# MARBLE ATELIER v0.9.6 (build 20) — camera regression repair

## Source provenance
Started from the latest v0.9.5 BlueStacks source (Library version 10), and compared the camera methods against original v0.9.2 (Library version 7 backup). No rebuilding from scratch.

## Exact reversal
- `FilamentBoard.changeZoom(float)` restored to the v0.9.2 range 0.52–2.60 (from the v0.9.3 range 0.66–2.40).
- `FilamentBoard.refreshCamera()` restored v0.9.2 target calculation without post-v0.9.3 focusFraction clamping.
- Other camera code (orbit easing, overview, camera reset, pan and touch gestures) left alone.

## Preserved
Both 10-level volumes, authored maze layouts, records, physics, music, cosmetics, Beacon Harbour crag and harbour scene, blue water reflection mitigation, invisible WASD/arrow input, Samsung support and BlueStacks arm64-v8a/x86_64 support.

## Test contract
Run `python3 tools/test_camera_v096.py` to verify original camera geometry and zoom are present; run all existing QA. Build from GitHub Actions workflow included with this ZIP. Compiled APK and actual camera feel/rendering remain unverified until built and tested on the user's phone/BlueStacks.

The source ZIP **must retain** the name `MARBLE_ATELIER_V060_STUDIO.zip` in GitHub unless source autodetection is used. v0.9.6 Build 20 allows updating a previous v0.9.5 Build 19 installation when signing signatures match.
