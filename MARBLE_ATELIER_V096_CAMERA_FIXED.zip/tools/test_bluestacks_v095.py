#!/usr/bin/env python3
"""Source regression for BlueStacks 5; does NOT replace a real emulator runtime test."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
gradle=(root/'app/build.gradle').read_text()
main=(root/'app/src/main/java/com/atelier/marble/MainActivity.java').read_text()
keyboard=(root/'app/src/main/java/com/atelier/marble/KeyboardSteering.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
compat=(root/'app/src/main/java/com/atelier/marble/EmulatorCompatibility.java').read_text()
renderer=(root/'app/src/main/java/com/atelier/marble/FilamentBoard.java').read_text()
assert re.search(r"abiFilters\s+['\"]arm64-v8a['\"],\s*['\"]x86_64['\"]",gradle)
assert "versionCode 20" in gradle and "versionName '0.9.6'" in gradle
assert 'filament-android:1.75.1' in gradle and 'filamat-android:1.75.1' in gradle
assert 'minSdk 28' in gradle
assert 'Engine.create(Engine.Backend.OPENGL)' in renderer
assert '.targetApi(MaterialBuilder.TargetApi.OPENGL)' in renderer
assert 'EmulatorCompatibility.initialGraphicsProfile()' in main
assert 'Build.SUPPORTED_ABIS' in compat and 'GraphicsProbe.BALANCED' in compat
assert 'graphics_boot_pending' in main
assert all(x in main for x in ['KeyEvent.KEYCODE_W','KeyEvent.KEYCODE_A', 'KeyEvent.KEYCODE_S', 'KeyEvent.KEYCODE_D', 'KeyEvent.KEYCODE_DPAD_UP','onWindowFocusChanged', 'keyboardSteering.clear()'])
assert 'keyboard|navigation' in manifest
assert 'physics.step(1f/60f,steerX,steerZ)' in main
assert 'screenX()' in keyboard and 'screenY()' in keyboard
print('PASS BlueStacks source contracts: ABI, API, GL, input, default graphics, mobile preserved')
print('NOTE: native library packaging & emulator GPU execution require the GitHub APK build and BlueStacks test')
