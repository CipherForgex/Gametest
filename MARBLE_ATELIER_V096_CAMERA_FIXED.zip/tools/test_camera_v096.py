#!/usr/bin/env python3
"""Verify original camera from v0.9.2 after v0.9.6 restoration (source contract)."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
java=(root/'app/src/main/java/com/atelier/marble/FilamentBoard.java').read_text()
zoom=java.split('public void changeZoom(float multiplier){',1)[1].split('public void toggleOverview(){',1)[0]
cam=java.split('private void refreshCamera(){',1)[1].split('private void updateCamera(float dt){',1)[0]
assert 'targetZoom=Math.max(.52f,Math.min(2.60f,targetZoom*multiplier));' in zoom
assert 'double tx=focusX*(1-overviewBlend)+panX*overviewBlend;' in cam
assert 'double tz=focusZ*(1-overviewBlend)+panZ*overviewBlend;' in cam
assert 'focusFraction' not in cam
assert 'currentLevel.halfWidth*' not in cam and 'currentLevel.halfLength*' not in cam
assert 'camera.lookAt(' in cam
assert 'yaw+=delta*a;' in java
assert 'public void rotateCamera(float degrees)' in java
print('PASS: original v0.9.2 zoom and free-follow camera framing restored; smooth orbit/overview retained')
