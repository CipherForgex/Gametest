#!/usr/bin/env python3
"""Non-rendering harbour rock and water regression contract (requires no Android SDK)."""
from pathlib import Path
import re, math
root=Path(__file__).resolve().parents[1]
render=(root/'app/src/main/java/com/atelier/marble/FilamentBoard.java').read_text()
blueprints=(root/'app/src/main/java/com/atelier/marble/LevelBlueprints.java').read_text()
assert render.count('private void buildHarbourFoundation(')==1
foundation=render.split('private void buildHarbourFoundation(')[1].split('private void buildHarbourScene(')[0]
assert 'Mesh bedrock=makeHarbourCrag(' in foundation
assert 'foundation.add(new BoxPart(0,-4.67f' not in render
assert 'foundation.add(new BoxPart(0,-5.95f' not in render
assert 'final int sides=96' in foundation
match_y=re.search(r'final float\[\] elevations=\{([^}]+)\}',foundation)
match_r=re.search(r'final float\[\] spreads=\{([^}]+)\}',foundation)
assert match_y and match_r
parse=lambda m:[float(x.strip().removesuffix('f')) for x in m.group(1).split(',')]
heights,scales=parse(match_y),parse(match_r)
assert len(heights)==len(scales)==10 and all(b>a for a,b in zip(heights,heights[1:]))
assert heights[-1]<=-1.95 and heights[0]<-7.7
assert scales[0]>scales[-1] and scales[5]<scales[6] and scales[6]>scales[7], 'Require non-pyramidal shelves and changes of slope'
# 20 level board dimensions are identical to existing blueprint definitions and do not enter render tests.
assert 'COUNT = 20' in blueprints and blueprints.count('new Blueprint(')==20
assert 'lake?.035f:0' in render and 'lake?.08f:0' in render
assert 'landscapePaint("water",.54f)' in render
assert '.usage(Texture.Usage.DEFAULT | Texture.Usage.GEN_MIPMAPPABLE)' in render
assert 'addBoat(' in render and 'makeBeaconBeam()' in render
assert 'buildSanctuary(game,span)' in render
print('PASS coastal rock has 10 nonuniform levels, lake-rooted foot, carved crown and no descending support slabs')
print('PASS water reflection mitigation, 20 original maps and startup mipmap guard')
print('NOTE source contract only: Filament GPU, visual artefact, frame rate and controls need phone test')
