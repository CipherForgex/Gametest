package com.atelier.marble;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.RadialGradient;
import android.graphics.Matrix;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.SeekBar;
import java.util.Locale;

/** Polished offline-first native Android shell over Filament. All pages fully navigable. */
public final class MainActivity extends Activity implements Choreographer.FrameCallback {
    private static final int MENU=0,PLAY=1,PAUSE=2,WIN=3,SETTINGS=4,LEVELS=5,RECORDS=6,
        STUDIO=7,THEMES=8,MARBLES=9,CAMERA=10,CONTROL=11,AUDIO=12;
    private static final int WHITE=0xfff2ede5,MUTED=0xffa5b2bc,BG=0xff0c121c;
    private FrameLayout root,overlay;
    private FilamentBoard board;
    private MarblePhysics physics;
    private TextView timerText,crashText,hintText;
    private long resetHintUntil=0L;
    private int mode=MENU,level=1,themeChoice=0,skinChoice=0,selectedVolume=0;
    private MusicDirector music;
    private boolean musicEnabled=true;
    private float musicGain=.45f,effectsGain=.65f;
    private boolean globalTheme=false,follow=true,sounds=true,haptics=true,highQuality=true;
    private int graphicsProfile=GraphicsProbe.STUDIO; // Best-quality default; Maximum remains optional in Graphics Lab.
    private int successfulAppFrames=0;
    private int graphicsDisabledMask=0;
    private float sensitivity=.78f,inputX,inputZ,lastX,lastY,anchorX,anchorY,gestureVX,gestureVY;
    private long lastTouchMillis,previousFrame;
    private double lastAngle,lastDistance;
    private float accumulator;
    private float renderPreviousX,renderPreviousZ;
    private int fingerMode=0; // 1=steer, 2=camera, 3=wait until fingers lift
    private final KeyboardSteering keyboardSteering=new KeyboardSteering();
    // Session-only fallback: an emulator can steer without waiting for tilt calibration.
    private boolean keyboardOnlySession=false,awaitingTiltCentre=false;
    private boolean active;
    private boolean cameraExpanded=false;
    private TiltSensor tilt;
    private boolean tiltEnabled;
    private int tiltSensitivity=1,tiltDeadZone=3;
    private SoundPool pool;
    private int impactSfx,completeSfx,tapSfx;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        SharedPreferences p=prefs();
        tilt=new TiltSensor(this);
        tiltEnabled=p.getBoolean("tilt_enabled",true)&&tilt.available();
        tiltSensitivity=Math.max(0,Math.min(2,p.getInt("tilt_sensitivity",1)));
        tiltDeadZone=Math.max(1,Math.min(10,p.getInt("tilt_dead_zone",3)));
        configureTilt();
        if(p.getInt("sanctuary_art_version",0)<1){
            p.edit().putInt("theme",0).putInt("skin",4).putBoolean("global_theme",true)
                .putInt("sanctuary_art_version",1).apply();
        }
        themeChoice=p.getInt("theme",0)%VisualStyles.THEMES.length;
        skinChoice=p.getInt("skin",4)%VisualStyles.MARBLES.length;
        globalTheme=p.getBoolean("global_theme",true); // New installs: coherent ivory collection; previous preference wins.
        follow=p.getBoolean("follow",true);
        sensitivity=p.getFloat("sensitivity",.78f);
        selectedVolume=Math.max(0,Math.min(1,p.getInt("selected_volume",0)));
        musicEnabled=p.getBoolean("music_enabled",true);musicGain=p.getFloat("music_gain",.45f);effectsGain=p.getFloat("effects_gain",.65f);
        sounds=p.getBoolean("sound",true);haptics=p.getBoolean("haptics",true);
        highQuality=p.getBoolean("quality",true);
        graphicsProfile=p.getInt("graphics_profile",GraphicsProbe.STUDIO);
        graphicsDisabledMask=p.getInt("graphics_disabled_mask",0);
        // If a previous start crashed before we saw 90 UI frames, force SAFE next launch.
        // This guards repeat crashes from experimental GPU settings without deleting saves.
        if(p.getBoolean("graphics_boot_pending",false)){
            graphicsProfile=GraphicsProbe.SAFE;
            android.util.Log.w("MarbleAtelier","Incomplete graphics boot detected; SAFE mode recovery");
        }
        p.edit().putBoolean("graphics_boot_pending",true).apply();
        root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
        try {
            board=new FilamentBoard(this);
            root.addView(board.getSurface(),new FrameLayout.LayoutParams(-1,-1));
            board.getSurface().setOnTouchListener((view,event)->onGameTouch(event));
            overlay=new FrameLayout(this);root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
            board.setFollowBall(follow);board.setGraphicsDisabledMask(graphicsDisabledMask);
            board.setGraphicsProfile(graphicsProfile);
            saveGraphicsReport();
            initializeSounds();applyTheme(volumeStart());showMenu();
        }catch(Throwable e){
            android.util.Log.e("MarbleAtelier","Graphics initialisation failed",e);
            prefs().edit().putInt("graphics_profile",GraphicsProbe.SAFE).apply();
            root.removeAllViews();
            TextView fallback=label("MARBLE ATELIER\n\nGraphics could not initialise.\n\n"+
                e.getClass().getSimpleName()+"\n"+String.valueOf(e.getMessage()),16,WHITE,true);
            fallback.setPadding(dp(28),dp(45),dp(28),dp(35));root.addView(fallback);
        }
    }
    private void initializeSounds(){
        try{
            pool=new SoundPool.Builder().setMaxStreams(3)
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build();
            impactSfx=pool.load(getAssets().openFd("sfx/impact.wav"),1);
            completeSfx=pool.load(getAssets().openFd("sfx/complete.wav"),1);
            tapSfx=pool.load(getAssets().openFd("sfx/tap.wav"),1);
        }catch(Exception ex){android.util.Log.w("MarbleAtelier","Audio optional",ex);}
        music=new MusicDirector(this);music.volume(musicEnabled?musicGain:0);music.scene(selectedVolume,false);
    }
    private void sound(int id){if(sounds&&pool!=null&&id!=0)pool.play(id,effectsGain,effectsGain,0,0,1f);}
    private void haptic(int type){if(haptics)root.performHapticFeedback(type);}
    private SharedPreferences prefs(){return getPreferences(0);}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private int accent(){return selectedVolume==1?0xffb6cbc9:VisualStyles.accent(globalTheme?themeChoice:(level-1)%6);}
    private int volumeStart(){return Volumes.start(selectedVolume);}
    private int volumeEnd(){return Volumes.end(selectedVolume);}
    private String volumeName(){return selectedVolume==0?"Sanctuary":"Beacon Harbour";}
    private String progressKey(){return Volumes.progressKey(selectedVolume);}
    private GradientDrawable surface(int fill,int radius,int border){
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));
        if(border!=0)d.setStroke(dp(1),border);return d;
    }
    private GradientDrawable gradient(int a,int b,int radius){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{a,b});
        d.setCornerRadius(dp(radius));return d;
    }
    private TextView label(String text,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        t.setGravity(Gravity.CENTER);t.setIncludeFontPadding(false);
        return t;
    }
    private FrameLayout.LayoutParams place(int w,int h,int grav,int l,int top,int r,int bottom){
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),grav);
        p.setMargins(dp(l),dp(top),dp(r),dp(bottom));return p;
    }
    private LinearLayout column(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);return c;}
    private void clear(){overlay.removeAllViews();timerText=crashText=hintText=null;}
    private View shade(boolean opaque){
        View v=new View(this);v.setBackground(gradient(opaque?0xf50b1423:0x1615181a,
            opaque?0xf80b1422:0xc9091012,0));return v;
    }
    private void applyTheme(int n){if(board!=null)board.applyStyle(n>10?6:(globalTheme?Math.floorMod(themeChoice,6):(n-1)%6),skinChoice,n);}
    private void tappable(View v,Runnable action){v.setOnClickListener(w->{sound(tapSfx);haptic(android.view.HapticFeedbackConstants.VIRTUAL_KEY);action.run();});}
    private TextView textButton(String title,boolean emphasis,Runnable run){
        TextView t=label(title,13,emphasis?0xff101925:WHITE,true);
        t.setLetterSpacing(.035f);
        t.setPadding(dp(10),dp(6),dp(10),dp(6));
        t.setMinHeight(dp(48));
        int tint=accent();
        t.setBackground(emphasis?gradient(brighter(tint),tint,15):surface(selectedVolume==0?0xa51a2024:0xa5112639,12,selectedVolume==0?0x557f7b70:0x5590b6ca));
        t.setBackground(new android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33ffffff),t.getBackground(),null));
        tappable(t,run);return t;
    }
    private static int brighter(int c){
        return 0xff000000|(Math.min(255,((c>>16)&255)+29)<<16)|
            (Math.min(255,((c>>8)&255)+29)<<8)|Math.min(255,(c&255)+29);
    }
    private void lineButton(LinearLayout parent,String text,boolean primary,Runnable run){
        TextView button=textButton(text,primary,run);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(49));lp.topMargin=dp(11);
        parent.addView(button,lp);
    }
    private LinearLayout panel(){
        LinearLayout c=column();c.setPadding(dp(19),dp(19),dp(19),dp(19));
        c.setBackground(surface(selectedVolume==0?0xee12191c:0xee091b2a,18,selectedVolume==0?0x557a776d:0x5577a6c0));return c;
    }
    private void title(LinearLayout box,String heading,String subtitle){
        TextView h=label(heading,27,WHITE,true);h.setLetterSpacing(.03f);box.addView(h);
        TextView description=label(subtitle,12,MUTED,false);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42));box.addView(description,lp);
    }
    private LinearLayout page(String title,String subtitle){
        clear();overlay.addView(shade(true),new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content=panel();title(content,title,subtitle);
        scroll.addView(content);overlay.addView(scroll,place(-1,-1,Gravity.CENTER,14,34,14,20));
        lineButton(content,"‹   BACK TO MENU",false,this::showMenu);
        return content;
    }
    private void showMenu(){
        keyboardSteering.clear();awaitingTiltCentre=false;keyboardOnlySession=false;
        mode=MENU;level=volumeStart();inputX=inputZ=0;fingerMode=0;
        applyTheme(level);board.presentMenu();
        clear();overlay.addView(shade(false),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout hero=column();hero.setGravity(Gravity.CENTER);
        TextView kicker=label(selectedVolume==0?"S A N C T U A R Y   /   V O L .  0 1":"B E A C O N   H A R B O U R   /   V O L .  0 2",10,accent(),true);hero.addView(kicker);
        TextView logo=label("Marble\nAtelier",48,WHITE,false);
        logo.setTypeface(Typeface.create(selectedVolume==0?"serif":"sans-serif-light",Typeface.NORMAL));
        logo.setLetterSpacing(.025f);LinearLayout.LayoutParams lg=new LinearLayout.LayoutParams(-1,-2);lg.topMargin=dp(15);hero.addView(logo,lg);
        TextView subtitle=label(selectedVolume==0?"Stone. Light. Motion.":"A quiet harbour. A guiding light.",11,MUTED,false);
        LinearLayout.LayoutParams sg=new LinearLayout.LayoutParams(-1,dp(48));hero.addView(subtitle,sg);
        overlay.addView(hero,place(-1,-2,Gravity.TOP,15,48,15,0));
        LinearLayout nav=column();nav.setPadding(dp(12),dp(16),dp(12),dp(10));
        LinearLayout volumes=new LinearLayout(this);
        for(int v=0;v<2;v++){
            final int volume=v;
            TextView choice=textButton((v==0?"01  SANCTUARY":"02  BEACON HARBOUR")+(v==selectedVolume?"  ✓":""),v==selectedVolume,()->{
                selectedVolume=volume;prefs().edit().putInt("selected_volume",volume).apply();showMenu();
            });
            LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(0,dp(46),1);vp.setMargins(dp(3),0,dp(3),dp(12));volumes.addView(choice,vp);
        }
        nav.addView(volumes);
        TextView eyebrow=label("PICK UP WHERE YOU LEFT OFF",11,MUTED,true);nav.addView(eyebrow);
        int unlocked=Volumes.continuation(selectedVolume,prefs().getInt(progressKey(),volumeStart()));
        lineButton(nav,String.format(Locale.US,"▶   CONTINUE  •  LEVEL %02d",LevelBlueprints.chapterOf(unlocked)),true,()->startLevel(unlocked));
        LinearLayout first=new LinearLayout(this),second=new LinearLayout(this);
        first.setOrientation(LinearLayout.HORIZONTAL);second.setOrientation(LinearLayout.HORIZONTAL);
        navTile(first,"▦","LEVELS",this::showLevels);navTile(first,"◷","RECORDS",this::showBestTimes);
        navTile(second,"◈","ATELIER",this::showStudio);navTile(second,"⚙","SETTINGS",this::showSettings);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(64));lp.topMargin=dp(12);nav.addView(first,lp);
        LinearLayout.LayoutParams lp2=new LinearLayout.LayoutParams(-1,dp(64));lp2.topMargin=dp(7);nav.addView(second,lp2);
        TextView note=label("TEN MAPS PER VOLUME  ·  TWO DISTINCT WORLDS",10,MUTED,false);
        nav.addView(note,new LinearLayout.LayoutParams(-1,dp(39)));
        overlay.addView(nav,place(-1,-2,Gravity.BOTTOM,16,0,16,23));
    }
    private void navTile(LinearLayout row,String glyph,String name,Runnable action){
        LinearLayout cell=column();cell.setGravity(Gravity.CENTER);
        cell.setBackground(surface(0x88191e22,12,0x4d9b9588));
        TextView ic=label(glyph,26,accent(),false);cell.addView(ic,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView text=label(name,11,WHITE,true);text.setLetterSpacing(.07f);
        cell.addView(text,new LinearLayout.LayoutParams(-1,dp(20)));
        tappable(cell,action);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);
        cp.leftMargin=dp(4);cp.rightMargin=dp(4);row.addView(cell,cp);
    }
    /** Actual collision-geometry preview: no invented image thumbnails. */
    private static final class MazePreview extends View{
        final MarblePhysics m;final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
        MazePreview(Activity a,int level){super(a);m=new MarblePhysics(level);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float w=getWidth(),h=getHeight();
            float cell=Math.min((w-16)/m.cols,(h-16)/m.rows);
            c.save();c.translate((w-m.cols*cell)/2,(h-m.rows*cell)/2);
            pen.setStyle(Paint.Style.FILL);pen.setColor(0xff253c52);
            for(int x=0;x<m.cols;x++)for(int z=0;z<m.rows;z++)if(m.isCell(x,z))
                c.drawRect(x*cell,z*cell,(x+1)*cell,(z+1)*cell,pen);
            pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(Math.max(1,cell*.11f));
            pen.setStrokeCap(Paint.Cap.SQUARE);pen.setColor(0xffc5d5dc);
            for(int x=0;x<m.cols;x++)for(int z=0;z<m.rows;z++)if(m.isCell(x,z)){
                int bits=m.openingBits(x,z);
                if((bits&1)==0)c.drawLine((x+1)*cell,z*cell,(x+1)*cell,(z+1)*cell,pen);
                if((bits&2)==0)c.drawLine(x*cell,(z+1)*cell,(x+1)*cell,(z+1)*cell,pen);
                if((bits&4)==0&&!m.isCell(x-1,z))c.drawLine(x*cell,z*cell,x*cell,(z+1)*cell,pen);
                if((bits&8)==0&&!m.isCell(x,z-1))c.drawLine(x*cell,z*cell,(x+1)*cell,z*cell,pen);
            }
            pen.setStyle(Paint.Style.FILL);pen.setColor(0xff67d9d3);
            c.drawCircle((m.cellCol(m.startX)+.5f)*cell,(m.cellRow(m.startZ)+.5f)*cell,cell*.33f,pen);
            pen.setColor(0xffffc474);
            c.drawCircle((m.cellCol(m.goalX)+.5f)*cell,(m.cellRow(m.goalZ)+.5f)*cell,cell*.33f,pen);
            c.restore();
        }
    }
    private String time(long ms){long cs=ms/10;return String.format(Locale.US,"%02d:%02d.%02d",cs/6000,(cs/100)%60,cs%100);}
    private long record(int n){return prefs().getLong("v04_best_"+n,Long.MAX_VALUE);}
    private String recordLabel(int n){long ms=record(n);return ms==Long.MAX_VALUE?"NO RECORD":time(ms);}
    private void showLevels(){
        mode=LEVELS;LinearLayout content=page(volumeName().toUpperCase(Locale.US)+" · MAPS","Ten distinct maps, increasingly demanding routes.");
        for(int i=volumeStart();i<=volumeEnd();i++){
            final int number=i;MarblePhysics p=new MarblePhysics(i);
            LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(dp(9),dp(8),dp(8),dp(8));
            line.setBackground(surface(0xec243345,14,0x415c7185));
            MazePreview preview=new MazePreview(this,i);
            line.addView(preview,new LinearLayout.LayoutParams(dp(90),dp(87)));
            LinearLayout info=column();info.setPadding(dp(14),0,0,0);
            TextView name=label(String.format(Locale.US,"%02d  %s",LevelBlueprints.chapterOf(i),p.shapeName()),16,WHITE,true);
            name.setGravity(Gravity.LEFT);info.addView(name);
            TextView detail=label("BEST  "+recordLabel(i),11,MUTED,false);detail.setGravity(Gravity.LEFT);
            LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(32));info.addView(detail,dl);
            line.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            TextView arrow=label("›",29,accent(),false);line.addView(arrow,new LinearLayout.LayoutParams(dp(27),dp(45)));
            tappable(line,()->startLevel(number));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(103));lp.topMargin=dp(10);content.addView(line,lp);
        }
    }
    private void showBestTimes(){
        mode=RECORDS;LinearLayout c=page("BEST TIMES","Personal records saved entirely on your device.");
        for(int i=volumeStart();i<=volumeEnd();i++){
            final int n=i;TextView item=textButton(String.format(Locale.US,"%02d  %-10s    %s",LevelBlueprints.chapterOf(i),
                new MarblePhysics(i).shapeName(),recordLabel(i)),false,()->startLevel(n));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(49));lp.topMargin=dp(8);c.addView(item,lp);
        }
    }
    private void showStudio(){
        mode=STUDIO;LinearLayout c=page("THE ATELIER","Real materials. Your style. Your marble.");
        lineButton(c,"◈   BROWSE BOARD THEMES",true,this::showThemes);
        lineButton(c,"◉   MARBLE COLLECTION",false,this::showMarbles);
        TextView copy=label("Select a surface and a marble independently. Your look is saved offline.",13,MUTED,false);
        copy.setPadding(dp(6),dp(20),dp(6),dp(3));c.addView(copy);
    }
    private void showThemes(){
        mode=THEMES;LinearLayout c=page("MATERIAL WORLDS",selectedVolume==0?"Textured stone, metal, ice and more.":"Beacon Harbour has its own slate and brushed silver finish.");
        if(selectedVolume==1){
            lineButton(c,"◉  CHOOSE YOUR HARBOUR MARBLE",true,this::showMarbles);
            return;
        }
        lineButton(c,"LEVEL THEMES: "+(globalTheme?"CUSTOM OVERRIDE":"AUTOMATIC"),true,()->{
            globalTheme=!globalTheme;prefs().edit().putBoolean("global_theme",globalTheme).apply();applyTheme(volumeStart());showThemes();
        });
        for(int i=0;i<6;i++){
            final int selected=i;LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);
            line.setBackground(surface(0xee213143,13,i==themeChoice?accent():0x5563768a));
            ImageView thumb=new ImageView(this);
            try(java.io.InputStream stream=getAssets().open("materials/"+VisualStyles.TEXTURE_KEYS[i]+"_floor_albedo.png")){
                thumb.setImageBitmap(android.graphics.BitmapFactory.decodeStream(stream));
            }catch(Exception ignored){}
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            line.addView(thumb,new LinearLayout.LayoutParams(dp(67),dp(67)));
            TextView name=label("  "+VisualStyles.THEMES[i]+(i==themeChoice?"  ✓":""),15,WHITE,true);
            line.addView(name,new LinearLayout.LayoutParams(0,-1,1));
            tappable(line,()->{themeChoice=selected;globalTheme=true;
                prefs().edit().putInt("theme",selected).putBoolean("global_theme",true).apply();
                applyTheme(volumeStart());showThemes();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(75));lp.topMargin=dp(9);c.addView(line,lp);
        }
    }
    /** Responsive, touch-rotatable material preview, without loading another 3D scene. */
    private final class MarbleSkinPreview extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Bitmap bitmap;
        private float shift,previousX;
        MarbleSkinPreview(int skin){
            super(MainActivity.this);
            Bitmap loaded=null;
            try(java.io.InputStream in=getAssets().open("materials/balls/"+
                    VisualStyles.BALL_TEXTURE_KEYS[skin]+"_albedo.png")){
                loaded=BitmapFactory.decodeStream(in);
            }catch(Exception ex){android.util.Log.w("MarbleAtelier","Marble preview texture",ex);}
            bitmap=loaded;
            setContentDescription("Rotatable preview of "+VisualStyles.MARBLES[skin]);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float cx=getWidth()*.5f,cy=getHeight()*.5f;
            float r=Math.min(getWidth()*.27f,getHeight()*.39f);
            paint.setShader(null);paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x66000000);c.drawOval(cx-r*1.04f,cy+r*.89f,cx+r*1.04f,cy+r*1.19f,paint);
            if(bitmap!=null){
                BitmapShader map=new BitmapShader(bitmap,Shader.TileMode.REPEAT,Shader.TileMode.CLAMP);
                Matrix m=new Matrix();m.setScale(2*r/bitmap.getWidth(),2*r/bitmap.getHeight());
                m.postTranslate(cx-r+shift,cy-r);map.setLocalMatrix(m);
                paint.setColor(Color.WHITE);paint.setShader(map);
            }else{paint.setColor(0xffb4c8db);}
            c.drawCircle(cx,cy,r,paint);
            paint.setShader(new RadialGradient(cx-r*.37f,cy-r*.50f,r*2.0f,
                new int[]{0x99FFFFFF,0x16FFFFFF,0xD4000716},
                new float[]{0f,.36f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r,paint);paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1.5f));
            paint.setColor(0x77E6F3FF);c.drawCircle(cx,cy,r,paint);
            paint.setStyle(Paint.Style.FILL);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN: previousX=e.getX();return true;
                case MotionEvent.ACTION_MOVE:
                    shift+=(e.getX()-previousX)*.43f;previousX=e.getX();invalidate();return true;
                case MotionEvent.ACTION_UP:performClick();return true;
                case MotionEvent.ACTION_CANCEL:return true;
            }
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}
    }
    private void showMarbles(){
        mode=MARBLES;clear();board.presentMarble(skinChoice);
        LinearLayout heading=column();title(heading,"The Marble Vault","Live 3D materials · the same marble you play with");
        overlay.addView(heading,place(-1,-2,Gravity.TOP,18,34,18,0));
        LinearLayout c=panel();
        for(int row=0;row<4;row++){
            LinearLayout pair=new LinearLayout(this);
            for(int col=0;col<2;col++){
                final int selected=row*2+col;
                TextView item=textButton((selected==skinChoice?"●  ":"")+VisualStyles.MARBLES[selected],selected==skinChoice,()->{
                    skinChoice=selected;prefs().edit().putInt("skin",selected).apply();showMarbles();
                });
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1);
                lp.setMargins(dp(3),dp(3),dp(3),dp(3));pair.addView(item,lp);
            }
            c.addView(pair);
        }
        lineButton(c,"ROTATE MARBLE VIEW",false,()->board.rotateCamera(45));
        lineButton(c,"‹  BACK TO ATELIER",false,()->{applyTheme(volumeStart());showStudio();});
        overlay.addView(c,place(-1,-2,Gravity.BOTTOM,14,0,14,16));
    }
    private void showSettings(){
        mode=SETTINGS;LinearLayout c=page("SETTINGS","Configure how the game looks, feels and sounds.");
        settingsRow(c,"Camera","Follow the marble, choose your view and learn the gestures.",this::showCameraSettings);
        settingsRow(c,"Tilt & touch","Choose tilt steering, dead zone or touch controls.",this::showControls);
        settingsRow(c,"Sound & feel","Rolling feedback, effects and touch vibration.",this::showAudioSettings);
        settingsRow(c,"Graphics Lab · "+GraphicsProbe.NAMES[graphicsProfile],"Picture quality, performance and advanced effects.",this::showGraphicsLab);
    }
    private void settingsRow(LinearLayout parent,String heading,String detail,Runnable action){
        LinearLayout row=column();row.setPadding(dp(17),dp(16),dp(17),dp(16));
        row.setBackground(surface(0xe8212c38,16,0x405e6c76));
        TextView h=label(heading+"  ›",17,WHITE,true);h.setGravity(Gravity.LEFT);row.addView(h);
        TextView d=label(detail,12,MUTED,false);d.setGravity(Gravity.LEFT);d.setPadding(0,dp(8),0,0);row.addView(d);
        row.setContentDescription(heading+". "+detail);tappable(row,action);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(12);parent.addView(row,lp);
    }
    private void showCameraHelp(){
        keyboardSteering.clear();awaitingTiltCentre=false;
        mode=PAUSE;inputX=inputZ=0;physics.stop();fingerMode=0;
        clear();overlay.addView(shade(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout c=panel();title(c,"Find your angle","Camera controls never move the maze.");
        TextView guide=label("ROTATE  ·  Turn the view 90°\n\nZOOM + / −  ·  Move closer or further away\n\nRESET  ·  Restore the starting angle\n\nTOP VIEW  ·  See the route from above\n\nTwo fingers: pinch to zoom, twist to orbit.\nTouch mode: drag and flick. Tilt mode: lean to roll; Centre resets your comfortable angle.",14,WHITE,false);
        guide.setGravity(Gravity.LEFT);guide.setPadding(dp(8),dp(14),dp(8),dp(18));c.addView(guide);
        lineButton(c,"GOT IT · BACK TO GAME",true,this::resumeRun);
        ScrollView scroll=new ScrollView(this);scroll.addView(c);overlay.addView(scroll,place(-1,-2,Gravity.CENTER,18,36,18,36));
    }
    private void saveGraphicsReport(){
        if(board==null)return;
        try(java.io.FileOutputStream out=openFileOutput("graphics_report.txt",MODE_PRIVATE)){
            out.write((board.getGraphicsReport()+"\nDevice: "+android.os.Build.MODEL+
                "\nAndroid "+android.os.Build.VERSION.RELEASE).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }catch(Exception ex){android.util.Log.w("MarbleAtelier","Could not store GPU report",ex);}
    }
    private String previousGraphicsReport(){
        try(java.io.FileInputStream in=openFileInput("graphics_report.txt")){
            java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream();
            byte[] chunk=new byte[4096];int read;
            while((read=in.read(chunk))!=-1 && b.size()<65536)b.write(chunk,0,read);
            return b.toString("UTF-8");
        }catch(Exception ex){return "No previous graphics report saved yet.";}
    }
    private void showGraphicsLab(){
        LinearLayout c=page("GRAPHICS LAB", "GPU stress-testing • no internet or account needed");
        TextView intro=label("MAXIMUM deliberately combines costly effects. If it stutters or looks wrong, switch to STUDIO or SAFE, then share the report.",13,MUTED,false);
        intro.setGravity(Gravity.LEFT);intro.setPadding(dp(6),dp(12),dp(6),dp(18));
        c.addView(intro);
        for(int i=0;i<GraphicsProbe.NAMES.length;i++){
            final int value=i;
            lineButton(c,(i==graphicsProfile?"●  ":"○  ")+GraphicsProbe.NAMES[i],i==graphicsProfile,()->{
                graphicsProfile=value;
                prefs().edit().putInt("graphics_profile",value)
                    .putBoolean("graphics_boot_pending",false).apply();
                board.setGraphicsProfile(value);saveGraphicsReport();showGraphicsLab();
            });
        }
        TextView switches=label("INDIVIDUAL EFFECT SWITCHES  •  ISOLATE CRASHES OR FPS DROPS",11,MUTED,true);
        switches.setPadding(dp(4),dp(22),dp(4),dp(11));c.addView(switches);
        for(int i=0;i<GraphicsProbe.FEATURES.length;i++){
            final int bit=i;
            boolean enabled=(graphicsDisabledMask&(1<<i))==0;
            lineButton(c,(enabled?"◉   ":"○   ")+GraphicsProbe.FEATURES[i]+(enabled?"  ON":"  OFF"),false,()->{
                graphicsDisabledMask ^= (1<<bit);
                prefs().edit().putInt("graphics_disabled_mask",graphicsDisabledMask).apply();
                board.setGraphicsDisabledMask(graphicsDisabledMask);
                board.setGraphicsProfile(graphicsProfile);saveGraphicsReport();
                showGraphicsLab();
            });
        }
        lineButton(c,"SHARE GRAPHICS / FPS REPORT",false,()->{
            String report=board.getGraphicsReport()+"\nAndroid "+android.os.Build.VERSION.RELEASE+
                " | device "+android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL;
            android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_SEND);
            intent.setType("text/plain");intent.putExtra(android.content.Intent.EXTRA_TEXT,report);
            startActivity(android.content.Intent.createChooser(intent,"Share graphics diagnostics"));
        });
        lineButton(c,"SHARE PREVIOUS SESSION REPORT",false,()->{
            android.content.Intent report=new android.content.Intent(android.content.Intent.ACTION_SEND);
            report.setType("text/plain");
            report.putExtra(android.content.Intent.EXTRA_TEXT,previousGraphicsReport());
            startActivity(android.content.Intent.createChooser(report,"Previous graphics session"));
        });
        lineButton(c,"COPY GRAPHICS REPORT",false,()->{
            android.content.ClipboardManager manager=(android.content.ClipboardManager)
                getSystemService(CLIPBOARD_SERVICE);
            manager.setPrimaryClip(android.content.ClipData.newPlainText("Marble graphics",board.getGraphicsReport()));
        });
        TextView diagnostic=label(board.getGraphicsReport(),10,MUTED,false);
        diagnostic.setGravity(Gravity.LEFT);diagnostic.setTextIsSelectable(true);
        diagnostic.setPadding(dp(7),dp(20),dp(7),dp(20));c.addView(diagnostic);
    }
    private void showCameraSettings(){
        mode=CAMERA;LinearLayout c=page("CAMERA","Rotate, orbit, zoom and inspect without cheating.");
        lineButton(c,"SMOOTH BALL FOLLOW  "+(follow?"ON":"OFF"),true,()->{
            follow=!follow;prefs().edit().putBoolean("follow",follow).apply();
            board.setFollowBall(follow);showCameraSettings();
        });
        TextView t=label("90° ROTATE: animated easing\nTWO-FINGER TWIST: full 360° orbit\nPINCH: zoom in and out\nTARGET: returns to the default camera\nOVERHEAD: playable top-down view — steering enabled\nWALLS: permanently visible",13,MUTED,false);
        t.setGravity(Gravity.LEFT);t.setLineSpacing(dp(7),1f);t.setPadding(dp(6),dp(22),dp(6),dp(18));c.addView(t);
    }
    private void showControls(){
        mode=CONTROL;LinearLayout c=page("TILT & TOUCH","Gentle tilt for precision. More tilt for more speed.");
        lineButton(c,"CONTROLS  ·  "+(tiltEnabled?"TILT":"TOUCH"),true,()->{
            if(!tiltEnabled&&!tilt.available()){
                android.widget.Toast.makeText(this,"No motion sensor available. Touch controls remain active.",android.widget.Toast.LENGTH_LONG).show();return;
            }
            tiltEnabled=!tiltEnabled;inputX=inputZ=gestureVX=gestureVY=0;
            prefs().edit().putBoolean("tilt_enabled",tiltEnabled).apply();
            if(tiltEnabled){if(!tilt.start())tiltEnabled=false;}else tilt.stop();showControls();
        });
        lineButton(c,"TILT SENSITIVITY  ·  "+new String[]{"PRECISE","BALANCED","RESPONSIVE"}[tiltSensitivity],false,()->{
            tiltSensitivity=(tiltSensitivity+1)%3;prefs().edit().putInt("tilt_sensitivity",tiltSensitivity).apply();configureTilt();showControls();
        });
        lineButton(c,"DEAD ZONE  ·  "+tiltDeadZone+"%",false,()->{
            tiltDeadZone=tiltDeadZone==3?5:tiltDeadZone==5?8:tiltDeadZone==8?1:3;
            prefs().edit().putInt("tilt_dead_zone",tiltDeadZone).apply();configureTilt();showControls();
        });
        TextView tiltHelp=label("Hold your phone comfortably and tap Centre before playing. The default 3% dead zone ignores tiny tilts. Tilt further to accelerate; tilt back to brake. Momentum fades naturally at centre. Two fingers still control the camera.",13,MUTED,false);
        tiltHelp.setGravity(Gravity.LEFT);tiltHelp.setPadding(dp(6),dp(14),dp(6),dp(8));c.addView(tiltHelp);
        lineButton(c,"TOUCH SENSITIVITY  "+(sensitivity<.7f?"PRECISE":sensitivity<1f?"BALANCED":"RESPONSIVE"),true,()->{
            sensitivity=sensitivity<.7f?.78f:sensitivity<1f?1.15f:.57f;
            prefs().edit().putFloat("sensitivity",sensitivity).apply();showControls();
        });
        TextView help=label("Move your finger a little to steer slowly.\nA quick release adds a capped impulse.\nThe ball never teleports.\nA collision resets the timer and position.",13,MUTED,false);
        help.setGravity(Gravity.LEFT);help.setLineSpacing(dp(6),1f);
        help.setPadding(dp(6),dp(22),dp(6),dp(12));c.addView(help);
    }
    private void showAudioSettings(){
        mode=AUDIO;LinearLayout c=page("SOUND & FEEL","Quiet, tactile audio and optional haptics.");
        lineButton(c,"BACKGROUND MUSIC  "+(musicEnabled?"ON":"OFF"),true,()->{
            musicEnabled=!musicEnabled;prefs().edit().putBoolean("music_enabled",musicEnabled).apply();
            music.volume(musicEnabled?musicGain:0);showAudioSettings();
        });
        audioSlider(c,"MUSIC",musicGain,true);
        audioSlider(c,"EFFECTS",effectsGain,false);
        lineButton(c,"SOUND EFFECTS  "+(sounds?"ON":"OFF"),true,()->{
            sounds=!sounds;prefs().edit().putBoolean("sound",sounds).apply();showAudioSettings();
        });
        lineButton(c,"HAPTIC FEEDBACK  "+(haptics?"ON":"OFF"),false,()->{
            haptics=!haptics;prefs().edit().putBoolean("haptics",haptics).apply();showAudioSettings();
        });
    }
    private void audioSlider(LinearLayout parent,String name,float gain,boolean soundtrack){
        TextView value=label(name+"  "+Math.round(gain*100)+"%",12,MUTED,false);parent.addView(value);
        SeekBar slider=new SeekBar(this);slider.setMax(100);slider.setProgress(Math.round(gain*100));
        slider.setContentDescription(name+" volume");
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int progress,boolean user){
                if(!user)return;value.setText(name+"  "+progress+"%");
                float v=progress/100f;
                if(soundtrack){musicGain=v;music.volume(musicEnabled?v:0);}else effectsGain=v;
            }
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){prefs().edit().putFloat(soundtrack?"music_gain":"effects_gain",bar.getProgress()/100f).apply();}
        });
        parent.addView(slider,new LinearLayout.LayoutParams(-1,dp(48)));
    }
    private void configureTilt(){
        tilt.fullAngle=(float)Math.toRadians(new float[]{35,25,17}[tiltSensitivity]);
        tilt.deadZone=tiltDeadZone/100f;
    }
    private String steeringHint(){return tiltEnabled?"TILT TO ROLL  ·  "+tiltDeadZone+"% DEAD ZONE":"DRAG TO ROLL  ·  FLICK TO BOOST";}
    private void resumeRun(){
        keyboardSteering.clear();awaitingTiltCentre=false;
        inputX=inputZ=gestureVX=gestureVY=0;fingerMode=0;previousFrame=0;accumulator=0;
        if(physics!=null){renderPreviousX=physics.x;renderPreviousZ=physics.z;}
        if(tiltEnabled&&!keyboardOnlySession)showTiltCentre();else{mode=PLAY;showHud();}
    }
    private void showTiltCentre(){
        keyboardSteering.clear();awaitingTiltCentre=true;
        mode=PAUSE;inputX=inputZ=gestureVX=gestureVY=0;fingerMode=0;physics.stop();
        clear();overlay.addView(shade(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout c=panel();title(c,"Find your balance","Hold your phone at a comfortable angle.");
        TextView detail=label("Keep still, then tap Centre & play. This becomes your neutral position.\n\nSmall tilt = gentle rolling\nMore tilt = stronger acceleration\nOpposite tilt = braking\n\nDead zone: "+tiltDeadZone+"% · use Centre whenever your grip changes.",14,WHITE,false);
        detail.setGravity(Gravity.LEFT);detail.setPadding(dp(8),dp(14),dp(8),dp(18));c.addView(detail);
        lineButton(c,"CENTRE & PLAY",true,()->{
            if(!tilt.centre()){
                android.widget.Toast.makeText(this,"Waiting for a fresh motion reading. Keep still and tap again, or use touch.",android.widget.Toast.LENGTH_LONG).show();return;
            }
            keyboardOnlySession=false;awaitingTiltCentre=false;
            inputX=inputZ=accumulator=0;previousFrame=0;renderPreviousX=physics.x;renderPreviousZ=physics.z;mode=PLAY;showHud();
        });
        lineButton(c,"USE TOUCH INSTEAD",false,()->{
            keyboardOnlySession=false;tiltEnabled=false;tilt.stop();prefs().edit().putBoolean("tilt_enabled",false).apply();resumeRun();
        });
        lineButton(c,"MAIN MENU",false,this::showMenu);
        ScrollView scroll=new ScrollView(this);scroll.addView(c);overlay.addView(scroll,place(-1,-2,Gravity.CENTER,18,34,18,34));
    }
    private void startLevel(int n){
        keyboardSteering.clear();awaitingTiltCentre=false;
        level=Math.max(1,Math.min(LevelBlueprints.COUNT,n));selectedVolume=LevelBlueprints.volumeOf(level);
        prefs().edit().putInt("selected_volume",selectedVolume).apply();physics=new MarblePhysics(level);
        inputX=inputZ=accumulator=0;fingerMode=0;previousFrame=0;mode=PLAY;
        renderPreviousX=physics.x;renderPreviousZ=physics.z;
        applyTheme(level);
        // A single, atomic renderer update must match the gameplay blueprint.
        if(board.getLoadedLevel()!=physics.level)throw new IllegalStateException("Rendered and physics levels disagree");
        board.resetCamera();board.setFollowBall(follow);board.resetBallPose(physics.x,physics.z);
        board.updateBall(physics.x,physics.z,false,0);resumeRun();
    }
    private void showHud(){
        clear();
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12),dp(10),dp(10),dp(9));
        header.setBackground(surface(0x3813191b,16,0));
        LinearLayout info=column();
        TextView name=label(String.format(Locale.US,"%02d / 10  ·  %s",LevelBlueprints.chapterOf(level),physics.shapeName()),11,accent(),true);
        name.setGravity(Gravity.LEFT);info.addView(name);
        timerText=label("00:00.00",24,WHITE,false);timerText.setGravity(Gravity.LEFT);info.addView(timerText);
        crashText=label("BEST  "+recordLabel(level)+"   ·   RESETS 0",10,MUTED,false);
        crashText.setGravity(Gravity.LEFT);info.addView(crashText);
        header.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(icon("Ⅱ",()->{mode=PAUSE;inputX=inputZ=0;physics.stop();showPause();}),
            new LinearLayout.LayoutParams(dp(45),dp(46)));
        overlay.addView(header,place(-1,-2,Gravity.TOP,12,22,12,0));
        LinearLayout bottom=column();bottom.setPadding(dp(7),dp(5),dp(7),dp(7));
        bottom.setBackground(surface(0x7012191c,16,0x337e796d));
        hintText=label(steeringHint(),10,WHITE,true);
        resetHintUntil=0L;
        bottom.addView(hintText,new LinearLayout.LayoutParams(-1,dp(23)));
        LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER);
        tool(toolbar,"↻","ROTATE",()->board.rotateCamera(90));
        tool(toolbar,"⊕","ZOOM IN",()->board.changeZoom(.84f));
        tool(toolbar,"⊖","ZOOM OUT",()->board.changeZoom(1.19f));
        tool(toolbar,"⌖","RESET",()->board.resetCamera());
        tool(toolbar,"◎","TOP VIEW",()->{
            physics.stop();inputX=inputZ=0;fingerMode=0;
            board.toggleOverview();
            if(hintText!=null)hintText.setText(steeringHint());
        });
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);
        TextView help=textButton(cameraExpanded?"CLOSE VIEW":"CAMERA",false,()->{cameraExpanded=!cameraExpanded;showHud();});
        TextView restart=textButton("RESTART",false,()->startLevel(level));
        LinearLayout.LayoutParams actionLp=new LinearLayout.LayoutParams(0,dp(48),1);actionLp.setMargins(dp(3),dp(5),dp(3),0);

        TextView centre=textButton(tiltEnabled?"CENTRE":"TRY TILT",false,()->{
            if(!tilt.available()||!tilt.start()){
                android.widget.Toast.makeText(this,"Motion sensor unavailable; use touch controls.",android.widget.Toast.LENGTH_LONG).show();return;
            }
            tiltEnabled=true;prefs().edit().putBoolean("tilt_enabled",true).apply();showTiltCentre();
        });
        actions.addView(help,actionLp);actions.addView(centre,new LinearLayout.LayoutParams(actionLp));actions.addView(restart,new LinearLayout.LayoutParams(actionLp));
        if(cameraExpanded){
            bottom.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(59)));
            TextView guide=label("Two fingers: orbit & pinch  ·  Tap for help",11,MUTED,false);
            tappable(guide,this::showCameraHelp);bottom.addView(guide,new LinearLayout.LayoutParams(-1,dp(32)));
        }
        bottom.addView(actions);
        overlay.addView(bottom,place(-1,-2,Gravity.BOTTOM,10,0,10,20));
    }
    private TextView icon(String glyph,Runnable action){
        TextView t=label(glyph,25,WHITE,false);t.setBackground(surface(0x701b2428,23,0x66958d7a));
        t.setContentDescription(glyph);tappable(t,action);return t;
    }
    private void tool(LinearLayout bar,String glyph,String description,Runnable action){
        TextView b=icon(glyph+"\n"+description,action);b.setTextSize(11);b.setContentDescription(description);
        b.setTooltipText(description);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(55),1);
        p.leftMargin=dp(2);p.rightMargin=dp(2);bar.addView(b,p);
    }
    private void showPause(){
        keyboardSteering.clear();awaitingTiltCentre=false;
        clear();overlay.addView(shade(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout c=panel();title(c,"PAUSED","The run is waiting for you.");
        lineButton(c,"▶   RESUME",true,this::resumeRun);
        lineButton(c,"⟲   RESTART",false,()->startLevel(level));
        lineButton(c,"◈   THE ATELIER",false,this::showStudio);
        lineButton(c,"⌂   MAIN MENU",false,this::showMenu);
        overlay.addView(c,place(-1,-2,Gravity.CENTER,22,0,22,0));
    }
    private void showWin(){
        keyboardSteering.clear();awaitingTiltCentre=false;
        mode=WIN;long elapsed=Math.round(physics.seconds*1000f);
        boolean record=elapsed<record(level);
        if(record)prefs().edit().putLong("v04_best_"+level,elapsed).apply();
        prefs().edit().putInt(progressKey(),Math.max(prefs().getInt(progressKey(),volumeStart()),Volumes.next(level))).apply();
        sound(completeSfx);
        clear();overlay.addView(shade(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout c=panel();title(c,"MAZE CLEARED",time(elapsed)+"   ·   "+physics.crashes+" RESETS");
        TextView recordText=label(record?"✦  NEW PERSONAL BEST":"BEST  "+recordLabel(level),15,accent(),true);
        c.addView(recordText,new LinearLayout.LayoutParams(-1,dp(59)));
        lineButton(c,level<volumeEnd()?"NEXT MAZE   ›":"REPLAY FINAL MAZE",true,()->startLevel(Volumes.next(level)));
        lineButton(c,"⟲   REPLAY",false,()->startLevel(level));
        lineButton(c,"⌂   MAIN MENU",false,this::showMenu);
        overlay.addView(c,place(-1,-2,Gravity.CENTER,23,0,23,0));
    }
    /** Key events are intercepted before focused HUD views (or emulator controls) consume them.
     *  This never requests an Android soft keyboard or displays a keyboard widget.
     */
    @Override public boolean dispatchKeyEvent(KeyEvent event){
        final int key=keyboardDirection(event.getKeyCode());
        if(key==0 || (event.getAction()!=KeyEvent.ACTION_DOWN && event.getAction()!=KeyEvent.ACTION_UP)){
            return super.dispatchKeyEvent(event);
        }
        // A hardware keyboard is enough to enter gameplay even when an emulator exposes an
        // uncalibrated tilt sensor. This fallback is only for the current play session.
        if(mode==PAUSE && awaitingTiltCentre && event.getAction()==KeyEvent.ACTION_DOWN
                && !event.isAltPressed() && !event.isCtrlPressed() && !event.isMetaPressed()){
            keyboardOnlySession=true;awaitingTiltCentre=false;
            inputX=inputZ=accumulator=0;previousFrame=0;
            renderPreviousX=physics.x;renderPreviousZ=physics.z;
            mode=PLAY;showHud();
        }
        if(mode!=PLAY){return super.dispatchKeyEvent(event);}
        if(event.getAction()==KeyEvent.ACTION_DOWN
                && (event.isAltPressed()||event.isCtrlPressed()||event.isMetaPressed())){
            return super.dispatchKeyEvent(event); // Don't steal desktop keyboard shortcuts.
        }
        keyboardSteering.setHeld(key,event.getAction()==KeyEvent.ACTION_DOWN);
        return true;
    }
    private static int keyboardDirection(int keyCode){
        switch(keyCode){
            case KeyEvent.KEYCODE_W:return KeyboardSteering.W;
            case KeyEvent.KEYCODE_A:return KeyboardSteering.A;
            case KeyEvent.KEYCODE_S:return KeyboardSteering.S;
            case KeyEvent.KEYCODE_D:return KeyboardSteering.D;
            case KeyEvent.KEYCODE_DPAD_UP:return KeyboardSteering.UP;
            case KeyEvent.KEYCODE_DPAD_LEFT:return KeyboardSteering.LEFT;
            case KeyEvent.KEYCODE_DPAD_DOWN:return KeyboardSteering.DOWN;
            case KeyEvent.KEYCODE_DPAD_RIGHT:return KeyboardSteering.RIGHT;
            default:return 0;
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(!hasFocus){keyboardSteering.clear();}
    }
    private double angle(MotionEvent e){return Math.atan2(e.getY(1)-e.getY(0),e.getX(1)-e.getX(0));}
    private double distance(MotionEvent e){return Math.hypot(e.getX(1)-e.getX(0),e.getY(1)-e.getY(0));}
    private float worldX(float x,float y){return ControlMath.worldX(x,y,board.getYaw());}
    private float worldZ(float x,float y){return ControlMath.worldZ(x,y,board.getYaw());}
    private boolean onGameTouch(MotionEvent e){
        if(mode!=PLAY||physics==null)return false;
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                fingerMode=1;
                anchorX=lastX=e.getX();anchorY=lastY=e.getY();
                inputX=inputZ=gestureVX=gestureVY=0;lastTouchMillis=e.getEventTime();return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if(e.getPointerCount()>=2){
                    fingerMode=2;inputX=inputZ=0;physics.stop();
                    lastAngle=angle(e);lastDistance=distance(e);
                }return true;
            case MotionEvent.ACTION_MOVE:
                if(fingerMode==2&&e.getPointerCount()>=2){
                    double a=angle(e),d=distance(e);
                    double rotation=Math.atan2(Math.sin(a-lastAngle),Math.cos(a-lastAngle));
                    board.rotateCamera((float)-Math.toDegrees(rotation));
                    if(lastDistance>30&&d>30)board.changeZoom((float)(lastDistance/d));
                    lastAngle=a;lastDistance=d;
                }else if(fingerMode==1&&(!tiltEnabled||keyboardOnlySession)){
                    // Less finger travel needed than V0.3; capped analog steering, no direct position edit.
                    float dx=(e.getX()-anchorX)/dp(110)*sensitivity;
                    float dy=(e.getY()-anchorY)/dp(110)*sensitivity;
                    float mag=(float)Math.hypot(dx,dy);
                    if(mag>1){dx/=mag;dy/=mag;}
                    float wishX=worldX(dx,dy),wishZ=worldZ(dx,dy);
                    inputX=inputX*.30f+wishX*.70f;inputZ=inputZ*.30f+wishZ*.70f;
                    long elapsed=e.getEventTime()-lastTouchMillis;
                    if(elapsed>0){
                        float vx=(e.getX()-lastX)/elapsed;
                        float vy=(e.getY()-lastY)/elapsed;
                        gestureVX=gestureVX*.45f+vx*.55f;
                        gestureVY=gestureVY*.45f+vy*.55f;
                    }
                    lastX=e.getX();lastY=e.getY();lastTouchMillis=e.getEventTime();
                }return true;
            case MotionEvent.ACTION_POINTER_UP:
                fingerMode=3;inputX=inputZ=0;return true;
            case MotionEvent.ACTION_UP:
                if(fingerMode==1&&(!tiltEnabled||keyboardOnlySession)){
                    float speed=(float)Math.hypot(gestureVX,gestureVY);
                    float travel=(float)Math.hypot(e.getX()-anchorX,e.getY()-anchorY);
                    if(speed>.8f&&travel>dp(30)){
                        // Velocity impulse, deliberately bounded; swept collision in physics.step().
                        physics.flick(worldX(gestureVX,gestureVY),worldZ(gestureVX,gestureVY));
                    }
                }
                fingerMode=0;inputX=inputZ=0;return true;
            case MotionEvent.ACTION_CANCEL:
                fingerMode=0;inputX=inputZ=0;return true;
        }
        return true;
    }
    @Override public void doFrame(long time){
        if(!active)return;
        if(board!=null){
            successfulAppFrames++;
            if(successfulAppFrames==90)prefs().edit().putBoolean("graphics_boot_pending",false).apply();
            if(successfulAppFrames%180==0)saveGraphicsReport();
        }
        float dt=previousFrame==0?1f/60f:Math.min(.05f,(time-previousFrame)*1e-9f);previousFrame=time;
        if(music!=null){music.scene(selectedVolume,mode==PLAY||mode==PAUSE||mode==WIN);music.duck(mode==PAUSE);}
        if(mode==PLAY&&physics!=null){
            if(tiltEnabled&&!keyboardOnlySession&&!keyboardSteering.anyHeld()){
                if(!tilt.ready()){
                    showTiltCentre();Choreographer.getInstance().postFrameCallback(this);return;
                }
                // Use rendered camera yaw each frame, including animated rotations.
                inputX=fingerMode==2||fingerMode==3?0:worldX(tilt.x(),tilt.y());
                inputZ=fingerMode==2||fingerMode==3?0:worldZ(tilt.x(),tilt.y());
            }
            // Keyboard takes precedence only while a directional key is down. In touch mode
            // the drag input is retained and becomes active again when the keys are released.
            float steerX=inputX,steerZ=inputZ;
            if(keyboardSteering.anyHeld()){
                // Keys move relative to the current view, even during camera rotation.
                steerX=worldX(keyboardSteering.screenX(),keyboardSteering.screenY());
                steerZ=worldZ(keyboardSteering.screenX(),keyboardSteering.screenY());
            }else if(keyboardOnlySession){
                steerX=fingerMode==1?inputX:0;
                steerZ=fingerMode==1?inputZ:0;
            }
            accumulator=Math.min(.08f,accumulator+dt);
            while(accumulator>=1f/60f){
                renderPreviousX=physics.x;renderPreviousZ=physics.z;
                physics.step(1f/60f,steerX,steerZ); // All input sources use the same physics/colliders.
                accumulator-=1f/60f;
            }
            if(physics.justCrashed){
                renderPreviousX=physics.x;renderPreviousZ=physics.z;
                board.resetBallPose(physics.x,physics.z);
            }
            float alpha=accumulator*60f;
            float visualX=physics.finished?physics.x:renderPreviousX+(physics.x-renderPreviousX)*alpha;
            float visualZ=physics.finished?physics.z:renderPreviousZ+(physics.z-renderPreviousZ)*alpha;
            board.updateBall(visualX,visualZ,physics.finished,dt);
            board.updateMovingWalls(physics);
            if(timerText!=null)timerText.setText(time(Math.round(physics.seconds*1000)));
            if(crashText!=null)crashText.setText("BEST  "+recordLabel(level)+"   ·   RESETS "+physics.crashes);
            if(physics.justCrashed){
                inputX=inputZ=gestureVX=gestureVY=0;
                if(hintText!=null)hintText.setText("WALL CONTACT — RESET");
                resetHintUntil=android.os.SystemClock.uptimeMillis()+1050L;
                sound(impactSfx);haptic(android.view.HapticFeedbackConstants.LONG_PRESS);
                physics.justCrashed=false;
            }
            if(resetHintUntil>0L&&android.os.SystemClock.uptimeMillis()>=resetHintUntil){
                resetHintUntil=0L;
                if(hintText!=null)hintText.setText(steeringHint());
            }
            if(physics.finished)showWin();
        }else if(mode==WIN&&physics!=null)board.updateBall(physics.x,physics.z,true,dt);
        Choreographer.getInstance().postFrameCallback(this);
    }
    @Override protected void onResume(){super.onResume();active=true;previousFrame=0;
        if(music!=null)music.resume();
        if(tiltEnabled&&!tilt.start())tiltEnabled=false;
        if(board!=null)board.setRunning(true);Choreographer.getInstance().postFrameCallback(this);}
    @Override protected void onPause(){
        if(music!=null)music.suspend();
        if(tilt!=null)tilt.stop();keyboardSteering.clear();inputX=inputZ=gestureVX=gestureVY=0;fingerMode=0;
        if(mode==PLAY&&physics!=null){mode=PAUSE;physics.stop();showPause();}
        active=false;Choreographer.getInstance().removeFrameCallback(this);
        if(board!=null)board.setRunning(false);super.onPause();}
    @Override protected void onDestroy(){if(tilt!=null)tilt.stop();if(board!=null)board.dispose();if(pool!=null)pool.release();if(music!=null)music.dispose();super.onDestroy();}
    @Override public void onBackPressed(){if(mode==PLAY){mode=PAUSE;physics.stop();showPause();}
        else if(mode==PAUSE){resumeRun();}else showMenu();}
}
