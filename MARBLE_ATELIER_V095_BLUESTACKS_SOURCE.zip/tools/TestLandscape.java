import com.atelier.marble.AlpineLandscape;

public class TestLandscape {
    static void yes(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        for(float clearance:new float[]{8,11,15}){
            AlpineLandscape.Geometry g=AlpineLandscape.build(clearance);
            int count=g.positions.length/3;yes(count<65536,"16-bit vertex limit");
            for(int i:g.indices)yes(i>=0&&i<count,"invalid mesh index");
            for(int i=0;i<count;i++){
                float x=g.positions[i*3],y=g.positions[i*3+1],z=g.positions[i*3+2];
                yes(Float.isFinite(x)&&Float.isFinite(y)&&Float.isFinite(z),"non-finite terrain");
                if(Math.hypot(x,z)<=clearance)yes(y<-7.6f,"scenery intersects play footprint");
                float nx=g.normals[i*3],ny=g.normals[i*3+1],nz=g.normals[i*3+2];
                yes(Math.abs(nx*nx+ny*ny+nz*nz-1)<.0001f&&ny>0,"terrain normal invalid");
            }
            yes(AlpineLandscape.height(-7,-46,clearance)>8,"distant mountain ridge missing");
            yes(AlpineLandscape.height(0,0,clearance)<-7.7f,"lake basin missing");
            for(int i=0;i<g.indices.length;i+=3){
                int a=g.indices[i]*3,b=g.indices[i+1]*3,c=g.indices[i+2]*3;
                float ay=(g.positions[b+2]-g.positions[a+2])*(g.positions[c]-g.positions[a])-
                         (g.positions[b]-g.positions[a])*(g.positions[c+2]-g.positions[a+2]);
                yes(ay>0,"inverted terrain face");
            }
        }
        System.out.println("PASS landscape: lake basin, mountain ridge, play clearance, winding, unit normals and 16-bit mesh limits");
    }
}
