#!/usr/bin/env python3
"""V0.4.3 visual-quality regression contracts: static checks, not GPU claims."""
from pathlib import Path
import struct
import re
root=Path(__file__).resolve().parents[1]
fil=(root/'app/src/main/java/com/atelier/marble/FilamentBoard.java').read_text()
main=(root/'app/src/main/java/com/atelier/marble/MainActivity.java').read_text()
physics=(root/'app/src/main/java/com/atelier/marble/MarblePhysics.java').read_text()
assert 'addChamferedWallBatch(walls,wall)' in fil
assert 'emitFace(' in fil and 'float bevel=' in fil
assert 'scene.setSkybox(skybox)' in fil
assert 'camera.setProjection(46.0' in fil
assert 'addChamferedWallBatch(base,podium)' in fil
assert 'addBoxBatch(edgeBands,chassisInset)' in fil
assert 'public boolean controlsLocked(){return false;}' in fil
assert 'physics.inspect(1f/60f)' not in main
assert 'resetHintUntil=' in main and 'android.os.SystemClock.uptimeMillis()>=resetHintUntil' in main
assert 'new MarblePhysics(level)' in fil and 'currentLevel=game' in fil
assert 'walls.remove(' not in fil
assert 'LEVEL_COUNT = LevelBlueprints.COUNT' in physics and 'COUNT = 20' in (root/'app/src/main/java/com/atelier/marble/LevelBlueprints.java').read_text()
folder=root/'app/src/main/assets/materials'
for key in ('obsidian','industrial','ivory','frost','ember','celestial','aurora'):
 for kind in ('floor','wall'):
  for layer in ('albedo','normalrough'):
   raw=(folder/f'{key}_{kind}_{layer}.png').read_bytes()
   assert raw[:8] == b'\x89PNG\r\n\x1a\n'
   w,h=struct.unpack_from('>II',raw,16)
   assert (w,h)==(512,512), (key,kind,layer,w,h)
for key in ('chrome','glacier','gold','obsidian','pearl','copper','neon','nebula'):
 for role in ('albedo','normalrough'):
  raw=(folder/'balls'/f'{key}_{role}.png').read_bytes()
  assert raw[:8] == b'\x89PNG\r\n\x1a\n'
  w,h=struct.unpack_from('>II',raw,16)
  assert w>=128 and h>=128
assert len(set((folder/f'{key}_floor_albedo.png').read_bytes()[:400] for key in ('obsidian','industrial','ivory','frost','ember','celestial','aurora')))==7
# 9 visible chamfered faces * 4 vertices each, < USHORT vertex limit per batch.
assert 700*21*4 < 65535
print('PASS visual regression: persistent visible bevelled walls, new manufactured perimeter chassis and cliffside sanctuary, camera and lighting revision')
print('PASS 28 environment maps at 512x512 and 16 marble maps; twenty fixed levels')
print('PASS transient reset-message clearing, no wall-hiding logic')
print('NOTE: only GitHub Android compile + real-device inspection can verify Filament output')
