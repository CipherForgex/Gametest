#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -encoding UTF-8 -d "$out" app/src/main/java/com/atelier/marble/{ControlMath,KeyboardSteering}.java tools/TestKeyboardSteering.java
java -cp "$out" TestKeyboardSteering
python3 tools/test_keyboard_contract.py
