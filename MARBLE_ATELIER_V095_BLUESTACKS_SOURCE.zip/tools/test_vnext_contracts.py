#!/usr/bin/env python3
"""Regression contracts independent of Android SDK, not simulated visual proof."""
from pathlib import Path
import hashlib
import struct
root=Path(__file__).resolve().parents[1]
code=(root/'app/src/main/java/com/atelier/marble/FilamentBoard.java').read_text()
ui=(root/'app/src/main/java/com/atelier/marble/MainActivity.java').read_text()
assert 'public boolean controlsLocked(){return false;}' in code
assert 'physics.step(1f/60f,steerX,steerZ)' in ui and 'physics.inspect(1f/60f)' not in ui
assert 'addChamferedWallBatch(base,podium)' in code
assert 'addBoxBatch(edgeBands,chassisInset)' in code
assert 'addBoxBatch(edgePins,podiumEdge)' in code
assert 'buildSanctuary(game,span)' in code
assert 'studioBackdrop=texturedPaint(' not in code
assert 'chassisInset=paint(0x111A23,.62f,.51f)' in code
assert 'view.setAntiAliasing(View.AntiAliasing.FXAA)' in code
assert 'camera.setProjection(46.0,aspect,0.28,140.0' in code
assert 'p.getInt("theme",0)' in ui and 'p.getInt("skin",4)' in ui
rootdir=root/'app/src/main/assets/materials'
for key in ('ivory','obsidian','frost','ember','industrial','celestial','aurora'):
    f=(rootdir/(key+'_floor_albedo.png')).read_bytes()
    w=(rootdir/(key+'_wall_albedo.png')).read_bytes()
    assert hashlib.sha256(f).digest()!=hashlib.sha256(w).digest()
    for kind in ('floor','wall'):
        d=(rootdir/(key+'_'+kind+'_normalrough.png')).read_bytes()
        assert d[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',d,16)==(512,512)
for ball in ('chrome','glacier','gold','obsidian','pearl','copper','neon','nebula'):
    for layer in ('albedo','normalrough'):
        d=(rootdir/'balls'/(ball+'_'+layer+'.png')).read_bytes()
        assert d[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',d,16)==(512,512)
print('PASS VNext: input routing, sanctuary scene, layered chassis, mobile AA, material contrast, 44 assets')
print('NOTE: Headless source+texture check; real Android render and GPU quality still unverified')
