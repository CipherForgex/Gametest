import com.atelier.marble.ControlMath;
import java.lang.reflect.*;

/** Runs on Java 17 without Android SDK; exercises the actual production key state class. */
public class TestKeyboardSteering {
    private static void expect(boolean result,String label){if(!result)throw new AssertionError(label);}
    private static void eq(float actual,float target,String label){expect(Math.abs(actual-target)<0.0001f,label+": "+actual+" vs "+target);}
    public static void main(String[] args)throws Exception{
        Class<?> c=Class.forName("com.atelier.marble.KeyboardSteering");
        Constructor<?> ctor=c.getDeclaredConstructor();ctor.setAccessible(true);
        Object k=ctor.newInstance();
        Method set=c.getDeclaredMethod("setHeld",int.class,boolean.class);
        Method x=c.getDeclaredMethod("screenX"),y=c.getDeclaredMethod("screenY"),active=c.getDeclaredMethod("anyHeld"),clear=c.getDeclaredMethod("clear");
        for(Method m:new Method[]{set,x,y,active,clear})m.setAccessible(true);
        // W/A/S/D: up = negative screen Y, left = negative screen X.
        set.invoke(k,1,true);eq((float)y.invoke(k),-1,"W up");eq((float)x.invoke(k),0,"W no horizontal");
        set.invoke(k,8,true);eq((float)x.invoke(k),.70710678f,"W+D diagonal X");eq((float)y.invoke(k),-.70710678f,"W+D diagonal Y");
        float rx=ControlMath.worldX((float)x.invoke(k),(float)y.invoke(k),(float)Math.PI/2);
        float rz=ControlMath.worldZ((float)x.invoke(k),(float)y.invoke(k),(float)Math.PI/2);
        eq((float)Math.hypot(rx,rz),1,"Camera rotation preserves diagonal speed");
        set.invoke(k,8,true);set.invoke(k,8,false);eq((float)y.invoke(k),-1,"Auto repeat then release doesn't stick");
        set.invoke(k,16,true);set.invoke(k,1,false);eq((float)y.invoke(k),-1,"Arrow up remains held after W release");
        set.invoke(k,64,true);eq((float)y.invoke(k),0,"Opposing up/down cancel");
        set.invoke(k,16,false);eq((float)y.invoke(k),1,"Down resumes after up released");
        set.invoke(k,2,true);eq((float)x.invoke(k),-0.70710678f,"A+Down diagonal X");
        set.invoke(k,0,true);set.invoke(k,255,true);eq((float)x.invoke(k),-0.70710678f,"Ignore invalid masks");
        clear.invoke(k);expect(!(boolean)active.invoke(k),"Clear held keys on focus loss/pause");
        eq((float)x.invoke(k),0,"No horizontal after clear");eq((float)y.invoke(k),0,"No vertical after clear");
        System.out.println("PASS WASD, arrow keys, simultaneous holds, diagonal speed, camera transform, key repeat and clear");
    }
}
