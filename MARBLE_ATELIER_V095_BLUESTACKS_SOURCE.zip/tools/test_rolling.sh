#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -encoding UTF-8 -d "$out" app/src/main/java/com/atelier/marble/RollingOrientation.java tools/TestRolling.java
java -cp "$out" TestRolling

# The existing GitHub workflow runs this entry point; also verify tilt steering.
bash tools/test_tilt.sh
