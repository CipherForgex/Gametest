#!/usr/bin/env python3
"""Original offline compositions for Marble Atelier. Requires numpy and ffmpeg.
No sampled songs or third-party audio. Circular note tails / reverb form musical loops.
"""
from pathlib import Path
import numpy as np,math,wave,subprocess,json,tempfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'app/src/main/assets/music';OUT.mkdir(exist_ok=True)
RATE=22050
# Authored chord progressions, voicings and melodies (MIDI pitches).
SANC_CHORDS=[[50,54,57],[47,50,54],[43,47,50],[45,49,52],[50,54,57],[42,45,49],[43,47,50],[45,50,52]]*2
SANC_MELODY=[74,73,71,69,66,69,71,73,74,78,76,74,71,69,66,69]
AUR_CHORDS=[[52,55,59],[48,52,55],[55,59,62],[50,54,57],[52,55,59],[48,55,59],[45,52,55],[50,54,59]]*2
AUR_MELODY=[83,81,79,78,76,79,81,83,86,83,81,79,78,76,74,78]
def frequency(note):return 440*2**((note-69)/12)
def voice(note,duration,kind,seed):
 t=np.arange(round(duration*RATE))/RATE;f=frequency(note)
 if kind=='piano':
  tone=sum((1/h**1.9)*np.sin(2*np.pi*f*h*(1+.00007*h*h)*t)*np.exp(-t*(.65+h*.22))for h in range(1,8))
  env=(1-np.exp(-t/.006))*np.minimum(1,(duration-t)/.15)
 elif kind=='bell':
  tone=sum(a*np.sin(2*np.pi*f*r*t)*np.exp(-t*d)for r,a,d in [(1,1,.65),(2,.25,1.1),(2.76,.11,1.8),(4.07,.045,2.8)])
  env=(1-np.exp(-t/.003))*np.minimum(1,(duration-t)/.18)
 elif kind=='pad':
  tone=(np.sin(2*np.pi*f*t)+.24*np.sin(2*np.pi*f*2*t)+.15*np.sin(2*np.pi*f*1.003*t))*.55
  env=np.sin(np.pi*np.minimum(1,t/duration))**1.8
 else:
  tone=np.sin(2*np.pi*f*t)+.15*np.sin(2*np.pi*f*2*t);env=(1-np.exp(-t/.03))*np.exp(-t*4)*np.minimum(1,(duration-t)/.12)
 return tone*np.maximum(0,env)
def compose(name,bpm,gameplay,arctic):
 beat=60/bpm;length=64*beat;n=round(length*RATE);audio=np.zeros((n,2),np.float64)
 chords=AUR_CHORDS if arctic else SANC_CHORDS;melody=AUR_MELODY if arctic else SANC_MELODY
 def add(note,at,duration,kind,amp,pan=0):
  a=voice(note,duration,kind,note);idx=(np.arange(len(a))+round(at*RATE))%n
  l=math.sqrt((1-pan)/2);r=math.sqrt((1+pan)/2)
  np.add.at(audio[:,0],idx,a*amp*l);np.add.at(audio[:,1],idx,a*amp*r)
 for bar,chord in enumerate(chords):
  start=bar*4*beat
  for j,note in enumerate(chord):add(note,start,6*beat,'pad',.032 if gameplay else .045,(j-1)*.38)
  add(chord[0]-12,start,3.5*beat,'pad',.045,0)
  for j in range(4):
   pitch=chord[[0,1,2,1][j]]+12
   add(pitch,start+(j*.9+.15)*beat,2.8*beat,'bell'if arctic else'piano',.036 if gameplay else .066,(-1 if j%2 else 1)*.22)
  if not gameplay or bar%2==0:
   add(melody[bar],start+.4*beat,3.6*beat,'bell'if arctic else'piano',.047 if gameplay else .095,.10)
  if arctic and gameplay:
   for j in [0,2]:add(chord[0]-12,start+j*beat,.8*beat,'pulse',.030)
 # Circular stereo echo: tails from the end naturally continue at the beginning.
 dry=audio.copy()
 for delay,gain in [(0.17,.16),(.37,.13),(.69,.09),(1.07,.07),(1.73,.05)]:
  shift=round(delay*RATE);audio+=np.roll(dry[:,::-1],shift,axis=0)*gain
 # Soft saturation and a consistent quiet mastered peak, with ample headroom for SFX.
 audio=np.tanh(audio*1.8);audio*=(.42 if gameplay else .58)/(np.max(np.abs(audio))+1e-8)
 tmp=Path(tempfile.gettempdir())/('marble_music_'+name+'.wav');pcm=(np.clip(audio,-1,1)*32767).astype('<i2')
 with wave.open(str(tmp),'wb')as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(RATE);f.writeframes(pcm.tobytes())
 target=OUT/(name+'.ogg')
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(tmp),'-c:a','libvorbis','-q:a','4','-metadata','title='+name.replace('_',' ').title(),'-metadata','artist=Marble Atelier original composition',str(target)],check=True)
 tmp.unlink()
 print(name,round(length,2),'seconds','RMS',round(float(np.sqrt(np.mean(audio**2))),4),'peak',round(float(np.max(np.abs(audio))),3))
 return dict(file=name+'.ogg',bpm=bpm,seconds=length,composition='original authored chord progression and melody',loop_beats=64)
tracks=[compose('sanctuary_menu',68,False,False),compose('sanctuary_game',68,True,False),compose('aurora_menu',72,False,True),compose('aurora_game',72,True,True)]
(OUT/'CREDITS.json').write_text(json.dumps({'license':'Original Marble Atelier project audio; no third-party recordings or samples.','tracks':tracks},indent=2))
