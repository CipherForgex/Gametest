#!/usr/bin/env python3
"""Android key routing/lifecycle contract, not a substitute for an emulator test."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/atelier/marble/MainActivity.java').read_text()
assert 'import android.view.KeyEvent;' in s
assert '@Override public boolean dispatchKeyEvent(KeyEvent event)' in s
assert 'mode!=PLAY' in s
assert all('KeyEvent.KEYCODE_'+k in s for k in ('W','A','S','D','DPAD_UP','DPAD_LEFT','DPAD_DOWN','DPAD_RIGHT'))
assert 'worldX(keyboardSteering.screenX(),keyboardSteering.screenY())' in s
assert 'worldZ(keyboardSteering.screenX(),keyboardSteering.screenY())' in s
assert 'physics.step(1f/60f,steerX,steerZ)' in s
assert 'if(tiltEnabled&&!keyboardOnlySession&&!keyboardSteering.anyHeld())' in s
assert 'keyboardOnlySession=true;awaitingTiltCentre=false;' in s
assert 'fingerMode==1&&(!tiltEnabled||keyboardOnlySession)' in s
assert 'onWindowFocusChanged(boolean hasFocus)' in s
assert 'keyboardSteering.clear();' in s
assert 'new EditText' not in s and 'InputMethodManager' not in s
assert 'noCompress' in (p/'app/build.gradle').read_text()
print('PASS physical-key routing, camera-relative physics, tilt override, pause/focus release, no keyboard UI')
