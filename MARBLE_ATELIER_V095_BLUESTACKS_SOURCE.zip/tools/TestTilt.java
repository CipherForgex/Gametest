import com.atelier.marble.TiltMath;
import com.atelier.marble.ControlMath;
public class TestTilt {
 static final float RANGE=(float)Math.toRadians(25);
 static void require(boolean ok,String why){if(!ok)throw new AssertionError(why);}
 static void near(float a,float b,float tolerance,String why){require(Math.abs(a-b)<tolerance,why+": "+a+" vs "+b);}
 static void feed(TiltMath m,float roll,float pitch,float dt){
   m.update(-(float)Math.sin(roll),(float)(Math.cos(roll)*Math.sin(pitch)),(float)(Math.cos(roll)*Math.cos(pitch)),dt,RANGE,.03f);
 }
 static void settle(TiltMath m,float roll,float pitch){for(int i=0;i<200;i++)feed(m,roll,pitch,.02f);}
 public static void main(String[] a){
   TiltMath m=new TiltMath();feed(m,.2f,.2f,.02f);require(m.x==0&&m.y==0,"uncalibrated output suppressed");
   m.centre(0,(float)Math.sin(.6),(float)Math.cos(.6));settle(m,0,.6f);require(m.x==0&&m.y==0,"comfortable grip neutral");
   m.centre(0,0,1);settle(m,RANGE*.029f,0);require(m.x==0&&m.y==0,"3 percent dead zone");
   settle(m,RANGE*.031f,0);require(m.x>0&&m.x<.001f,"continuous threshold");
   float previous=0;
   for(float amount:new float[]{.05f,.1f,.25f,.5f,.75f,1f}){settle(m,RANGE*amount,0);require(m.x>previous,"more tilt gives more force");previous=m.x;}
   near(m.x,1,.0001f,"full force at full tilt");
   settle(m,-RANGE,0);near(m.x,-1,.0001f,"opposite tilt brakes/reverses");
   settle(m,RANGE,RANGE);near((float)Math.hypot(m.x,m.y),1,.0001f,"diagonal speed normalisation");
   m.centre(0,0,1);settle(m,RANGE*.02f,RANGE*.02f);require(m.x==0&&m.y==0,"radial dead zone includes diagonal jitter");
   settle(m,RANGE*.025f,RANGE*.025f);require(m.x>0&&m.y>0,"radial dead zone boundary");
   m.centre(0,0,1);feed(m,RANGE,0,.02f);require(m.x>0&&m.x<.2f,"smoothed onset");
   settle(m,RANGE,0);settle(m,0,0);require(m.x==0&&m.y==0,"neutral force returns to zero");
   TiltMath n=new TiltMath();m.centre(0,0,1);n.centre(0,0,1);
   for(int i=0;i<50;i++)feed(m,RANGE*.5f,0,.02f);
   for(int i=0;i<100;i++)feed(n,RANGE*.5f,0,.01f);
   near(m.x,n.x,.00001f,"time-based smoothing independent of sensor frequency");
   near(ControlMath.worldX(1,0,(float)(Math.PI/2)),0,.0001f,"camera 90 X");
   near(ControlMath.worldZ(1,0,(float)(Math.PI/2)),-1,.0001f,"camera 90 Z");
   m.reset();require(!m.isCalibrated()&&m.x==0&&m.y==0,"lifecycle reset clears force and calibration");
   System.out.println("PASS tilt: neutral grip, 3% radial dead zone, threshold continuity, progressive force, reverse, cap, smoothing, sample-rate independence, camera mapping, lifecycle reset");
 }
}
