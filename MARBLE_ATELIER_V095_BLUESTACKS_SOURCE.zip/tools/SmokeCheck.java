import com.atelier.marble.MarblePhysics;
import com.atelier.marble.ControlMath;
import com.atelier.marble.LevelBlueprints;
import com.atelier.marble.Volumes;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Offline contract checks against the exact Java physics source shipped in the APK. */
public class SmokeCheck {
    static void yes(boolean condition,String info){if(!condition)throw new AssertionError(info);}
    static final int[] DX={1,0,-1,0},DZ={0,1,0,-1};
    static int routeLength(MarblePhysics p){
        int sx=p.cellCol(p.startX),sz=p.cellRow(p.startZ);
        int[][] dist=new int[p.cols][p.rows];
        for(int[] v:dist)Arrays.fill(v,-1);
        dist[sx][sz]=0;ArrayDeque<int[]> q=new ArrayDeque<>();q.add(new int[]{sx,sz});
        int reachable=0;
        while(!q.isEmpty()){
            int[] a=q.poll();int x=a[0],z=a[1];reachable++;
            for(int d=0;d<4;d++)if((p.openingBits(x,z)&(1<<d))!=0){
                int nx=x+DX[d],nz=z+DZ[d];
                yes(p.isCell(nx,nz),"opening outside visible board at level "+p.level);
                yes((p.openingBits(nx,nz)&(1<<((d+2)%4)))!=0,"nonreciprocal opening");
                if(dist[nx][nz]<0){dist[nx][nz]=dist[x][z]+1;q.add(new int[]{nx,nz});}
            }
        }
        int count=0;for(int x=0;x<p.cols;x++)for(int z=0;z<p.rows;z++)if(p.isCell(x,z))count++;
        yes(reachable==count,"disconnected maze "+p.level);
        int gx=p.cellCol(p.goalX),gz=p.cellRow(p.goalZ);
        yes(dist[gx][gz]>0,"goal cannot be reached in level "+p.level);
        return dist[gx][gz];
    }
    static void verifyOpenDoors(MarblePhysics p){
        // Centreline of every logical opening must be physically traversable.
        for(int x=0;x<p.cols;x++)for(int z=0;z<p.rows;z++)if(p.isCell(x,z)){
            for(int d=0;d<4;d++)if((p.openingBits(x,z)&(1<<d))!=0){
                for(int k=0;k<=24;k++){
                    float t=k/24f;
                    p.x=p.centerX(x)+DX[d]*p.cellSize*t;
                    p.z=p.centerZ(z)+DZ[d]*p.cellSize*t;
                    yes(p.isCell(p.cellCol(p.x),p.cellRow(p.z)),"open corridor leaves board");
                    for(MarblePhysics.Obstacle o:p.obstacles)if(!o.moving)
                        yes(!p.touches(o,0),"INVISIBLE WALL: blocked authored passage at level "+p.level+" ["+x+","+z+"] d="+d);
                }
            }
        }
    }
    static void verifyFlick(MarblePhysics p){
        p.resetAll();float x=p.x,z=p.z;
        p.flick(20f,20f);
        yes(p.x==x&&p.z==z,"flick teleported ball");
        yes(Math.hypot(p.vx,p.vz)<=p.maxSpeed()+.0001,"flick exceeded velocity cap");
        p.step(1f/60f,0,0);
        yes(Math.hypot(p.x-x,p.z-z)<=p.maxSpeed()/60+.001,"flick jumped farther than step physics");
    }
    static void verifySlidingGates(MarblePhysics p){
        for(MarblePhysics.Obstacle gate : p.movingObstacles){
            // A sliding wall must actually make contact at its central position,
            // then retract far enough for a ball on the corridor centreline.
            yes(gate.moving, "hazard must animate");
            float originalX=p.x,originalZ=p.z;
            p.x=gate.x;p.z=gate.z;
            float centreTime=(float)((Math.PI*2-gate.phase)/gate.speed);
            yes(p.touches(gate,centreTime),"moving gate does not close");
            float openTime=(float)((Math.PI/2-gate.phase)/gate.speed);
            yes(!p.touches(gate,openTime),"sliding gate never clears full ball radius at level "+p.level);
            p.x=originalX;p.z=originalZ;
        }
    }
    static void verifyWorldBoundaries(MarblePhysics p){
        p.resetAll();
        p.x=p.halfWidth+p.cellSize;p.z=p.startZ;
        yes(p.hitsAnything(0),"ball escaped board on x boundary");
        p.x=p.startX;p.z=-p.halfLength-p.cellSize;
        yes(p.hitsAnything(0),"ball escaped board on z boundary");
        p.resetAll();
    }
    static void verifyControlsAfterReset(MarblePhysics p){
        p.resetAll();p.flick(.7f,.4f);
        MarblePhysics.Obstacle obstacle=p.obstacles.get(0);
        p.x=obstacle.x;p.z=obstacle.z;
        p.step(1f/60f,0f,0f);
        yes(p.justCrashed&&p.x==p.startX&&p.z==p.startZ, "reset did not restore spawn");
        yes(p.vx==0f&&p.vz==0f&&p.seconds==0f,"velocity or timer survived reset");
        p.resetAll();
    }
    static void verifyOverhead(MarblePhysics p){
        p.resetAll();p.vx=1.8f;p.vz=.6f;float x=p.x,z=p.z;
        for(int i=0;i<120;i++)p.inspect(1f/60f);
        yes(p.x==x&&p.z==z&&p.vx==0&&p.vz==0,"overhead allowed ball movement");
        yes(p.seconds>1.9f,"overhead must not pause timer");
    }
    public static void main(String[] args){
        yes(MarblePhysics.LEVEL_COUNT==20,"twenty levels across two volumes");
        yes(LevelBlueprints.MAPS.length==20,"twenty blueprints");
        yes(Volumes.start(0)==1&&Volumes.end(0)==10&&Volumes.start(1)==11&&Volumes.end(1)==20,"volume boundaries");
        yes(Volumes.next(10)==10&&Volumes.next(20)==20&&Volumes.next(11)==12,"next escapes volume");
        yes(!Volumes.progressKey(0).equals(Volumes.progressKey(1)),"progress collision");
        yes(Volumes.progressKey(0).equals("v04_progress"),"existing Sanctuary progress changed");
        yes(Volumes.continuation(1,1)==11&&Volumes.continuation(1,99)==20&&Volumes.continuation(0,99)==10,"corrupt saved progress clamp");
        for(int i=1;i<=20;i++)yes(LevelBlueprints.volumeOf(i)==(i-1)/10&&LevelBlueprints.chapterOf(i)==(i-1)%10+1,"chapter display");
        Set<String> names=new HashSet<>(),maps=new HashSet<>();
        int previous=0,totalWalls=0,totalMoving=0,totalRamps=0;
        for(int i=1;i<=20;i++){
            if(i==11)previous=0;
            MarblePhysics p=new MarblePhysics(i);
            yes(names.add(p.shapeName()),"all twenty map names must differ");
            yes(p.isSpawnClear(),"spawn overlapping fatal collider on level "+i);
            yes(p.corridorClearance()>.0f,"marble cannot fit level "+i);
            yes(Integer.bitCount(p.openingBits(p.cellCol(p.startX),p.cellRow(p.startZ)))==1,"start chamber not one exit");
            int len=routeLength(p);
            yes(len>previous,"difficulty route distance must grow each level, "+i+": "+len+" <= "+previous);
            previous=len;
            verifyOpenDoors(p);
            StringBuilder sig=new StringBuilder();
            for(int z=0;z<p.rows;z++)for(int x=0;x<p.cols;x++)sig.append(p.isCell(x,z)?Integer.toHexString(p.openingBits(x,z)):".");
            yes(maps.add(sig.toString()),"duplicate maze layout "+i);
            totalWalls+=p.wallCount();totalMoving+=p.movingObstacles.size();
            for(int x=0;x<p.cols;x++)for(int z=0;z<p.rows;z++)if(p.rampDirection(x,z)!=0)totalRamps++;
            verifyFlick(p);verifyOverhead(p);verifySlidingGates(p);
            verifyWorldBoundaries(p);verifyControlsAfterReset(p);
            p.resetAll();
            MarblePhysics.Obstacle first=p.obstacles.get(0);
            p.x=first.x;p.z=first.z;p.step(1f/60f,0,0);
            yes(p.justCrashed&&p.crashes==1,"wall collision failed "+i);
            yes(p.x==p.startX&&p.z==p.startZ&&p.seconds==0,"reset failed "+i);
            p.resetAll();p.x=p.goalX;p.z=p.goalZ;p.step(1f/60f,0,0);
            yes(p.finished,"goal detection failed "+i);
            float elapsed=p.seconds;p.step(1f/60f,0,0);yes(elapsed==p.seconds,"finished timer continues");
            System.out.println("PASS level "+i+" "+p.shapeName()+" route="+len+" clearance="+p.corridorClearance()+" hazards="+p.movingObstacles.size());
        }
        yes(totalMoving>=20,"multiple moving hazards need testing");
        yes(totalRamps>=8,"late maze ramps missing");
        for(int i=0;i<=16;i++){
            float yaw=(float)(i*Math.PI/8),x=ControlMath.worldX(.7f,-.3f,yaw),
                z=ControlMath.worldZ(.7f,-.3f,yaw);
            yes(Math.abs(Math.hypot(x,z)-Math.hypot(.7,-.3))<.00001,"rotation alters input strength");
            yes(Math.abs(ControlMath.worldX(.7f,-.3f,yaw+(float)(Math.PI*2))-x)<.00001,"360 degree mapping regression");
        }
        System.out.println("PASS twenty unique solvable blueprints across two volumes, no invisible fixed colliders across every opening; " +
            "strictly increasing solution distance; "+totalWalls+" rendered wall colliders, "+totalMoving+
            " moving hazards, "+totalRamps+" ramps; flick / overhead / restart / goal / camera maths");
    }
}
