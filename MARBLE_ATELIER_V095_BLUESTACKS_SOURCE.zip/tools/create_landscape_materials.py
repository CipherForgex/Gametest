#!/usr/bin/env python3
"""Original seamless terrain grain and restrained lake ripple maps."""
from pathlib import Path
import numpy as np
from PIL import Image
out=Path(__file__).resolve().parents[1]/'app/src/main/assets/landscape';out.mkdir(exist_ok=True)
n=512;rng=np.random.default_rng(6249);y,x=np.mgrid[0:n,0:n]/n
frequency=np.fft.fftfreq(n);fy,fx=np.meshgrid(frequency,frequency,indexing='ij')
radius=np.sqrt(fx*fx+fy*fy);radius[0,0]=1
field=np.fft.ifft2(np.fft.fft2(rng.normal(size=(n,n)))/radius**1.5).real
field=(field-field.mean())/field.std();grain=rng.normal(size=(n,n))
color=np.array([91,94,82])+field[:,:,None]*8+grain[:,:,None]*2
rough=np.clip(205+field*10+grain*3,170,240)
h=field*.6+grain*.025;dx=(np.roll(h,-1,axis=1)-np.roll(h,1,axis=1))*.09;dy=(np.roll(h,-1,axis=0)-np.roll(h,1,axis=0))*.09
normal=np.stack([-dx,-dy,np.ones_like(dx)],axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
packed=np.concatenate([(normal*.5+.5)*255,rough[:,:,None]],axis=2)
Image.fromarray(np.clip(color,0,255).astype('uint8')).save(out/'terrain_albedo.png',optimize=True)
Image.fromarray(np.clip(packed,0,255).astype('uint8')).save(out/'terrain_normalrough.png',optimize=True)
ripple=np.sin(2*np.pi*(x*9+y*3))*.7+np.sin(2*np.pi*(x*5-y*11))*.3
water=np.array([44,54,58])+ripple[:,:,None]*1.5
nx=np.cos(2*np.pi*(x*9+y*3))*.055+np.cos(2*np.pi*(x*5-y*11))*.024
ny=np.cos(2*np.pi*(x*9+y*3))*.018-np.cos(2*np.pi*(x*5-y*11))*.052
normal=np.stack([nx,ny,np.ones_like(nx)],axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
packed=np.concatenate([(normal*.5+.5)*255,(85+ripple*5)[:,:,None]],axis=2)
Image.fromarray(np.clip(water,0,255).astype('uint8')).save(out/'water_albedo.png',optimize=True)
Image.fromarray(np.clip(packed,0,255).astype('uint8')).save(out/'water_normalrough.png',optimize=True)
print('PASS four original terrain and water maps')
