#!/usr/bin/env python3
"""Aurora pale stone mobile maps, derived from the bundled CC0 white marble."""
from pathlib import Path
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parents[1];src=root/'tools/source_materials';out=root/'app/src/main/assets/materials'
base=np.array(Image.open(next(src.glob('white_marble_albedo.*'))).convert('RGB').resize((512,512))).astype(float)
rough=np.array(Image.open(next(src.glob('white_marble_roughness.*'))).convert('L').resize((512,512))).astype(float)
for kind in ['floor','wall']:
 color=np.clip(base*np.array([.42,.44,.46])+np.array([18,19,20]),0,255)
 if kind=='wall':color=np.clip(color*.91+np.array([22,22,22]),0,255)
 Image.fromarray(color.astype('uint8')).save(out/f'aurora_{kind}_albedo.png',optimize=True)
 packed=np.empty((512,512,4),dtype='uint8');packed[:,:,:3]=[128,128,255];packed[:,:,3]=np.clip(rough*.30+105,90,180)
 Image.fromarray(packed).save(out/f'aurora_{kind}_normalrough.png',optimize=True)
print('PASS Aurora stone maps')
