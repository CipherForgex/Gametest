package com.atelier.marble;

import android.app.Activity;
import android.opengl.Matrix;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.google.android.filament.Texture;
import com.google.android.filament.TextureSampler;
import com.google.android.filament.android.TextureHelper;
import java.io.IOException;
import java.util.Arrays;
import android.view.Choreographer;
import android.view.Surface;
import android.view.SurfaceView;

import com.google.android.filament.Box;
import com.google.android.filament.Camera;
import com.google.android.filament.Colors;
import com.google.android.filament.Engine;
import com.google.android.filament.EntityManager;
import com.google.android.filament.Filament;
import com.google.android.filament.IndexBuffer;
import com.google.android.filament.IndirectLight;
import com.google.android.filament.LightManager;
import com.google.android.filament.Material;
import com.google.android.filament.MaterialInstance;
import com.google.android.filament.MathUtils;
import com.google.android.filament.RenderableManager;
import com.google.android.filament.Renderer;
import com.google.android.filament.Scene;
import com.google.android.filament.Skybox;
import com.google.android.filament.SwapChain;
import com.google.android.filament.VertexBuffer;
import com.google.android.filament.View;
import com.google.android.filament.Viewport;
import com.google.android.filament.android.DisplayHelper;
import com.google.android.filament.android.FilamentHelper;
import com.google.android.filament.android.UiHelper;
import com.google.android.filament.filamat.MaterialBuilder;
import com.google.android.filament.filamat.MaterialPackage;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * Native Filament PBR preview/game board. All engine operations run on the Activity UI thread.
 * Self-contained: generated geometry, runtime-generated Filamat shaders, no external 3D models.
 */
public final class FilamentBoard implements UiHelper.RendererCallback, Choreographer.FrameCallback {
    private final SurfaceView surface;
    private final UiHelper uiHelper;
    private final DisplayHelper displayHelper;
    private final Engine engine;
    private final Renderer renderer;
    private final Scene scene;
    private final View view;
    private final Camera camera;
    private final Texture studioReflection,auroraReflection;
    private final Material material;
    private final Material texturedMaterial;
    private final Material glassMaterial;
    private final Material auroraMaterial;
    private final Activity context;
    private final Texture[][] albedos=new Texture[7][2], details=new Texture[7][2];
    private final Texture[] ballAlbedos=new Texture[8],ballDetails=new Texture[8];
    private final List<Mesh> batchedMeshes=new ArrayList<>();
    // IMPORTANT: TextureSampler creates a native Filament handle. Never construct it in
    // a field initializer: Java executes field initializers BEFORE the constructor body
    // calls Filament.init(), causing UnsatisfiedLinkError: nCreateSampler on Android.
    private final TextureSampler textureSampler;
    private long lastRenderNanos=0;
    private final GraphicsProbe graphicsProbe=new GraphicsProbe();
    public String getGraphicsReport(){return graphicsProbe.report();}
    public String getGraphicsProfileName(){return graphicsProbe.label();}
    public void setGraphicsDisabledMask(int mask){graphicsProbe.setDisabledMask(mask);}
    public int getGraphicsDisabledMask(){return graphicsProbe.disabledMask();}
    public int getGraphicsProfile(){return graphicsProbe.profile();}

    private final IndirectLight ambient,auroraAmbient;
    private final Skybox skybox,auroraSkybox;
    private int sunEntity;
    private final List<Integer> auroraCurtains=new ArrayList<>();
    private final List<BoatVisual> boats=new ArrayList<>();
    private int beaconLight,beaconBeam;
    private float beaconX,beaconY,beaconZ;
    private static final class BoatVisual {
        final int parent;final float x,z,phase;final boolean cruise;
        BoatVisual(int p,float x,float z,float phase,boolean cruise){parent=p;this.x=x;this.z=z;this.phase=phase;this.cruise=cruise;}
    }
    private float atmosphereTime;
    private final List<MaterialInstance> materialInstances = new ArrayList<>();
    private final List<Mesh> meshes = new ArrayList<>();
    private final List<Integer> entities = new ArrayList<>();
    private final List<Integer> lights = new ArrayList<>();
    private final Mesh cube, sphere, torus, cylinder;
    // A separate neutral photographic cyclorama. No theme-derived textures: the playing
    // surface needs a distinct value and color temperature for mobile legibility.
    
    private SwapChain swapChain;
    private int ballEntity,ballRingEntity;
    private final List<MovingVisual> movingPieces=new ArrayList<>();
    private static final class MovingVisual {
        final int entity;final MarblePhysics.Obstacle obstacle;final float height,halfX,halfY,halfZ;
        MovingVisual(int e,MarblePhysics.Obstacle o,float h,float hx,float hy,float hz){
            entity=e;obstacle=o;height=h;halfX=hx;halfY=hy;halfZ=hz;
        }
    }
    private int level = 1;
    private int themeIndex=0, ballSkin=0;
    private boolean overview=false,followBall=true,marblePreview=false;
    private float yaw=0,targetYaw=0,zoom=1.0f,targetZoom=1.0f,overviewBlend=0f,targetOverview=0f;
    private float focusX=0,focusZ=0,panX=0,panZ=0;
    public int getLoadedLevel(){return level;}
    // No fading, visibility assist, or hidden wall entities anywhere in V0.4.
    private MarblePhysics currentLevel;

    private boolean running;
    private boolean disposed;
    private float ballX, ballZ, lastBallX, lastBallZ, sink;
    private final RollingOrientation rolling = new RollingOrientation();

    private static final class Mesh {
        final VertexBuffer vertices;
        final IndexBuffer indices;
        final int indexCount;
        Mesh(VertexBuffer vertices, IndexBuffer indices, int indexCount) {
            this.vertices=vertices; this.indices=indices; this.indexCount=indexCount;
        }
    }

    public FilamentBoard(Activity activity) {
        // Load filament-jni before constructing ANY native-backed Filament objects.
        // This must precede TextureSampler, Engine, Texture.Builder, etc.
        Filament.init();
        textureSampler = new TextureSampler(
            TextureSampler.MinFilter.LINEAR_MIPMAP_LINEAR,
            TextureSampler.MagFilter.LINEAR,
            TextureSampler.WrapMode.REPEAT);
        context=activity;
        surface = new SurfaceView(activity);
        surface.setKeepScreenOn(true);
        displayHelper = new DisplayHelper(activity);
        engine = Engine.create(Engine.Backend.OPENGL);
        renderer = engine.createRenderer();
        scene = engine.createScene();
        view = engine.createView();
        camera = engine.createCamera(EntityManager.get().create());
        view.setScene(scene);
        view.setCamera(camera);
        // Filament built-in free rendering: contact occlusion, antialiasing, and restrained bloom.
        view.setAntiAliasing(View.AntiAliasing.FXAA);
        View.AmbientOcclusionOptions occlusion = new View.AmbientOcclusionOptions();
        occlusion.enabled = true;
        occlusion.radius = .42f;
        occlusion.intensity = 1.20f;
        view.setAmbientOcclusionOptions(occlusion);
        View.BloomOptions bloom = new View.BloomOptions();
        bloom.enabled = true;
        bloom.strength = .09f;
        view.setBloomOptions(bloom);
        // Cinematic effects are independently instrumented and downgrade gracefully.
        // Android settings page can switch between MAX, STUDIO, BALANCED and SAFE.
        graphicsProbe.configure(view, GraphicsProbe.SAFE);
        // A restrained charcoal environment; the stage carries the highlights.
        studioReflection=createStudioReflection(false);
        auroraReflection=createStudioReflection(true);
        auroraSkybox=new Skybox.Builder().environment(auroraReflection).build(engine);
        auroraAmbient=new IndirectLight.Builder().reflections(auroraReflection)
            .irradiance(1,new float[]{.38f,.41f,.47f}).intensity(11500f).build(engine);
        skybox = new Skybox.Builder().environment(studioReflection).build(engine);
        scene.setSkybox(skybox);
        ambient = new IndirectLight.Builder().reflections(studioReflection).irradiance(1, new float[]{0.46f, 0.53f, 0.64f})
                .intensity(18000f).build(engine);
        scene.setIndirectLight(ambient);
        refreshCamera();
        camera.setExposure(8.0f, 1.0f/80.0f, 100f);
        // Generating a single PBR material on-device avoids a desktop-only matc step.
        MaterialBuilder.init();
        String shader = "void material(inout MaterialInputs material) {\n"
                + "  prepareMaterial(material);\n"
                + "  material.baseColor.rgb = materialParams.baseColor;\n"
                + "  material.metallic = materialParams.metallic;\n"
                + "  material.roughness = materialParams.roughness;\n"
                + "  material.reflectance = 0.65;\n"
                + "  material.clearCoat = materialParams.clearCoat;\n"
                + "  material.clearCoatRoughness = 0.09;\n"
                + "  material.anisotropy = materialParams.anisotropy;\n"
                + "  material.emissive = float4(materialParams.baseColor * materialParams.emissive, 1.0);\n"
                + "}\n";
        MaterialPackage pkg;
        try {
            pkg = new MaterialBuilder()
                .name("AtelierPBR")
                .platform(MaterialBuilder.Platform.MOBILE)
                .targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3, "baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "roughness")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "clearCoat")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "anisotropy")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "emissive")
                .material(shader)
                .build(engine);
        if (!pkg.isValid()) throw new IllegalStateException("Advanced Filamat package invalid");
            graphicsProbe.note("ON  advanced PBR clearcoat, anisotropy and emissive");
        } catch(Throwable err) {
            graphicsProbe.note("FALLBACK advanced PBR: "+err.getClass().getSimpleName());
            String fallback="void material(inout MaterialInputs material) {\n"+
                "  prepareMaterial(material);\n"+
                "  material.baseColor.rgb=materialParams.baseColor;\n"+
                "  material.metallic=materialParams.metallic;\n"+
                "  material.roughness=materialParams.roughness;\n"+
                "}\n";
            pkg=new MaterialBuilder().name("AtelierSafePBR")
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"roughness")
                .material(fallback).build(engine);
            if(!pkg.isValid())throw new IllegalStateException("Safe PBR shader invalid",err);
        }
        ByteBuffer data = pkg.getBuffer();
        material = new Material.Builder().payload(data, data.remaining()).build(engine);
        // Texture-backed material uses original, locally generated albedo and tangent-space
        // normal+roughness maps. Material colour is a neutral multiplier, not a theme swatch.
        String texturedShader="void material(inout MaterialInputs material) {\n"+
            "  float4 texel=texture(materialParams_albedoMap,getUV0());\n"+
            "  float4 detail=texture(materialParams_normalRoughMap,getUV0());\n"+
            // Filament normal maps must be set before prepareMaterial(): tangent frame conversion.
            "  material.normal=normalize(detail.rgb*2.0-1.0);\n"+
            "  prepareMaterial(material);\n"+
            "  material.baseColor.rgb=texel.rgb*materialParams.baseColor;\n"+
            "  material.metallic=materialParams.metallic;\n"+
            "  material.roughness=clamp(materialParams.roughness*(0.6+detail.a*0.9),0.08,1.0);\n"+
            "  material.reflectance=0.6;\n"+
            "  material.clearCoat=materialParams.clearCoat;\n"+
            "  material.clearCoatRoughness=0.10;\n"+
            "  material.anisotropy=materialParams.anisotropy;\n"+
            "}\n";
        MaterialPackage texturedPkg;
        try {
            texturedPkg=new MaterialBuilder()
            .name("AtelierTexturedPBR")
            .platform(MaterialBuilder.Platform.MOBILE)
            .targetApi(MaterialBuilder.TargetApi.OPENGL)
            .shading(MaterialBuilder.Shading.LIT)
            .require(MaterialBuilder.VertexAttribute.UV0)
            .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"baseColor")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"metallic")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"roughness")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"clearCoat")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"anisotropy")
            .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"albedoMap")
            .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"normalRoughMap")
            .material(texturedShader).build(engine);
        if(!texturedPkg.isValid()) throw new IllegalStateException("Advanced textured shader invalid");
            graphicsProbe.note("ON  coated anisotropic textured material");
        } catch(Throwable err) {
            graphicsProbe.note("FALLBACK textured PBR: "+err.getClass().getSimpleName());
            String safeTextured="void material(inout MaterialInputs material) {\n"+
                "  float4 t=texture(materialParams_albedoMap,getUV0());\n"+
                "  float4 d=texture(materialParams_normalRoughMap,getUV0());\n"+
                "  material.normal=normalize(d.rgb*2.0-1.0);\n"+
                "  prepareMaterial(material);\n"+
                "  material.baseColor.rgb=t.rgb*materialParams.baseColor;\n"+
                "  material.metallic=materialParams.metallic;\n"+
                "  material.roughness=clamp(materialParams.roughness*(0.6+d.a*0.9),0.08,1.0);\n"+
                "}\n";
            texturedPkg=new MaterialBuilder().name("AtelierSafeTextured")
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT).require(MaterialBuilder.VertexAttribute.UV0)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"roughness")
                .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                    MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"albedoMap")
                .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                    MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"normalRoughMap")
                .material(safeTextured).build(engine);
            if(!texturedPkg.isValid())throw new IllegalStateException("Safe textured shader invalid",err);
        }
        ByteBuffer packed=texturedPkg.getBuffer();
        texturedMaterial=new Material.Builder().payload(packed,packed.remaining()).build(engine);
        Material glass=null;
        try {
            MaterialPackage glassPkg=new MaterialBuilder().name("SanctuaryCrystal")
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .refractionMode(MaterialBuilder.RefractionMode.SCREEN_SPACE)
                .refractionType(MaterialBuilder.RefractionType.SOLID)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"absorption")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"thickness")
                .material("void material(inout MaterialInputs material) {\n"+
                    "prepareMaterial(material); material.baseColor=float4(1.0);\n"+
                    "material.metallic=0.0; material.roughness=0.06; material.ior=1.52;\n"+
                    "material.transmission=0.96; material.absorption=materialParams.absorption;\n"+
                    "material.thickness=materialParams.thickness; }\n").build(engine);
            if(glassPkg.isValid()){
                ByteBuffer glassData=glassPkg.getBuffer();
                glass=new Material.Builder().payload(glassData,glassData.remaining()).build(engine);
                graphicsProbe.note("ON solid crystal transmission and screen-space refraction");
            } else graphicsProbe.note("UNAVAILABLE crystal shader: opaque polished fallback");
        } catch(Throwable failure){graphicsProbe.note("UNAVAILABLE crystal shader: "+failure.getClass().getSimpleName());}
        glassMaterial=glass;
        Material aurora=null;
        try{
            MaterialPackage curtain=new MaterialBuilder().name("AuroraCurtain")
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.UNLIT).require(MaterialBuilder.VertexAttribute.UV0)
                .blending(MaterialBuilder.BlendingMode.TRANSPARENT).doubleSided(true).depthWrite(false)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"tint")
                .material("void material(inout MaterialInputs material) { prepareMaterial(material);\n"+
                    "float2 uv=getUV0(); float a=pow(max(0.0,sin(clamp(uv.y,0.0,1.0)*3.14159265)),1.5)*0.34;\n"+
                    "a*=smoothstep(0.0,0.10,uv.x)*(1.0-smoothstep(0.9,1.0,uv.x));\n"+
                    "material.baseColor=float4(materialParams.tint*a*3.0,a); }\n").build(engine);
            if(curtain.isValid()){
                ByteBuffer lightData=curtain.getBuffer();aurora=new Material.Builder().payload(lightData,lightData.remaining()).build(engine);
            }else graphicsProbe.note("UNAVAILABLE Aurora curtain shader");
        }catch(Throwable unavailable){graphicsProbe.note("UNAVAILABLE Aurora curtain shader: "+unavailable.getClass().getSimpleName());}
        auroraMaterial=aurora;
        MaterialBuilder.shutdown();
        cube=makeCube(); sphere=makeSphere(64, 40); torus=makeTorus(48, 12); cylinder=makeCylinder(40);
        createLights();
        setLevel(1);
        uiHelper = new UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK);
        uiHelper.setRenderCallback(this);
        uiHelper.attachTo(surface);
    }

    /** Camera is a pure view change: it never rotates or moves the physics world. */
    public float getYaw(){return yaw;}
    public void rotateCamera(float degrees){
        // Angle is animated in updateCamera, never jumped in the click handler.
        targetYaw+=(float)Math.toRadians(degrees);
    }
    public void changeZoom(float multiplier){
        // Keep both the close-up marble and a useful surrounding route on-screen.
        // Previously 0.52x could crop the board almost completely on a portrait phone.
        targetZoom=Math.max(.66f,Math.min(2.40f,targetZoom*multiplier));
    }
    public void toggleOverview(){
        overview=!overview;targetOverview=overview?1f:0f;
    }
    public boolean isOverview(){return overview;}
    public boolean controlsLocked(){return false;} // Camera framing NEVER disables marble input.
    /** The vault uses the same sphere, shaders and textures as gameplay. */
    public void presentMarble(int skin){
        setLevel(level);
        for(int entity:entities)scene.removeEntity(entity);
        if(beaconLight!=0)scene.removeEntity(beaconLight);
        marblePreview=true;followBall=false;focusX=focusZ=0;panX=panZ=0;
        targetYaw=0;targetZoom=1;overview=false;targetOverview=0;
        MaterialInstance finish=(skin==1||skin==3)&&glassMaterial!=null?
            crystal(skin==1?new float[]{3,.65f,.12f}:new float[]{1.6f,1.9f,2.1f},2.4f):texturedBallPaint(skin);
        addShape(sphere,0,1.33f,0,1.2f,1.2f,1.2f,finish);
        MaterialInstance stone=texturedPaint(.02f,.24f,0,0);
        addShape(cylinder,0,-.10f,0,2.4f,.20f,2.4f,stone);
        addShape(torus,0,-.26f,0,2.35f,.12f,2.35f,paint(0xC0A16C,.88f,.22f));
        refreshCamera();
    }
    public void presentMenu(){
        followBall=false;focusX=0;focusZ=0;targetYaw=(float)Math.toRadians(-24);
        targetZoom=1.20f;targetOverview=0;overview=false;
    }
    public void resetCamera(){
        overview=false;targetOverview=0;
        targetYaw=0;targetZoom=1f;
        // Smoothly return to the marble instead of snapping.
    }
    public void setFollowBall(boolean on){followBall=on;}
    public void setQuality(boolean high){setGraphicsProfile(high?GraphicsProbe.STUDIO:GraphicsProbe.BALANCED);}
    public void setGraphicsProfile(int profile){
        graphicsProbe.configure(view,profile);
        boolean max=profile==GraphicsProbe.MAXIMUM;
        boolean expensive=profile<=GraphicsProbe.STUDIO;
        View.AmbientOcclusionOptions ao=new View.AmbientOcclusionOptions();
        ao.enabled=profile!=GraphicsProbe.SAFE && graphicsProbe.allowed(9);
        ao.radius=max?0.64f:.42f;
        ao.intensity=max?1.52f:1.20f;
        view.setAmbientOcclusionOptions(ao);
        View.BloomOptions bloom=new View.BloomOptions();
        bloom.enabled=expensive && graphicsProbe.allowed(10);
        bloom.strength=max?.20f:.105f;
        view.setBloomOptions(bloom);
        view.setAntiAliasing(View.AntiAliasing.FXAA);
        View.FogOptions mist=new View.FogOptions();
        mist.enabled=profile!=GraphicsProbe.SAFE&&graphicsProbe.allowed(3);mist.distance=isAurora()?30:12;mist.density=isAurora()?.009f:.021f;
        mist.height=isAurora()?-8:-6;mist.heightFalloff=.20f;mist.maximumOpacity=isAurora()?.55f:.82f;
        mist.color=isAurora()?new float[]{.15f,.18f,.22f}:new float[]{.23f,.29f,.33f};mist.fogColorFromIbl=false;
        view.setFogOptions(mist);
        view.setScreenSpaceRefractionEnabled(profile<=GraphicsProbe.STUDIO&&graphicsProbe.allowed(8));
        graphicsProbe.note("ON  SSAO="+ao.enabled+" / bloom="+bloom.enabled+" / FXAA=true for every preset");
    }
    public void setVisibilityAssist(boolean ignored){
        // Legacy API intentionally does nothing: wall visibility is permanent.
    }
    public void applyStyle(int theme,int skin,int requestedLevel){
        int nextTheme=Math.floorMod(theme,VisualStyles.THEMES.length);
        int nextBall=Math.floorMod(skin,VisualStyles.MARBLES.length);
        boolean reload=marblePreview||nextTheme!=themeIndex||nextBall!=ballSkin||currentLevel==null||level!=requestedLevel;
        themeIndex=nextTheme;
        ballSkin=nextBall;
        // Change stage AND appearance atomically, avoiding an intermediate wrong-level
        // render and duplicate GPU texture/mesh allocations during navigation.
        if(reload)setLevel(requestedLevel);
    }
    private void refreshCamera(){
        if(camera==null)return;
        // Overhead is a PLAYABLE camera mode. Camera moves, collision world does not.
        // Distance scales with the actual footprint, not a fixed guess per level.
        double boardSize=marblePreview?0:currentLevel==null?9.0:Math.max(currentLevel.cols*currentLevel.cellSize,currentLevel.rows*currentLevel.cellSize);
        double distance=(boardSize*.64+6.6 + (boardSize*1.42+8.5)*overviewBlend)*zoom;
        double horizontal=distance*(.69*(1-overviewBlend)+.001*overviewBlend);
        double height=distance*(.96*(1-overviewBlend)+1.0*overviewBlend);
        // Camera-aware soft framing. The marble is still followed, but the focal point
        // cannot chase it so far toward an edge that most of the sculpted maze disappears.
        // This changes no steering / collision coordinates, including overhead play.
        double tx=focusX,tz=focusZ;
        if(!marblePreview && currentLevel!=null){
            double focusFraction=.28+.07*Math.min(1,Math.max(0,zoom-.7));
            tx=Math.max(-currentLevel.halfWidth*focusFraction,Math.min(currentLevel.halfWidth*focusFraction,tx));
            tz=Math.max(-currentLevel.halfLength*focusFraction,Math.min(currentLevel.halfLength*focusFraction,tz));
        }
        tx=tx*(1-overviewBlend)+panX*overviewBlend;
        tz=tz*(1-overviewBlend)+panZ*overviewBlend;
        camera.lookAt(tx+Math.sin(yaw)*horizontal,height,tz+Math.cos(yaw)*horizontal,
            tx,marblePreview?1.05:0,tz,0,1,0);
    }
    private void updateCamera(float dt){
        float a=1f-(float)Math.exp(-8.0f*Math.min(dt,.05f));
        // Angular interpolation uses the shortest wrapped delta for 0/360 transitions.
        float delta=(float)Math.atan2(Math.sin(targetYaw-yaw),Math.cos(targetYaw-yaw));
        yaw+=delta*a;
        zoom+=(targetZoom-zoom)*a;
        overviewBlend+=(targetOverview-overviewBlend)*a;
        if(overviewBlend<.0005f&&targetOverview==0)overviewBlend=0;
        refreshCamera();
    }

    public SurfaceView getSurface() { return surface; }
    public void setRunning(boolean isRunning) {
        if (disposed || running == isRunning) return;
        running = isRunning;
        if(running)lastRenderNanos=0;
        if (running) Choreographer.getInstance().postFrameCallback(this);
        else Choreographer.getInstance().removeFrameCallback(this);
    }
    public void setLevel(int nextLevel) {
        level = nextLevel;marblePreview=false;auroraCurtains.clear();boats.clear();atmosphereTime=0;
        if(beaconLight!=0){scene.removeEntity(beaconLight);engine.destroyEntity(beaconLight);EntityManager.get().destroy(beaconLight);beaconLight=0;}
        beaconBeam=0;
        configureVolumeLighting();
        movingPieces.clear();ballRingEntity=0;
        for (int entity : entities) {
            scene.removeEntity(entity);
            engine.destroyEntity(entity);
            EntityManager.get().destroy(entity);
        }
        entities.clear();
        for(Mesh mesh:batchedMeshes){
            engine.destroyVertexBuffer(mesh.vertices);engine.destroyIndexBuffer(mesh.indices);
        }
        meshes.removeAll(batchedMeshes);batchedMeshes.clear();
        for (MaterialInstance mi : materialInstances) engine.destroyMaterialInstance(mi);
        materialInstances.clear();
        MarblePhysics game = new MarblePhysics(level);currentLevel=game;
        // The outer silhouette is cut from exactly the playable maze cells.
        // No decorative rectangle underneath lets players bypass the true maze.
        int[] colors=VisualStyles.PALETTES[themeIndex];
        // Ceramic/stone top against a carbon-anodised sculptural chassis.
        // The base is deliberately NOT textured like the floor (V0.4.3's main visual issue).
        MaterialInstance podium=texturedPaint(.02f,.34f,themeIndex,1);
        MaterialInstance chassisInset=paint(0x111A23,.62f,.51f);
        MaterialInstance floor=texturedPaint(.02f,.23f,themeIndex,0);
        MaterialInstance brass=paint(colors[4],.80f,.23f);
        MaterialInstance rim=paint(isAurora()?0xC8D8E4:0xB59B70,.88f,.26f);
        MaterialInstance wall=texturedPaint(.02f,.28f,themeIndex,1);
        MaterialInstance railLine=paint(colors[5],.26f,.31f);
        MaterialInstance goalGlow=paint(isAurora()?0xB3FFF0:0xFFE2A3,.0f,.24f);
        tryParam(goalGlow,"emissive",3.5f);
        MaterialInstance launch=paint(colors[4],.48f,.30f);
        float c=game.cellSize;
        float span=Math.max(game.cols,game.rows)*c;
        MaterialInstance podiumEdge=paint(isAurora()?0xBCD3E3:0xBA965F,.86f,.24f);
        if(isAurora())buildAurora(game,span);else buildSanctuary(game,span);
        // Batched static meshes: thousands of tiles become seven draw calls.
        List<BoxPart> base=new ArrayList<>(),floorTiles=new ArrayList<>(),gold=new ArrayList<>(),inlay=new ArrayList<>();
        List<BoxPart> edgeBands=new ArrayList<>(),edgePins=new ArrayList<>();
        List<BoxPart> walls=new ArrayList<>(),caps=new ArrayList<>(),sideGrooves=new ArrayList<>(),capInlays=new ArrayList<>();
        for(int ix=0;ix<game.cols;ix++)for(int iz=0;iz<game.rows;iz++)if(game.isCell(ix,iz)){
            float px=game.centerX(ix),pz=game.centerZ(iz);
            base.add(new BoxPart(px,-1.00f,pz,c*.497f,.69f,c*.497f));
            // A three-material chassis profile instead of theme-matching slabs.
            gold.add(new BoxPart(px,-.315f,pz,c*.498f,.016f,c*.498f));
            inlay.add(new BoxPart(px,-.277f,pz,c*.495f,.025f,c*.495f));
            float slope=game.rampDirection(ix,iz)*.095f;
            if(Math.abs(px-game.goalX)<.01f && Math.abs(pz-game.goalZ)<.01f)
                addGoalTile(px,pz,c*.498f,floor);
            else floorTiles.add(new BoxPart(px,-.151f,pz,c*.498f,.15f,c*.498f,
                (float)-Math.atan(slope)));
            if(slope!=0)addBox(px,-.005f,pz,c*.43f,.008f,.018f,goalGlow);
            // Cut the perimeter ONLY along exposed exterior cell faces. Cosmetic
            // geometry is far below collision Y=0; authored routes are untouched.
            float outside=c*.498f;
            if(!game.isCell(ix-1,iz)){
                edgeBands.add(new BoxPart(px-outside,-.49f,pz,.019f,.065f,c*.475f));
                edgePins.add(new BoxPart(px-outside,-.61f,pz,.029f,.014f,c*.452f));
            }
            if(!game.isCell(ix+1,iz)){
                edgeBands.add(new BoxPart(px+outside,-.49f,pz,.019f,.065f,c*.475f));
                edgePins.add(new BoxPart(px+outside,-.61f,pz,.029f,.014f,c*.452f));
            }
            if(!game.isCell(ix,iz-1)){
                edgeBands.add(new BoxPart(px,-.49f,pz-outside,c*.475f,.065f,.019f));
                edgePins.add(new BoxPart(px,-.61f,pz-outside,c*.452f,.014f,.029f));
            }
            if(!game.isCell(ix,iz+1)){
                edgeBands.add(new BoxPart(px,-.49f,pz+outside,c*.475f,.065f,.019f));
                edgePins.add(new BoxPart(px,-.61f,pz+outside,c*.452f,.014f,.029f));
            }
        }
        for(MarblePhysics.Obstacle o:game.obstacles){
            if(o.moving){
                int block=addBox(o.x,.17f,o.z,o.halfX,.17f,o.halfZ,wall);
                int cap=addBox(o.x,.349f,o.z,o.halfX,.011f,o.halfZ,rim);
                movingPieces.add(new MovingVisual(block,o,.17f,o.halfX,.17f,o.halfZ));
                movingPieces.add(new MovingVisual(cap,o,.349f,o.halfX,.011f,o.halfZ));
            }else{
                walls.add(new BoxPart(o.x,.17f,o.z,o.halfX,.17f,o.halfZ));
                caps.add(new BoxPart(o.x,.349f,o.z,Math.max(.012f,o.halfX-.036f),.006f,Math.max(.012f,o.halfZ-.036f)));
                // Inset fine machinery grooves on both faces of the wall near its base.
                // These remain inside the collision envelope (purely visual recess lines).
                if(o.halfX>o.halfZ){
                    float depth=Math.max(.001f,o.halfZ-.012f);
                    sideGrooves.add(new BoxPart(o.x,.058f,o.z-depth,o.halfX*.94f,.008f,.007f));
                    sideGrooves.add(new BoxPart(o.x,.058f,o.z+depth,o.halfX*.94f,.008f,.007f));
                    capInlays.add(new BoxPart(o.x,.357f,o.z,o.halfX*.88f,.0025f,.007f));
                }else{
                    float depth=Math.max(.001f,o.halfX-.012f);
                    sideGrooves.add(new BoxPart(o.x-depth,.058f,o.z,.007f,.008f,o.halfZ*.94f));
                    sideGrooves.add(new BoxPart(o.x+depth,.058f,o.z,.007f,.008f,o.halfZ*.94f));
                    capInlays.add(new BoxPart(o.x,.357f,o.z,.007f,.0025f,o.halfZ*.88f));
                }
            }
        }
        addChamferedWallBatch(base,podium);
        addBoxBatch(gold,podiumEdge);addBoxBatch(inlay,chassisInset);
        addBoxBatch(edgeBands,chassisInset);addBoxBatch(edgePins,podiumEdge);
        addBoxBatch(floorTiles,floor);addChamferedWallBatch(walls,wall);
        // Twin recessed foot grooves and a narrow crown inlay make walls read as
        // precision-machined components, without moving any physical surface.
        addBoxBatch(sideGrooves,chassisInset);
        addBoxBatch(capInlays,podiumEdge);
        addShape(cylinder,game.startX,.006f,game.startZ,.27f,.014f,.27f,launch);
        addShape(torus,game.startX,.017f,game.startZ,.29f,.040f,.29f,goalGlow);
        addShape(cylinder,game.goalX,-.235f,game.goalZ,.265f,.025f,.265f,chassisInset);
        addShape(torus,game.goalX,.008f,game.goalZ,.32f,.14f,.32f,brass);
        addShape(torus,game.goalX,-.16f,game.goalZ,.252f,.10f,.252f,goalGlow);
        MaterialInstance ball=(ballSkin==1||ballSkin==3)&&glassMaterial!=null?
            crystal(ballSkin==1?new float[]{3.0f,.65f,.12f}:new float[]{1.6f,1.9f,2.1f},MarblePhysics.BALL_RADIUS*2):texturedBallPaint(ballSkin);
        ballEntity=addShape(sphere,game.x,MarblePhysics.BALL_RADIUS+game.getHeightAt(game.x,game.z),game.z,MarblePhysics.BALL_RADIUS,
            MarblePhysics.BALL_RADIUS,MarblePhysics.BALL_RADIUS,ball);
        if(ballSkin>=6){
            MaterialInstance trim=paint(ballSkin==6?0x2CF6FF:ballSkin==7?0xF4B8FF:colors[4],.71f,.17f);
            ballRingEntity=addShape(torus,game.x,.17f,game.z,.143f,.143f,.143f,trim);
        }
        ballX=lastBallX=game.x;ballZ=lastBallZ=game.z;
        rolling.reset();sink=0;
        focusX=game.x;focusZ=game.z;panX=0;panZ=0;
        refreshCamera();
        updateMovingWalls(game);
    }

    private boolean isAurora(){return level>LevelBlueprints.VOLUME_SIZE;}
    private void configureVolumeLighting(){
        boolean arctic=isAurora();scene.setSkybox(arctic?auroraSkybox:skybox);
        scene.setIndirectLight(arctic?auroraAmbient:ambient);
        camera.setExposure(arctic?10f:8f,arctic?1f/100f:1f/80f,100f);
        if(sunEntity!=0){
            LightManager lm=engine.getLightManager();int sun=lm.getInstance(sunEntity);
            lm.setColor(sun,arctic?.88f:1f,arctic?.91f:.83f,arctic?.95f:.62f);
            lm.setIntensity(sun,arctic?42000f:85000f);
            lm.setDirection(sun,-.62f,arctic?-.52f:-.72f,-.42f);
            for(int i=1;i<lights.size();i++){
                int l=lm.getInstance(lights.get(i));
                if(arctic){lm.setColor(l,.58f,.64f,.73f);lm.setIntensity(l,i==1?9000f:i==2?6000f:4500f);}
                else if(i==2){lm.setColor(l,.94f,.81f,.62f);lm.setIntensity(l,13000f);}
                else {lm.setColor(l,i==1?.60f:.44f,i==1?.74f:.67f,1f);lm.setIntensity(l,i==1?16000f:9000f);}
            }
        }
        setGraphicsProfile(graphicsProbe.profile());
    }
    /** Aurora is a continuous alpine lake landscape, with a distinct wide silhouette. */
    private void buildAurora(MarblePhysics game,float span){
        float clearance=(float)Math.hypot(game.halfWidth,game.halfLength)+3.8f;
        MaterialInstance earth=landscapePaint("terrain",.88f);
        MaterialInstance water=landscapePaint("water",.54f);
        MaterialInstance steel=paint(0x77858C,.76f,.32f);
        MaterialInstance pine=paint(0x293B32,0,.87f),bark=paint(0x51463A,0,.94f);
        MaterialInstance shoreRock=paint(0x63655F,.01f,.86f);
        AlpineLandscape.Geometry terrain=AlpineLandscape.build(clearance);
        Mesh land=upload(terrain.positions,terrain.normals,terrain.uv,terrain.indices);
        batchedMeshes.add(land);addShape(land,0,0,0,1,1,1,earth);
        // Subdued, rougher PBR water avoids the repeated bright point highlights seen
        // from steep phone camera angles. Textured ripples are retained, not removed.
        List<BoxPart> lake=new ArrayList<>();lake.add(new BoxPart(0,-7.70f,0,64,.035f,64));addBoxBatch(lake,water);
        buildHarbourFoundation(game);
        buildHarbourScene(game,clearance);
        java.util.Random random=new java.util.Random(6249);
        // Trees and shore boulders sit on the actual terrain height, never on flat cap discs.
        List<BoxPart> pebbles=new ArrayList<>();
        for(int i=0;i<48;i++){
            float angle=i*2.399963f;
            float radius=clearance+10+random.nextFloat()*16;
            float x=(float)Math.cos(angle)*radius,z=(float)Math.sin(angle)*radius;
            float y=AlpineLandscape.height(x,z,clearance);
            if(y<-7.35f||y>3f)continue;
            float size=.35f+random.nextFloat()*.65f;
            pebbles.add(new BoxPart(x,y+.15f,z,size,.22f,size*.7f));
            if(i%2==0){
                float height=1.6f+random.nextFloat()*1.5f;
                addShape(cylinder,x,y+height*.5f,z,.045f,height*.5f,.045f,bark);
                Mesh tree=makePine(x,y,z,height,random);batchedMeshes.add(tree);
                addShape(tree,0,0,0,1,1,1,pine);
            }
        }
        addChamferedWallBatch(pebbles,shoreRock);
    }

    /**
     * Beacon Harbour 0.9.3: an irregular coastal crag, NOT three descending boxes.
     * A slender carved masonry crown unites the clean board with naturally fractured
     * rock. The rock foot flares into the lake / terrain and is entirely cosmetic.
     * All geometry remains below the gameplay deck, outside the marble colliders.
     */
    private void buildHarbourFoundation(MarblePhysics game){
        MaterialInstance crag=landscapePaint("terrain",.92f);
        crag.setParameter("baseColor",Colors.RgbType.SRGB,.73f,.71f,.67f);
        Mesh bedrock=makeHarbourCrag(game.halfWidth,game.halfLength);
        batchedMeshes.add(bedrock);
        addShape(bedrock,0,0,0,1,1,1,crag);

        MaterialInstance cutSlate=texturedPaint(.02f,.64f,6,1);
        MaterialInstance weatheredMetal=paint(0x828787,.51f,.49f);
        MaterialInstance joint=paint(0x222F32,.06f,.84f);
        MaterialInstance amber=paint(0xC5A271,.02f,.54f);tryParam(amber,"emissive",.62f);

        // One shallow platform, not a solid artificial plinth extending downward.
        List<BoxPart> crown=new ArrayList<>();
        crown.add(new BoxPart(0,-1.87f,0,game.halfWidth+.19f,.23f,game.halfLength+.19f));
        addChamferedWallBatch(crown,cutSlate);
        List<BoxPart> seams=new ArrayList<>(),reinforcement=new ArrayList<>(),lightSlots=new ArrayList<>();
        for(int sign:new int[]{-1,1}){
            seams.add(new BoxPart(sign*(game.halfWidth+.197f),-1.96f,0,.012f,.030f,game.halfLength+.17f));
            seams.add(new BoxPart(0,-1.96f,sign*(game.halfLength+.197f),game.halfWidth+.17f,.030f,.012f));
            // Short buttresses, broken into separate courses on the visible upper rock.
            for(int i=-1;i<=1;i++){
                float z=i*game.halfLength*.61f;
                reinforcement.add(new BoxPart(sign*(game.halfWidth+.18f),-2.25f,z,.08f,.24f,.19f));
                lightSlots.add(new BoxPart(sign*(game.halfWidth+.262f),-2.11f,z,.013f,.032f,.083f));
                float x=i*game.halfWidth*.61f;
                reinforcement.add(new BoxPart(x,-2.25f,sign*(game.halfLength+.18f),.19f,.24f,.08f));
                lightSlots.add(new BoxPart(x,-2.11f,sign*(game.halfLength+.262f),.083f,.032f,.013f));
            }
        }
        addBoxBatch(seams,joint);
        addChamferedWallBatch(reinforcement,weatheredMetal);
        addBoxBatch(lightSlots,amber);
    }

    /** Natural, stratified rock: fractured vertical cliffs and nonuniform ledges.
     * Radial rectangular footprint at its crown supports ALL authored maze silhouettes.
     * Subsequent rings deliberately bulge and recede to eliminate inverted-pyramid lines.
     */
    private Mesh makeHarbourCrag(float halfWidth,float halfLength){
        final int sides=96;
        final float[] elevations={-9.65f,-8.48f,-7.78f,-6.74f,-5.83f,-4.91f,-4.07f,-3.30f,-2.49f,-2.00f};
        final float[] spreads={1.39f,1.31f,1.25f,1.17f,1.10f,1.02f,1.09f,.97f,1.00f,1.00f};
        final int rings=elevations.length,faces=(rings-1)*sides;
        float[] p=new float[faces*12],n=new float[p.length],uv=new float[faces*8];
        int[] indices=new int[faces*6];
        float[][][] points=new float[rings][sides][3];
        for(int ring=0;ring<rings;ring++)for(int side=0;side<sides;side++){
            double a=side*Math.PI*2/sides;
            float cos=(float)Math.cos(a),sin=(float)Math.sin(a);
            // True rectangular envelope at the top, natural roughness further down.
            float rectangular=Math.min((halfWidth+.15f)/Math.max(.0001f,Math.abs(cos)),
                    (halfLength+.15f)/Math.max(.0001f,Math.abs(sin)));
            float scar=(float)(.065*Math.sin(a*7.0+ring*.47)+.043*Math.sin(a*13.0-ring*.81)
                    +.026*Math.sin(a*27.0+ring*.33));
            float ledge=(ring==4||ring==6)?.055f:0;
            float roughness=ring==rings-1?0:(scar+ledge);
            float radius=rectangular*(spreads[ring]+roughness);
            float slant=ring==rings-1?0:(float)(.13*Math.sin(a*5.0+ring*.7));
            points[ring][side]=new float[]{cos*radius,elevations[ring]+slant,sin*radius};
        }
        int face=0;
        for(int r=0;r<rings-1;r++)for(int i=0;i<sides;i++){
            int next=(i+1)%sides;
            face=emitFace(0,face,faces,points[r][i],points[r][next],
                    points[r+1][next],points[r+1][i],p,n,uv,indices);
        }
        return upload(p,n,uv,indices);
    }
    private void buildHarbourScene(MarblePhysics game,float clearance){
        MaterialInstance masonry=paint(0xB9B6A9,0,.78f),roof=paint(0x5B6468,.62f,.38f);
        MaterialInstance timber=paint(0x756552,0,.85f),rail=paint(0x687275,.72f,.35f);
        MaterialInstance lamp=paint(0xF4D8A0,0,.22f);tryParam(lamp,"emissive",2f);
        float x=-clearance-10,z=-clearance-6;
        float y=Math.max(-7.25f,AlpineLandscape.height(x,z,clearance));
        addShape(cylinder,x,y+.14f,z,1.60f,.26f,1.60f,roof);
        // Tapered masonry tower, balcony, lantern room and conical roof.
        Mesh tower=makeTaperedTower();batchedMeshes.add(tower);addShape(tower,x,y+.40f,z,1,1,1,masonry);
        for(float h:new float[]{1.4f,3.5f,5.5f})addShape(torus,x,y+h,z,.72f,.20f,.72f,roof);
        addShape(cylinder,x,y+6.10f,z,1.13f,.10f,1.13f,roof);
        addShape(torus,x,y+6.75f,z,1.10f,.35f,1.10f,rail);
        for(int i=0;i<12;i++){
            double angle=i*Math.PI*2/12;
            addShape(cylinder,x+(float)Math.cos(angle)*1.08f,y+6.45f,z+(float)Math.sin(angle)*1.08f,.025f,.35f,.025f,rail);
        }
        MaterialInstance window=glassMaterial!=null?crystal(new float[]{.1f,.12f,.14f},.25f):paint(0x536774,.3f,.18f);
        addShape(cylinder,x,y+6.96f,z,.70f,.66f,.70f,window);
        for(int i=0;i<8;i++){
            double angle=i*Math.PI*2/8;
            addShape(cylinder,x+(float)Math.cos(angle)*.72f,y+6.96f,z+(float)Math.sin(angle)*.72f,.027f,.68f,.027f,rail);
        }
        addShape(cylinder,x,y+7.63f,z,.85f,.10f,.85f,roof);
        Mesh top=makeConicalRoof();batchedMeshes.add(top);
        addShape(top,x,y+7.73f,z,1,1,1,roof);
        addShape(sphere,x,y+6.96f,z,.20f,.30f,.20f,lamp);
        addBox(x,y+.95f,z+.82f,.24f,.50f,.035f,timber);
        for(float h:new float[]{2.6f,4.5f})addBox(x,y+h,z+.77f,.14f,.25f,.03f,window);
        beaconX=x;beaconY=y+6.96f;beaconZ=z;
        beaconLight=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.SPOT).position(beaconX,beaconY,beaconZ).direction(1,-.38f,0)
            .color(1,.88f,.65f).intensity(90000f).falloff(40).spotLightCone(.06f,.13f).castShadows(false).build(engine,beaconLight);
        scene.addEntity(beaconLight);
        MaterialInstance beamMaterial;
        if(auroraMaterial!=null){beamMaterial=auroraMaterial.createInstance();beamMaterial.setParameter("tint",.40f,.33f,.20f);materialInstances.add(beamMaterial);}
        else {beamMaterial=lamp;}
        Mesh beam=makeBeaconBeam();batchedMeshes.add(beam);beaconBeam=addShape(beam,beaconX,beaconY,beaconZ,1,1,1,beamMaterial);
        engine.getRenderableManager().setCastShadows(engine.getRenderableManager().getInstance(beaconBeam),false);
        // Wooden jetty and mooring posts, positioned over the lake rather than the maze.
        float jettyX=clearance+5,jettyZ=2;
        List<BoxPart> planks=new ArrayList<>();
        for(int i=0;i<24;i++)planks.add(new BoxPart(jettyX,-7.28f,jettyZ+i*.22f,.85f,.07f,.09f));
        for(int i=0;i<19;i++)planks.add(new BoxPart(jettyX+i*.22f,-7.28f,jettyZ,.09f,.07f,.65f));
        addBoxBatch(planks,timber);
        for(int i=0;i<4;i++)for(int side:new int[]{-1,1})addShape(cylinder,jettyX+side*.82f,-7.18f,jettyZ+i*1.65f,.075f,.52f,.075f,timber);
        addBoat(jettyX-1.5f,jettyZ+2,0,false,0x486071);
        addBoat(jettyX+1.7f,jettyZ+4,1,false,0x7A5046);
        addBoat(-clearance*.45f,-clearance-3.5f,2,true,0x566A58);
        addBoat(clearance*.5f,-clearance-5.5f,3,false,0xC0B69E);
        // In-world scale cues: reflective channel markers and harbour pier fittings.
        MaterialInstance buoy=paint(0xB47A4B,.18f,.42f),buoyTop=paint(0xD4B17D,.14f,.41f);
        for(int i=0;i<4;i++){
            float bx=jettyX+(i%2==0?-2.55f:2.55f),bz=jettyZ+i*2.02f;
            addShape(cylinder,bx,-7.55f,bz,.17f,.16f,.17f,buoy);
            addShape(sphere,bx,-7.31f,bz,.11f,.12f,.11f,buoyTop);
        }
        List<BoxPart> dockGear=new ArrayList<>();
        for(int i=0;i<3;i++){
            dockGear.add(new BoxPart(jettyX+.34f,-7.08f,jettyZ+.40f+i*1.23f,.14f,.11f,.17f));
        }
        addChamferedWallBatch(dockGear,timber);
        // Shore buildings, grouped rocks and reeds give the headland a lived-in scale.
        addBox(x+2.8f,y+.65f,z+1.2f,1.1f,.65f,.8f,masonry);
        addTiltedBox(x+2.8f,y+1.42f,z+.78f,1.2f,.07f,.52f,roof,-23);
        addTiltedBox(x+2.8f,y+1.42f,z+1.62f,1.2f,.07f,.52f,roof,23);
        addBox(x+2.8f,y+.7f,z+2.01f,.24f,.37f,.02f,timber);
        List<BoxPart> reeds=new ArrayList<>();java.util.Random random=new java.util.Random(725);
        for(int i=0;i<120;i++){
            float a=i*2.399963f,rx=(clearance+7.5f)*(float)Math.cos(a),rz=(clearance+12.5f)*(float)Math.sin(a);
            float ground=AlpineLandscape.height(rx,rz,clearance);
            if(ground>-7.7f&&ground<-6.5f)for(int j=0;j<3;j++){
                float h=.22f+random.nextFloat()*.30f;
                reeds.add(new BoxPart(rx+random.nextFloat()*.35f,ground+h,rz+random.nextFloat()*.35f,.016f,h,.016f));
            }
        }
        addBoxBatch(reeds,paint(0x6E7754,0,.92f));
    }
    private Mesh makeConicalRoof(){
        int sides=40;float[] p=new float[sides*12],n=new float[p.length],uv=new float[sides*8];int[] idx=new int[sides*6];
        float[] peak={0,.68f,0};
        for(int i=0;i<sides;i++){
            double a=i*Math.PI*2/sides,b=(i+1)*Math.PI*2/sides;
            emitFace(0,i,sides,new float[]{(float)Math.cos(a)*.90f,0,(float)Math.sin(a)*.90f},
                new float[]{(float)Math.cos(b)*.90f,0,(float)Math.sin(b)*.90f},peak,peak,p,n,uv,idx);
        }
        return upload(p,n,uv,idx);
    }
    private Mesh makeTaperedTower(){
        int sides=40,faces=sides;float[] p=new float[faces*12],n=new float[p.length],uv=new float[faces*8];int[] idx=new int[faces*6];
        for(int i=0;i<sides;i++){
            double a=i*Math.PI*2/sides,b=(i+1)*Math.PI*2/sides;
            emitFace(0,i,faces,new float[]{(float)Math.cos(a)*.90f,0,(float)Math.sin(a)*.90f},new float[]{(float)Math.cos(b)*.90f,0,(float)Math.sin(b)*.90f},
                new float[]{(float)Math.cos(b)*.66f,5.75f,(float)Math.sin(b)*.66f},new float[]{(float)Math.cos(a)*.66f,5.75f,(float)Math.sin(a)*.66f},p,n,uv,idx);
        }
        return upload(p,n,uv,idx);
    }
    private Mesh makeBeaconBeam(){
        int sides=24;float[] p=new float[sides*12],n=new float[p.length],uv=new float[sides*8];int[] idx=new int[sides*6];
        for(int i=0;i<sides;i++){
            double a=i*Math.PI*2/sides,b=(i+1)*Math.PI*2/sides;
            emitFace(0,i,sides,new float[]{.15f,(float)Math.cos(a)*.04f,(float)Math.sin(a)*.04f},
                new float[]{22,-8.36f+(float)Math.cos(a)*2.2f,(float)Math.sin(a)*2.2f},
                new float[]{22,-8.36f+(float)Math.cos(b)*2.2f,(float)Math.sin(b)*2.2f},
                new float[]{.15f,(float)Math.cos(b)*.04f,(float)Math.sin(b)*.04f},p,n,uv,idx);
            int v=i*8;uv[v]=.1f;uv[v+1]=i/(float)sides;uv[v+2]=1f;uv[v+3]=i/(float)sides;
            uv[v+4]=1f;uv[v+5]=(i+1)/(float)sides;uv[v+6]=.1f;uv[v+7]=(i+1)/(float)sides;
        }
        return upload(p,n,uv,idx);
    }
    private void addBoat(float x,float z,float phase,boolean cruise,int color){
        int first=entities.size();
        MaterialInstance hull=paint(color,.04f,.45f),deck=paint(0xD1C5A9,0,.70f),glass=paint(0x3D5662,.25f,.18f),metal=paint(0x727E81,.75f,.30f);
        Mesh hullMesh=makeBoatHull();batchedMeshes.add(hullMesh);addShape(hullMesh,0,0,0,1,1,1,hull);
        addBox(0,.12f,.10f,.45f,.055f,.91f,deck);
        addBox(0,.46f,.42f,.32f,.32f,.38f,deck);addBox(0,.80f,.42f,.37f,.035f,.42f,metal);
        addBox(0,.53f,.03f,.26f,.16f,.012f,glass);
        for(int side:new int[]{-1,1})addBox(side*.33f,.54f,.42f,.012f,.14f,.27f,glass);
        addShape(cylinder,0,1.17f,.44f,.018f,.38f,.018f,metal);
        MaterialInstance port=paint(0xCE4D3E,0,.35f),starboard=paint(0x62AA7A,0,.35f);
        tryParam(port,"emissive",1.2f);tryParam(starboard,"emissive",1.2f);
        addShape(sphere,-.38f,.72f,.15f,.045f,.045f,.045f,port);
        addShape(sphere,.38f,.72f,.15f,.045f,.045f,.045f,starboard);
        int last=entities.size(),parent=EntityManager.get().create();engine.getTransformManager().create(parent);entities.add(parent);
        int instance=engine.getTransformManager().getInstance(parent);
        for(int i=first;i<last;i++)engine.getTransformManager().setParent(engine.getTransformManager().getInstance(entities.get(i)),instance);
        boats.add(new BoatVisual(parent,x,z,phase,cruise));
    }
    private Mesh makeBoatHull(){
        float[][] edge={{0,-1.5f},{.36f,-1.03f},{.52f,-.50f},{.55f,.65f},{.40f,1.22f},{-.40f,1.22f},{-.55f,.65f},{-.52f,-.50f},{-.36f,-1.03f}};
        int faces=edge.length;float[] p=new float[faces*12],n=new float[p.length],uv=new float[faces*8];int[] idx=new int[faces*6];
        for(int i=0;i<faces;i++){
            float[] a=edge[i],b=edge[(i+1)%faces];
            emitFace(0,i,faces,new float[]{a[0]*.6f,-.35f,a[1]*.83f},new float[]{b[0]*.6f,-.35f,b[1]*.83f},
                new float[]{b[0],.20f,b[1]},new float[]{a[0],.20f,a[1]},p,n,uv,idx);
        }
        return upload(p,n,uv,idx);
    }
    private Texture landscapeAlbedo,landscapeDetail,lakeAlbedo,lakeDetail;
    private MaterialInstance landscapePaint(String name,float rough){
        boolean lake=name.equals("water");
        if(lake&&lakeAlbedo==null){lakeAlbedo=readTexture("landscape/water_albedo.png",false);lakeDetail=readTexture("landscape/water_normalrough.png",true);}
        if(!lake&&landscapeAlbedo==null){landscapeAlbedo=readTexture("landscape/terrain_albedo.png",false);landscapeDetail=readTexture("landscape/terrain_normalrough.png",true);}
        MaterialInstance mi=texturedMaterial.createInstance();mi.setParameter("baseColor",Colors.RgbType.SRGB,1,1,1);
        mi.setParameter("metallic",lake?.035f:0);mi.setParameter("roughness",rough);
        tryParam(mi,"clearCoat",lake?.08f:0);tryParam(mi,"anisotropy",0);
        mi.setParameter("albedoMap",lake?lakeAlbedo:landscapeAlbedo,textureSampler);
        mi.setParameter("normalRoughMap",lake?lakeDetail:landscapeDetail,textureSampler);
        materialInstances.add(mi);return mi;
    }
    private Mesh makePine(float x,float y,float z,float height,java.util.Random random){
        int layers=9,sides=11,faces=layers*sides;
        float[] p=new float[faces*12],n=new float[p.length],uv=new float[faces*8];int[] idx=new int[faces*6];
        int face=0;
        for(int layer=0;layer<layers;layer++){
            float frac=layer/(float)layers,base=y+height*(.18f+frac*.68f),tip=base+height*.28f;
            float radius=height*.31f*(1-frac*.85f);
            for(int side=0;side<sides;side++){
                double a=side*Math.PI*2/sides,b=(side+1)*Math.PI*2/sides;
                float ra=radius*(.75f+random.nextFloat()*.25f),rb=radius*(.75f+random.nextFloat()*.25f);
                float[] top={x+(float)Math.sin(layer)*.035f,tip,z};
                face=emitFace(0,face,faces,new float[]{x+(float)Math.cos(a)*ra,base,z+(float)Math.sin(a)*ra},
                    new float[]{x+(float)Math.cos(b)*rb,base,z+(float)Math.sin(b)*rb},top,top,p,n,uv,idx);
            }
        }
        return upload(p,n,uv,idx);
    }
    private Mesh makeAuroraRibbon(float radius,int band){
        int count=96;float[] p=new float[count*12],n=new float[p.length],uv=new float[count*8];int[] idx=new int[count*6];
        for(int i=0;i<count;i++){
            double a=Math.PI+i*Math.PI/count,b=Math.PI+(i+1)*Math.PI/count;
            float x=(float)Math.cos(a)*radius,z=(float)Math.sin(a)*radius;
            float bx=(float)Math.cos(b)*radius,bz=(float)Math.sin(b)*radius;
            float y=16+band*1.7f+(float)Math.sin(a*5+band)*1.4f;
            float by=16+band*1.7f+(float)Math.sin(b*5+band)*1.4f;
            float h=1.3f+(float)Math.sin(a*13+band)*.45f;
            emitFace(0,i,count,new float[]{x,y,z},new float[]{bx,by,bz},new float[]{bx,by+h,bz},new float[]{x,y+h,z},p,n,uv,idx);
            int v=i*8;uv[v]=i/(float)count;uv[v+1]=0;uv[v+2]=(i+1)/(float)count;uv[v+3]=0;
            uv[v+4]=(i+1)/(float)count;uv[v+5]=1;uv[v+6]=i/(float)count;uv[v+7]=1;
        }
        return upload(p,n,uv,idx);
    }

    /** World geometry outside the collision footprint, not a background photograph. */
    private void buildSanctuary(MarblePhysics game,float span){
        MaterialInstance rock=texturedPaint(.02f,.85f,0,1);
        MaterialInstance moss=paint(0x4F583A,.0f,.91f);
        MaterialInstance leaves=paint(0x665638,.0f,.88f);
        MaterialInstance bark=paint(0x382B21,.0f,.92f);
        MaterialInstance water=paint(0x4D6770,.46f,.13f);
        addBox(0,-12,0,90,.08f,90,water);
        if(glassMaterial!=null){
            MaterialInstance crystal=crystal(new float[]{.12f,.06f,.025f},1.5f);
            MaterialInstance brass=paint(0xC5A36A,.86f,.23f);
            for(int i=0;i<2;i++){
                float x=(i==0?-1:1)*(game.halfWidth+2.6f),z=-game.halfLength-2;
                addBox(x,-1.3f,z,1,.07f,1,brass);
                List<BoxPart> crystalBlock=new ArrayList<>();
                crystalBlock.add(new BoxPart(x,-.48f,z,.75f,.75f,.75f));
                addChamferedWallBatch(crystalBlock,crystal);
            }
        }
        java.util.Random random=new java.util.Random(6189);
        float exclusion=(float)Math.hypot(game.halfWidth,game.halfLength)+3.6f;
        for(int i=0;i<34;i++){
            float angle=(float)(i*2.399963),radius=exclusion+3+(i%6)*3.7f;
            float x=(float)Math.cos(angle)*radius,z=(float)Math.sin(angle)*radius;
            float width=.75f+random.nextFloat()*2.2f;
            float top=-3.0f+random.nextFloat()*6.3f;
            Mesh cliff=makeCliff(x,z,width,top,random);batchedMeshes.add(cliff);
            addShape(cliff,0,0,0,1,1,1,rock);
            addShape(sphere,x,top+.10f,z,width*.78f,.22f,width*.67f,moss);
            if(i%4==0){
                addShape(cylinder,x,top+1.05f,z,.10f,1.05f,.10f,bark);
                for(int branch=0;branch<6;branch++){
                    float a=branch*2.4f;
                    float dx=(float)Math.cos(a)*(.5f+branch*.13f),dz=(float)Math.sin(a)*(.5f+branch*.13f);
                    addBranch(x,top+1,z,x+dx,top+1.6f+branch*.09f,z+dz,bark);
                    Mesh foliage=makeFoliage(x+dx,top+1.6f+branch*.09f,z+dz,random);
                    batchedMeshes.add(foliage);addShape(foliage,0,0,0,1,1,1,leaves);
                }
            }
        }
        // Tall fractured supports disappear into the valley beneath the playable stone.
        for(int i=0;i<5;i++){
            float x=(i-2)*game.halfWidth*.34f,z=(i%2==0?-1:1)*game.halfLength*.22f;
            Mesh support=makeCliff(x,z,span*.13f,-1.65f,random);batchedMeshes.add(support);
            addShape(support,0,0,0,1,1,1,rock);
        }
        // Distant waterfall ribbons kept well outside all playable cells.
        MaterialInstance falls=paint(0xB2C7CD,.12f,.36f);
        float back=-exclusion-12;
        for(int i=0;i<8;i++)addBox(-8+i*.14f,-4,back,.045f,8,.03f,falls);
    }
    private void addBranch(float x,float y,float z,float bx,float by,float bz,MaterialInstance bark){
        float dx=bx-x,dy=by-y,dz=bz-z,length=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        int entity=addShape(cylinder,(x+bx)*.5f,(y+by)*.5f,(z+bz)*.5f,1,1,1,bark);
        float[] matrix=identity();Matrix.translateM(matrix,0,(x+bx)*.5f,(y+by)*.5f,(z+bz)*.5f);
        Matrix.rotateM(matrix,0,(float)Math.toDegrees(Math.acos(dy/length)),dz,0,-dx);
        Matrix.scaleM(matrix,0,.045f,length*.5f,.045f);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
    }
    private Mesh makeFoliage(float x,float y,float z,java.util.Random random){
        int count=170;float[] p=new float[count*12],n=new float[p.length],uv=new float[count*8];int[] idx=new int[count*6];
        for(int i=0;i<count;i++){
            double a=random.nextFloat()*Math.PI*2;float radius=(float)Math.sqrt(random.nextFloat());
            float px=x+(float)Math.cos(a)*radius*.88f,pz=z+(float)Math.sin(a)*radius*.67f;
            float py=y+(random.nextFloat()-.5f)*.33f;
            float tilt=(random.nextFloat()-.5f)*.08f,leaf=.07f+random.nextFloat()*.07f;
            emitFace(0,i,count,new float[]{px-leaf,py,pz},new float[]{px,py+tilt,pz-leaf*.65f},
                new float[]{px+leaf,py,pz},new float[]{px,py-tilt,pz+leaf*.65f},p,n,uv,idx);
        }
        return upload(p,n,uv,idx);
    }
    private Mesh makeCliff(float x,float z,float radius,float top,java.util.Random random){
        int sides=11,rings=5,faceCount=sides*(rings-1)+sides;
        float[] p=new float[faceCount*12],n=new float[p.length],uv=new float[faceCount*8];
        int[] idx=new int[faceCount*6];float[][][] q=new float[rings][sides][3];
        float[] radii=new float[sides];
        for(int i=0;i<sides;i++)radii[i]=radius*(.78f+random.nextFloat()*.35f);
        for(int r=0;r<rings;r++)for(int i=0;i<sides;i++){
            float angle=i*(float)Math.PI*2/sides;
            float rr=radii[i]*(1+(rings-1-r)*.07f+(random.nextFloat()-.5f)*.11f);
            q[r][i]=new float[]{x+(float)Math.cos(angle)*rr,-16+(top+16)*r/(rings-1),z+(float)Math.sin(angle)*rr};
        }
        int face=0;
        for(int r=0;r<rings-1;r++)for(int i=0;i<sides;i++){
            int j=(i+1)%sides;
            face=emitFace(0,face,faceCount,q[r][i],q[r][j],q[r+1][j],q[r+1][i],p,n,uv,idx);
        }
        float[] center={x,top,z};
        for(int i=0;i<sides;i++)face=emitFace(0,face,faceCount,q[rings-1][i],q[rings-1][(i+1)%sides],center,center,p,n,uv,idx);
        return upload(p,n,uv,idx);
    }
    private void addGoalTile(float x,float z,float half,MaterialInstance mat){
        int segments=64,faces=segments*2;
        float[] p=new float[faces*12],n=new float[p.length],uv=new float[faces*8];int[] idx=new int[faces*6];
        int face=0;float radius=.275f;
        for(int i=0;i<segments;i++){
            double a=i*Math.PI*2/segments,b=(i+1)*Math.PI*2/segments;
            float ax=(float)Math.cos(a),az=(float)Math.sin(a),bx=(float)Math.cos(b),bz=(float)Math.sin(b);
            float ar=half/Math.max(Math.abs(ax),Math.abs(az)),br=half/Math.max(Math.abs(bx),Math.abs(bz));
            float[] ia={x+ax*radius,0,z+az*radius},ib={x+bx*radius,0,z+bz*radius};
            face=emitFace(0,face,faces,ia,ib,new float[]{x+bx*br,0,z+bz*br},new float[]{x+ax*ar,0,z+az*ar},p,n,uv,idx);
            face=emitFace(0,face,faces,new float[]{ia[0],-.30f,ia[2]},new float[]{ib[0],-.30f,ib[2]},ib,ia,p,n,uv,idx);
        }
        Mesh mesh=upload(p,n,uv,idx);batchedMeshes.add(mesh);addShape(mesh,0,0,0,1,1,1,mat);
    }

    private MaterialInstance crystal(float[] absorption,float thickness){
        MaterialInstance mi=glassMaterial.createInstance();
        mi.setParameter("absorption",absorption[0],absorption[1],absorption[2]);
        mi.setParameter("thickness",thickness);materialInstances.add(mi);return mi;
    }
    private static void tryParam(MaterialInstance mi,String name,float value){
        // A fallback shader may not expose an experimental material uniform.
        try{mi.setParameter(name,value);}catch(RuntimeException unavailable){}
    }
    private MaterialInstance paint(int rgb,float metal,float rough){
        return m(((rgb>>16)&255)/255f,((rgb>>8)&255)/255f,(rgb&255)/255f,metal,rough);
    }
    private int addTiltedBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat,float angle){
        int entity=addBox(x,y,z,sx,sy,sz,mat);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.rotateM(matrix,0,angle,1,0,0);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        return entity;
    }

    public void updateMovingWalls(MarblePhysics game){
        if(disposed||game==null)return;
        for(MovingVisual p:movingPieces){
            float[] matrix=identity();
            Matrix.translateM(matrix,0,p.obstacle.atX(game.animationTime),p.height,
                p.obstacle.atZ(game.animationTime));
            Matrix.scaleM(matrix,0,p.halfX,p.halfY,p.halfZ);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(p.entity),matrix);
        }
    }

    private Texture ballTexture(int skin,boolean detail){
        Texture[] store=detail?ballDetails:ballAlbedos;
        if(store[skin]!=null)return store[skin];
        String name="materials/balls/"+VisualStyles.BALL_TEXTURE_KEYS[skin]+
            (detail?"_normalrough.png":"_albedo.png");
        store[skin]=readTexture(name,detail);return store[skin];
    }
    private MaterialInstance texturedBallPaint(int skin){
        MaterialInstance mi=texturedMaterial.createInstance();
        mi.setParameter("baseColor",Colors.RgbType.SRGB,1f,1f,1f);
        mi.setParameter("metallic",VisualStyles.METAL[skin]);
        mi.setParameter("roughness",VisualStyles.ROUGH[skin]);
        tryParam(mi,"clearCoat",skin==0||skin==2||skin==4||skin==7?.95f:.56f);
        tryParam(mi,"anisotropy",skin==0||skin==2||skin==5?.25f:0f);
        mi.setParameter("albedoMap",ballTexture(skin,false),textureSampler);
        mi.setParameter("normalRoughMap",ballTexture(skin,true),textureSampler);
        materialInstances.add(mi);return mi;
    }
    private Texture readTexture(String name,boolean detail){
        try(java.io.InputStream stream=context.getAssets().open(name)){
            BitmapFactory.Options decode=new BitmapFactory.Options();
            // Alpha stores roughness, not opacity. Premultiplication corrupts normals.
            decode.inPremultiplied=false;decode.inScaled=false;
            Bitmap bm=BitmapFactory.decodeStream(stream,null,decode);
            if(bm==null)throw new IllegalStateException("Could not decode "+name);
            Texture result=new Texture.Builder().width(bm.getWidth()).height(bm.getHeight())
                .levels(0xff).sampler(Texture.Sampler.SAMPLER_2D)
                .usage(Texture.Usage.DEFAULT | Texture.Usage.GEN_MIPMAPPABLE)
                .format(detail?Texture.InternalFormat.RGBA8:Texture.InternalFormat.SRGB8_A8)
                .build(engine);
            TextureHelper.setBitmap(engine,result,0,bm);
            result.generateMipmaps(engine);
            return result;
        }catch(IOException ex){throw new IllegalStateException("Missing material asset "+name,ex);}
    }
    private Texture texture(int theme,int kind,boolean detail){
        Texture[][] store=detail?details:albedos;
        if(store[theme][kind]!=null)return store[theme][kind];
        String name=VisualStyles.TEXTURE_KEYS[theme]+"_"+(kind==0?"floor":"wall")+
            (detail?"_normalrough.png":"_albedo.png");
        store[theme][kind]=readTexture("materials/"+name,detail);
        return store[theme][kind];
    }
    private MaterialInstance texturedPaint(float metal,float rough,int theme,int kind){
        MaterialInstance mi=texturedMaterial.createInstance();
        mi.setParameter("baseColor",Colors.RgbType.SRGB,1f,1f,1f);
        mi.setParameter("metallic",metal);
        mi.setParameter("roughness",rough);
        tryParam(mi,"clearCoat",kind==0?.72f:.48f);
        tryParam(mi,"anisotropy",metal>.3f?.35f:0f);
        mi.setParameter("albedoMap",texture(theme,kind,false),textureSampler);
        mi.setParameter("normalRoughMap",texture(theme,kind,true),textureSampler);
        materialInstances.add(mi);
        return mi;
    }
    private static final class BoxPart {
        final float x,y,z,hx,hy,hz,ax;
        BoxPart(float x,float y,float z,float hx,float hy,float hz){this(x,y,z,hx,hy,hz,0);}
        BoxPart(float x,float y,float z,float hx,float hy,float hz,float ax){
            this.x=x;this.y=y;this.z=z;this.hx=hx;this.hy=hy;this.hz=hz;this.ax=ax;
        }
    }
    /** Combine same-material boxes into one vertex/index buffer (low mobile draw-call count). */
    private void addBoxBatch(List<BoxPart> pieces,MaterialInstance mat){
        if(pieces.isEmpty())return;
        if(pieces.size()*24>64000)throw new IllegalStateException("Batch index overflow");
        final float[][] face={
            {-1,-1,1, 1,-1,1, 1,1,1,-1,1,1},
            {1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1},
            {1,-1,1,1,-1,-1,1,1,-1,1,1,1},
            {-1,-1,-1,-1,-1,1,-1,1,1,-1,1,-1},
            {-1,1,1,1,1,1,1,1,-1,-1,1,-1},
            {-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1}
        };
        final float[][] normals={{0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}};
        float[] vertices=new float[pieces.size()*72],normal=new float[vertices.length];
        float[] tex=new float[pieces.size()*48];int[] indexes=new int[pieces.size()*36];
        for(int b=0;b<pieces.size();b++){
            BoxPart p=pieces.get(b);float sin=(float)Math.sin(p.ax),cos=(float)Math.cos(p.ax);
            for(int f=0;f<6;f++)for(int v=0;v<4;v++){
                int i=b*24+f*4+v;float lx=face[f][v*3],ly=face[f][v*3+1],lz=face[f][v*3+2];
                float yy=ly*p.hy,zz=lz*p.hz;
                vertices[i*3]=p.x+lx*p.hx;
                vertices[i*3+1]=p.y+cos*yy-sin*zz;
                vertices[i*3+2]=p.z+sin*yy+cos*zz;
                float nx=normals[f][0],ny=normals[f][1],nz=normals[f][2];
                normal[i*3]=nx;normal[i*3+1]=cos*ny-sin*nz;
                normal[i*3+2]=sin*ny+cos*nz;
                float u=(ny!=0?vertices[i*3]:nx!=0?vertices[i*3+2]:vertices[i*3])*.22f;
                float vv=(ny!=0?vertices[i*3+2]:vertices[i*3+1])*.22f;
                tex[i*2]=u;tex[i*2+1]=vv;
            }
            for(int f=0;f<6;f++){
                int v=b*24+f*4,j=b*36+f*6;
                indexes[j]=v;indexes[j+1]=v+1;indexes[j+2]=v+2;
                indexes[j+3]=v;indexes[j+4]=v+2;indexes[j+5]=v+3;
            }
        }
        Mesh group=upload(vertices,normal,tex,indexes);
        batchedMeshes.add(group);
        addShape(group,0,0,0,1,1,1,mat);
    }
    /**
     * Actual chamfered top edges, not a color-only outline. Colliders stay authoritative
     * and at the exact un-bevelled footprint, so no invisible wall is introduced.
     * Only visual vertices and normals are changed; walls remain permanently visible.
     */
    private void addChamferedWallBatch(List<BoxPart> pieces, MaterialInstance material) {
        final int segments=4, faces=4*(segments+1)+1, max=700;
        for(int start=0;start<pieces.size();start+=max){
            int count=Math.min(max,pieces.size()-start);
            float[] vertex=new float[count*faces*4*3],normals=new float[vertex.length];
            float[] uv=new float[count*faces*4*2];int[] indices=new int[count*faces*6];
            for(int i=0;i<count;i++){
                BoxPart b=pieces.get(start+i);
                float x0=b.x-b.hx,x1=b.x+b.hx,z0=b.z-b.hz,z1=b.z+b.hz;
                float y0=b.y-b.hy,y1=b.y+b.hy;
                float bevel=Math.min(.055f,Math.min(b.hx,b.hz)*.42f);
                float[][] prev={{x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z1}};
                int face=0;
                for(int ring=0;ring<=segments;ring++){
                    double angle=ring*Math.PI/(2*segments);
                    float inset=bevel*(1-(float)Math.cos(angle));
                    float y=y1-bevel+bevel*(float)Math.sin(angle);
                    float[][] next={{x0+inset,y,z0+inset},{x1-inset,y,z0+inset},
                        {x1-inset,y,z1-inset},{x0+inset,y,z1-inset}};
                    for(int side=0;side<4;side++){
                        int n=(side+1)%4;
                        face=emitFace(i,face,faces,prev[side],prev[n],next[n],next[side],vertex,normals,uv,indices);
                    }
                    prev=next;
                }
                emitFace(i,face,faces,prev[0],prev[1],prev[2],prev[3],vertex,normals,uv,indices);
            }
            Mesh mesh=upload(vertex,normals,uv,indices);
            batchedMeshes.add(mesh);addShape(mesh,0,0,0,1,1,1,material);
        }
    }
    private static int emitFace(int item,int face,int faces,float[] a,float[] b,float[] c,float[] d,
            float[] vertex,float[] normal,float[] uv,int[] indices){
        int vi=(item*faces+face)*4,ii=(item*faces+face)*6;
        float[] e={b[0]-a[0],b[1]-a[1],b[2]-a[2]};
        float[] f={d[0]-a[0],d[1]-a[1],d[2]-a[2]};
        float nx=f[1]*e[2]-f[2]*e[1],ny=f[2]*e[0]-f[0]*e[2],nz=f[0]*e[1]-f[1]*e[0];
        float inv=1f/Math.max(.00001f,(float)Math.sqrt(nx*nx+ny*ny+nz*nz));
        float[][] q={a,b,c,d};
        for(int j=0;j<4;j++){
            int v=vi+j;vertex[v*3]=q[j][0];vertex[v*3+1]=q[j][1];vertex[v*3+2]=q[j][2];
            normal[v*3]=nx*inv;normal[v*3+1]=ny*inv;normal[v*3+2]=nz*inv;
            // World-projected UVs keep texture scales coherent between wall segments.
            uv[v*2]=(Math.abs(ny)>.7f?q[j][0]:Math.abs(nx)>.7f?q[j][2]:q[j][0])*.22f;
            uv[v*2+1]=(Math.abs(ny)>.7f?q[j][2]:q[j][1])*.22f;
        }
        indices[ii]=vi;indices[ii+1]=vi+2;indices[ii+2]=vi+1;
        indices[ii+3]=vi;indices[ii+4]=vi+3;indices[ii+5]=vi+2;
        return face+1;
    }

    public void resetBallPose(float x,float z){lastBallX=x;lastBallZ=z;rolling.reset();sink=0;}

    public void updateBall(float x, float z, boolean scored, float dt) {
        if (disposed || ballEntity == 0) return;
        rolling.advance(x-lastBallX,z-lastBallZ,MarblePhysics.BALL_RADIUS);
        lastBallX=x; lastBallZ=z;
        if (scored) sink = Math.min(1f,sink+dt*1.3f);
        float shrink = 1f - .70f*sink;
        float altitude = MarblePhysics.BALL_RADIUS + (currentLevel==null?0:currentLevel.getHeightAt(x,z)) - sink*.46f;
        float[] matrix = identity();
        Matrix.translateM(matrix,0,x,altitude,z);
        float[] rotation=rolling.matrix();
        float[] rotated=new float[16];
        Matrix.multiplyMM(rotated,0,matrix,0,rotation,0);matrix=rotated;
        Matrix.scaleM(matrix,0,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink);
        int instance=engine.getTransformManager().getInstance(ballEntity);
        engine.getTransformManager().setTransform(instance,matrix);
        if(ballRingEntity!=0){
            float[] ring=identity();Matrix.translateM(ring,0,x,altitude,z);
            float[] oriented=new float[16];Matrix.multiplyMM(oriented,0,ring,0,rotation,0);ring=oriented;
            Matrix.scaleM(ring,0,.143f*shrink,.143f*shrink,.143f*shrink);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(ballRingEntity),ring);
        }
        if(followBall){
            float damping=1f-(float)Math.exp(-4.3f*Math.min(dt,.05f));
            // Gentle look-ahead without jumping at each flick or sudden reset.
            float predictedX=x;
            float predictedZ=z;
            focusX+=(predictedX-focusX)*damping;
            focusZ+=(predictedZ-focusZ)*damping;
        }
        ballX=x;ballZ=z;
    }

    private MaterialInstance m(float r,float g,float b,float metallic,float roughness) {
        MaterialInstance mi=material.createInstance();
        mi.setParameter("baseColor", Colors.RgbType.SRGB,r,g,b);
        mi.setParameter("metallic",metallic);
        mi.setParameter("roughness",roughness);
        tryParam(mi,"clearCoat",roughness<.3f?.86f:.16f);
        tryParam(mi,"anisotropy",metallic>.65f?.30f:0f);
        tryParam(mi,"emissive",0f);
        materialInstances.add(mi);
        return mi;
    }
    private int addBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        return addShape(cube,x,y,z,sx,sy,sz,mat);
    }
    private int addShape(Mesh mesh,float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        int entity=EntityManager.get().create();
        new RenderableManager.Builder(1)
                .boundingBox(new Box(0f,0f,0f,1.25f,1.25f,1.25f))
                .geometry(0,RenderableManager.PrimitiveType.TRIANGLES,mesh.vertices,mesh.indices,0,mesh.indexCount)
                .material(0,mat)
                .castShadows(true)
                .receiveShadows(true)
                .culling(false)
                .build(engine,entity);
        scene.addEntity(entity);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        entities.add(entity);
        return entity;
    }
    private static float[] identity() { float[] m=new float[16]; Matrix.setIdentityM(m,0);return m; }
    /** Six continuous HDR faces, filtered by Filament for roughness-aware reflections. */
    private Texture createStudioReflection(boolean arctic){
        final int size=64;
        ByteBuffer bytes=ByteBuffer.allocateDirect(6*size*size*3*4).order(ByteOrder.nativeOrder());
        FloatBuffer pixels=bytes.asFloatBuffer();int[] offsets=new int[6];
        for(int face=0;face<6;face++){
            offsets[face]=face*size*size*3*4;
            for(int row=0;row<size;row++)for(int col=0;col<size;col++){
                float u=2f*(col+.5f)/size-1,v=2f*(row+.5f)/size-1;
                float x=0,y=0,z=0;
                switch(face){
                    case 0:x=1;y=-v;z=-u;break;case 1:x=-1;y=-v;z=u;break;
                    case 2:x=u;y=1;z=v;break;case 3:x=u;y=-1;z=-v;break;
                    case 4:x=u;y=-v;z=1;break;default:x=-u;y=-v;z=-1;
                }
                float inv=1f/(float)Math.sqrt(x*x+y*y+z*z);x*=inv;y*=inv;z*=inv;
                // Wide softboxes, warm key and cool strip; evaluated in direction space.
                float key=(float)Math.exp(-((x+.48f)*(x+.48f)*18+(y-.72f)*(y-.72f)*35+(z-.48f)*(z-.48f)*8));
                float strip=(float)Math.exp(-((x-.82f)*(x-.82f)*90+(y-.25f)*(y-.25f)*4+(z+.52f)*(z+.52f)*14));
                float horizon=(float)Math.exp(-y*y*12);
                float sky=Math.max(0,y);
                if(arctic){
                    float aurora=0;
                    pixels.put(.075f+sky*.055f+horizon*.12f+key*1.0f+aurora*.05f);
                    pixels.put(.085f+sky*.065f+horizon*.105f+key*1.1f+aurora*.13f);
                    pixels.put(.115f+sky*.075f+horizon*.10f+key*1.25f+aurora*.12f);
                }else{
                    pixels.put(.14f+sky*.12f+horizon*.36f+key*4.5f+strip*.45f);
                    pixels.put(.19f+sky*.23f+horizon*.23f+key*2.9f+strip*.65f);
                    pixels.put(.25f+sky*.36f+horizon*.12f+key*1.5f+strip*.95f);
                }
            }
        }
        pixels.flip();
        Texture texture=new Texture.Builder().width(size).height(size).levels(0xff)
            .sampler(Texture.Sampler.SAMPLER_CUBEMAP).format(Texture.InternalFormat.R11F_G11F_B10F).build(engine);
        Texture.PrefilterOptions options=new Texture.PrefilterOptions();options.sampleCount=64;options.mirror=false;
        texture.generatePrefilterMipmap(engine,new Texture.PixelBufferDescriptor(pixels,Texture.Format.RGB,Texture.Type.FLOAT),offsets,options);
        return texture;
    }
    private void createLights() {
        directional(-.62f,-.72f,-.42f,85000f,1f,.83f,.62f);
        int fill=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(4f,7f,5f)
                .color(.60f,.74f,1f).intensity(16000f).falloff(21f).build(engine,fill);
        scene.addEntity(fill);lights.add(fill);
        int key=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(-9f,9f,-5f)
            .color(.94f,.81f,.62f).intensity(13000f).falloff(26f).build(engine,key);
        scene.addEntity(key);lights.add(key);
        int rimLight=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(0f,5f,-11f)
            .color(.44f,.67f,1f).intensity(9000f).falloff(30f).build(engine,rimLight);
        scene.addEntity(rimLight);lights.add(rimLight);
    }
    private void directional(float x,float y,float z,float lux,float r,float g,float b) {
        int light=EntityManager.get().create();sunEntity=light;
        LightManager.ShadowOptions shadows=new LightManager.ShadowOptions();
        shadows.mapSize=2048;shadows.shadowCascades=2;shadows.shadowFar=65f;
        shadows.normalBias=.6f;shadows.shadowBulbRadius=.12f;
        shadows.screenSpaceContactShadows=true;shadows.maxShadowDistance=2f;
        new LightManager.Builder(LightManager.Type.DIRECTIONAL)
                .direction(x,y,z).color(r,g,b).intensity(lux).castShadows(true)
                .shadowOptions(shadows).build(engine,light);
        scene.addEntity(light);lights.add(light);
    }

    // Geometry packing: positions + tangent-frame quaternion, matching Filament lit materials.
    private Mesh upload(float[] vertex,float[] normals,int[] indices){
        int n=vertex.length/3;float[] uv=new float[n*2];
        for(int i=0;i<n;i++){
            uv[i*2]=vertex[i*3]*.5f+.5f;
            uv[i*2+1]=vertex[i*3+2]*.5f+.5f;
        }
        return upload(vertex,normals,uv,indices);
    }
    private Mesh upload(float[] vertex,float[] normals,float[] uv,int[] indices){
        int n=vertex.length/3;
        ByteBuffer verts=ByteBuffer.allocateDirect(n*36).order(ByteOrder.nativeOrder());
        for(int i=0;i<n;i++){
            float nx=normals[3*i],ny=normals[3*i+1],nz=normals[3*i+2];
            float tx,ty=0f,tz;
            if(Math.abs(ny)>.92f){
                // Project onto the normal plane: the old constant X tangent was
                // not perpendicular on the upper sphere, distorting highlights.
                tx=1f-nx*nx;ty=-nx*ny;tz=-nx*nz;
                float length=(float)Math.sqrt(tx*tx+ty*ty+tz*tz);
                tx/=length;ty/=length;tz/=length;
            }
            else{float len=(float)Math.hypot(nz,nx);tx=nz/len;tz=-nx/len;}
            float bx=ny*tz-nz*ty,by=nz*tx-nx*tz,bz=nx*ty-ny*tx;
            float[] q=new float[4];MathUtils.packTangentFrame(tx,ty,tz,bx,by,bz,nx,ny,nz,q);
            verts.putFloat(vertex[i*3]).putFloat(vertex[i*3+1]).putFloat(vertex[i*3+2]);
            for(float v:q)verts.putFloat(v);
            verts.putFloat(uv[i*2]).putFloat(uv[i*2+1]);
        }
        verts.flip();
        ByteBuffer faces=ByteBuffer.allocateDirect(indices.length*2).order(ByteOrder.nativeOrder());
        for(int idx:indices){if(idx<0||idx>65535)throw new IllegalStateException("Mesh too large");faces.putShort((short)idx);}
        faces.flip();
        VertexBuffer vb=new VertexBuffer.Builder().bufferCount(1).vertexCount(n)
            .attribute(VertexBuffer.VertexAttribute.POSITION,0,VertexBuffer.AttributeType.FLOAT3,0,36)
            .attribute(VertexBuffer.VertexAttribute.TANGENTS,0,VertexBuffer.AttributeType.FLOAT4,12,36)
            .attribute(VertexBuffer.VertexAttribute.UV0,0,VertexBuffer.AttributeType.FLOAT2,28,36)
            .build(engine);
        vb.setBufferAt(engine,0,verts);
        IndexBuffer ib=new IndexBuffer.Builder().indexCount(indices.length)
            .bufferType(IndexBuffer.Builder.IndexType.USHORT).build(engine);
        ib.setBuffer(engine,faces);
        Mesh mesh=new Mesh(vb,ib,indices.length);meshes.add(mesh);return mesh;
    }
    private Mesh makeCube() {
        float[][] vertices = {
                {-1,-1,1, 1,-1,1, 1,1,1, -1,1,1},
                {1,-1,-1, -1,-1,-1, -1,1,-1, 1,1,-1},
                {1,-1,1, 1,-1,-1, 1,1,-1, 1,1,1},
                {-1,-1,-1, -1,-1,1, -1,1,1, -1,1,-1},
                {-1,1,1, 1,1,1, 1,1,-1, -1,1,-1},
                {-1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,1}
        };
        float[][] normals={{0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}};
        float[] p=new float[72],n=new float[72];int[] idx=new int[36];
        for(int f=0;f<6;f++) {
            for(int j=0;j<4;j++) for(int c=0;c<3;c++) {p[f*12+j*3+c]=vertices[f][j*3+c];n[f*12+j*3+c]=normals[f][c];}
            int t=f*6,v=f*4; idx[t]=v;idx[t+1]=v+1;idx[t+2]=v+2;idx[t+3]=v;idx[t+4]=v+2;idx[t+5]=v+3;
        }
        return upload(p,n,idx);
    }
    private Mesh makeSphere(int slices,int stacks) {
        int count=(slices+1)*(stacks+1);
        float[] p=new float[count*3],n=new float[count*3],uv=new float[count*2];
        int[] indices=new int[slices*stacks*6];
        int t=0;
        for(int j=0;j<=stacks;j++) {
            double a=Math.PI*j/stacks;
            for(int i=0;i<=slices;i++) {
                double b=2*Math.PI*i/slices;
                int o=(j*(slices+1)+i)*3;
                float nx=(float)(Math.sin(a)*Math.cos(b)),ny=(float)Math.cos(a),nz=(float)(Math.sin(a)*Math.sin(b));
                p[o]=n[o]=nx;p[o+1]=n[o+1]=ny;p[o+2]=n[o+2]=nz;
                int vi=j*(slices+1)+i;uv[vi*2]=i/(float)slices;uv[vi*2+1]=j/(float)stacks;
            }
        }
        for(int j=0;j<stacks;j++) for(int i=0;i<slices;i++) {
            int a=j*(slices+1)+i,b=a+slices+1;
            indices[t++]=a;indices[t++]=a+1;indices[t++]=b;
            indices[t++]=a+1;indices[t++]=b+1;indices[t++]=b;
        }
        return upload(p,n,uv,indices);
    }
    private Mesh makeTorus(int slices,int sides) {
        int count=(slices+1)*(sides+1);
        float[] p=new float[count*3],n=new float[count*3];int[] idx=new int[slices*sides*6];int t=0;
        for(int a=0;a<=slices;a++) for(int b=0;b<=sides;b++) {
            double angle=a*Math.PI*2/slices,v=b*Math.PI*2/sides;
            float cs=(float)Math.cos(angle),sn=(float)Math.sin(angle),cv=(float)Math.cos(v),sv=(float)Math.sin(v);
            int o=(a*(sides+1)+b)*3;
            p[o]=(1f+.075f*cv)*cs;p[o+1]=.075f*sv;p[o+2]=(1f+.075f*cv)*sn;
            n[o]=cv*cs;n[o+1]=sv;n[o+2]=cv*sn;
        }
        for(int a=0;a<slices;a++) for(int b=0;b<sides;b++) {
            int v=a*(sides+1)+b,w=v+sides+1;
            idx[t++]=v;idx[t++]=v+1;idx[t++]=w;
            idx[t++]=w;idx[t++]=v+1;idx[t++]=w+1;
        }
        return upload(p,n,idx);
    }
    private Mesh makeCylinder(int segments) {
        int count=(segments+1)*4+2;
        float[] p=new float[count*3],n=new float[count*3],uv=new float[count*2];
        List<Integer> faces=new ArrayList<>();
        for(int i=0;i<=segments;i++){
            float x=(float)Math.cos(i*Math.PI*2/segments),z=(float)Math.sin(i*Math.PI*2/segments);
            for(int j=0;j<4;j++){
                int v=j*(segments+1)+i;float y=(j==0||j==2)?1:-1;
                p[v*3]=x;p[v*3+1]=y;p[v*3+2]=z;
                if(j<2){n[v*3]=x;n[v*3+2]=z;uv[v*2]=i/(float)segments;uv[v*2+1]=j;}
                else {n[v*3+1]=y;uv[v*2]=x*.5f+.5f;uv[v*2+1]=z*.5f+.5f;}
            }
        }
        int top=count-2,bottom=count-1;p[top*3+1]=1;p[bottom*3+1]=-1;
        n[top*3+1]=1;n[bottom*3+1]=-1;
        for(int i=0;i<segments;i++){
            int a=i,b=segments+1+i;
            for(int v:new int[]{a,b,a+1,a+1,b,b+1,
                top,2*(segments+1)+i+1,2*(segments+1)+i,
                bottom,3*(segments+1)+i,3*(segments+1)+i+1})faces.add(v);
        }
        return upload(p,n,uv,faces.stream().mapToInt(Integer::intValue).toArray());
    }

    @Override public void onNativeWindowChanged(Surface surface) {
        if (swapChain != null) engine.destroySwapChain(swapChain);
        swapChain=engine.createSwapChain(surface);
        if (this.surface.getDisplay()!=null) displayHelper.attach(renderer,this.surface.getDisplay());
    }
    @Override public void onDetachedFromSurface() {
        displayHelper.detach();
        if(swapChain!=null) {engine.destroySwapChain(swapChain);engine.flushAndWait();swapChain=null;}
    }
    @Override public void onResized(int width,int height) {
        if (height<=0) return;
        double aspect=(double)width/height;
        camera.setProjection(46.0,aspect,0.28,140.0,Camera.Fov.VERTICAL);
        view.setViewport(new Viewport(0,0,width,height));
        FilamentHelper.synchronizePendingFrames(engine);
    }
    @Override public void doFrame(long timeNanos) {
        if(!running||disposed)return;
        float elapsed=lastRenderNanos==0?1f/60f:Math.min(.06f,(timeNanos-lastRenderNanos)*1e-9f);
        lastRenderNanos=timeNanos;
        updateCamera(elapsed);
        atmosphereTime+=elapsed;
        for(int i=0;i<auroraCurtains.size();i++){
            float[] curtain=identity();Matrix.translateM(curtain,0,0,(float)Math.sin(atmosphereTime*.12f+i)*.55f,0);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(auroraCurtains.get(i)),curtain);
        }
        for(BoatVisual boat:boats){
            float a=atmosphereTime*.035f+boat.phase;
            float x=boat.x+(boat.cruise?(float)Math.cos(a)*2.8f:0);
            float z=boat.z+(boat.cruise?(float)Math.sin(a)*1.7f:0);
            float yaw=boat.cruise?(float)Math.toDegrees(Math.atan2(2.8f*Math.sin(a),-1.7f*Math.cos(a))):boat.phase*35;
            float[] pose=identity();Matrix.translateM(pose,0,x,-7.52f+(float)Math.sin(atmosphereTime*.8f+boat.phase)*.055f,z);
            Matrix.rotateM(pose,0,yaw,0,1,0);Matrix.rotateM(pose,0,(float)Math.sin(atmosphereTime*.6f+boat.phase)*1.2f,0,0,1);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(boat.parent),pose);
        }
        if(beaconLight!=0){
            float angle=atmosphereTime*(float)(Math.PI*2/90);
            float dx=(float)Math.cos(angle),dz=(float)Math.sin(angle);
            engine.getLightManager().setDirection(engine.getLightManager().getInstance(beaconLight),dx,-.38f,dz);
            float[] beam=identity();Matrix.translateM(beam,0,beaconX,beaconY,beaconZ);
            Matrix.rotateM(beam,0,(float)Math.toDegrees(-angle),0,1,0);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(beaconBeam),beam);
        }
        boolean rendered=false;
        if (uiHelper.isReadyToRender() && swapChain != null && renderer.beginFrame(swapChain,timeNanos)) {
            renderer.render(view);renderer.endFrame();rendered=true;
        }
        graphicsProbe.frame(elapsed,rendered);
        Choreographer.getInstance().postFrameCallback(this);
    }
    public void dispose() {
        if(disposed)return;
        setRunning(false);
        uiHelper.detach();
        for(int id:entities) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(int id:lights) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(Mesh mesh:meshes) {engine.destroyVertexBuffer(mesh.vertices);engine.destroyIndexBuffer(mesh.indices);}
        for(MaterialInstance mi:materialInstances) engine.destroyMaterialInstance(mi);
        engine.destroyMaterial(material);
        engine.destroyMaterial(texturedMaterial);
        if(glassMaterial!=null)engine.destroyMaterial(glassMaterial);
        if(auroraMaterial!=null)engine.destroyMaterial(auroraMaterial);
        for(int t=0;t<7;t++)for(int k=0;k<2;k++){
            if(albedos[t][k]!=null)engine.destroyTexture(albedos[t][k]);
            if(details[t][k]!=null)engine.destroyTexture(details[t][k]);
        }
        for(int t=0;t<8;t++){
            if(ballAlbedos[t]!=null)engine.destroyTexture(ballAlbedos[t]);
            if(ballDetails[t]!=null)engine.destroyTexture(ballDetails[t]);
        }
        if(landscapeAlbedo!=null){engine.destroyTexture(landscapeAlbedo);engine.destroyTexture(landscapeDetail);}
        if(lakeAlbedo!=null){engine.destroyTexture(lakeAlbedo);engine.destroyTexture(lakeDetail);}
        if(beaconLight!=0){scene.removeEntity(beaconLight);engine.destroyEntity(beaconLight);EntityManager.get().destroy(beaconLight);}
        engine.destroyIndirectLight(ambient);engine.destroyIndirectLight(auroraAmbient);
        engine.destroyTexture(studioReflection);engine.destroyTexture(auroraReflection);
        engine.destroySkybox(skybox);engine.destroySkybox(auroraSkybox);
        engine.destroyRenderer(renderer);
        engine.destroyView(view);
        engine.destroyScene(scene);
        engine.destroyCameraComponent(camera.getEntity());
        EntityManager.get().destroy(camera.getEntity());
        engine.destroy();
        disposed=true;
    }
}
