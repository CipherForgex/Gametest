package com.atelier.marble;

/** Saved progress is isolated by volume; original Sanctuary keys remain compatible. */
public final class Volumes {
    public static final int COUNT=2;
    private Volumes(){}
    public static int start(int volume){if(volume<0||volume>=COUNT)throw new IllegalArgumentException("Volume "+volume);return volume*LevelBlueprints.VOLUME_SIZE+1;}
    public static int end(int volume){return start(volume)+LevelBlueprints.VOLUME_SIZE-1;}
    public static int continuation(int volume,int saved){return Math.max(start(volume),Math.min(end(volume),saved));}
    public static int next(int level){return Math.min(end(LevelBlueprints.volumeOf(level)),level+1);}
    public static String progressKey(int volume){start(volume);return volume==0?"v04_progress":"v02_progress";}
}
