package com.atelier.marble;

/** A continuous lake basin and mountain ridge, independent of the maze/pillar meshes. */
public final class AlpineLandscape {
    private AlpineLandscape(){}
    public static final class Geometry {
        public final float[] positions,normals,uv;
        public final int[] indices;
        Geometry(float[] p,float[] n,float[] uv,int[] i){positions=p;normals=n;this.uv=uv;indices=i;}
    }
    private static float smooth(float a,float b,float x){float t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);}
    private static float hash(int x,int z){int h=x*374761393+z*668265263;h=(h^(h>>>13))*1274126177;return (h&0x7fffffff)/(float)Integer.MAX_VALUE;}
    private static float noise(float x,float z){
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z);float fx=x-ix,fz=z-iz;
        fx=fx*fx*(3-2*fx);fz=fz*fz*(3-2*fz);
        float a=hash(ix,iz)*(1-fx)+hash(ix+1,iz)*fx,b=hash(ix,iz+1)*(1-fx)+hash(ix+1,iz+1)*fx;
        return a*(1-fz)+b*fz;
    }
    private static float peak(float x,float z,float cx,float cz,float width,float height){
        float dx=(x-cx)/width,dz=(z-cz)/(width*.82f);return height*(float)Math.exp(-(dx*dx+dz*dz)*.8f);
    }
    public static float height(float x,float z,float clearance){
        float radial=(float)Math.hypot(x,z);
        float shore=(float)Math.sqrt(x*x/((clearance+7)*(clearance+7))+z*z/((clearance+12)*(clearance+12)));
        float land=smooth(.93f,1.26f,shore);
        float ridge=peak(x,z,-28,-38,11,17)+peak(x,z,-7,-46,12,23)+peak(x,z,23,-39,13,20);
        float hills=peak(x,z,-25,0,13,5)+peak(x,z,28,4,12,4);
        float detail=(noise(x*.14f,z*.14f)-.5f)*1.5f+(noise(x*.37f,z*.37f)-.5f)*.6f;
        // The complete lake/play footprint stays below Y=-7.6; scenery never masks the maze.
        return -9.5f+land*(3.0f+ridge+hills+detail)*smooth(clearance,clearance+5,radial);
    }
    public static Geometry build(float clearance){
        final int steps=112,side=steps+1,count=side*side;
        float[] p=new float[count*3],n=new float[p.length],uv=new float[count*2];int[] idx=new int[steps*steps*6];
        for(int z=0;z<=steps;z++)for(int x=0;x<=steps;x++){
            float wx=-65+x*130f/steps,wz=-65+z*130f/steps;int v=z*side+x;
            p[v*3]=wx;p[v*3+1]=height(wx,wz,clearance);p[v*3+2]=wz;
            float dx=(height(wx+.15f,wz,clearance)-height(wx-.15f,wz,clearance))/.30f;
            float dz=(height(wx,wz+.15f,clearance)-height(wx,wz-.15f,clearance))/.30f;
            float inv=1/(float)Math.sqrt(dx*dx+1+dz*dz);n[v*3]=-dx*inv;n[v*3+1]=inv;n[v*3+2]=-dz*inv;
            uv[v*2]=wx*.085f;uv[v*2+1]=wz*.085f;
        }
        int i=0;for(int z=0;z<steps;z++)for(int x=0;x<steps;x++){
            int a=z*side+x,b=a+1,c=a+side,d=c+1;
            for(int v:new int[]{a,c,b,b,c,d})idx[i++]=v;
        }
        return new Geometry(p,n,uv,idx);
    }
}
