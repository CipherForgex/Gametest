package com.atelier.marble;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Deterministic precision physics for ten fixed blueprints. Each rendered wall and
 * each fatal collider use the same Obstacle object; there is no visibility assist.
 * This class deliberately has no Android dependency so CI can test the real rules.
 */
public final class MarblePhysics {
    public static final int LEVEL_COUNT = LevelBlueprints.COUNT;
    public static final float BALL_RADIUS = .145f;
    public static final int[] DX={1,0,-1,0}, DY={0,1,0,-1}, OPP={2,3,0,1};
    private static final float WALL_THICKNESS=.070f;
    public final int level,cols,rows;
    public final float cellSize,halfWidth,halfLength,startX,startZ,goalX,goalZ;
    private final boolean[][] occupied;
    private final int[][] openings, ramps;
    public final List<Obstacle> obstacles;
    public final List<Obstacle> movingObstacles;
    private final String label;
    public float x,z,vx,vz,seconds,animationTime;
    public int crashes;
    public boolean finished,justCrashed;
    private static final float ACCEL=7.1f,DRAG=3.9f,MAX_SPEED=2.5f;

    public static final class Obstacle {
        public final float x,z,halfX,halfZ,sweepX,sweepZ,speed,phase;
        public final boolean moving;
        public Obstacle(float x,float z,float hx,float hz){this(x,z,hx,hz,0,0,0,0);}
        public Obstacle(float x,float z,float hx,float hz,float sweepX,float sweepZ,float speed,float phase){
            this.x=x;this.z=z;halfX=hx;halfZ=hz;this.sweepX=sweepX;this.sweepZ=sweepZ;
            this.speed=speed;this.phase=phase;moving=Math.abs(sweepX)+Math.abs(sweepZ)>.0001f;
        }
        public float atX(float t){return x+sweepX*(float)Math.sin(t*speed+phase);}
        public float atZ(float t){return z+sweepZ*(float)Math.sin(t*speed+phase);}
    }

    public MarblePhysics(int n){
        LevelBlueprints.Blueprint b=LevelBlueprints.at(n);
        level=n;label=b.name;rows=b.rows.length;cols=b.rows[0].length();
        int chapter=LevelBlueprints.chapterOf(n);
        cellSize=.98f-.043f*(chapter-1); // 0.98 at Level 1; 0.593 at Level 10
        halfWidth=cols*cellSize*.5f;halfLength=rows*cellSize*.5f;
        occupied=new boolean[cols][rows];openings=new int[cols][rows];ramps=new int[cols][rows];
        for(int j=0;j<rows;j++){
            if(b.rows[j].length()!=cols)throw new IllegalStateException("Invalid authored row width");
            for(int i=0;i<cols;i++){
                char c=b.rows[j].charAt(i);
                if(c!='.') {occupied[i][j]=true;openings[i][j]=Character.digit(c,16);}
            }
        }
        if(!valid(b.startX,b.startY)||!valid(b.goalX,b.goalY))throw new IllegalStateException("Spawn or goal outside board");
        startX=centerX(b.startX);startZ=centerZ(b.startY);
        goalX=centerX(b.goalX);goalZ=centerZ(b.goalY);
        for(int[] xy:b.rampCells){if(valid(xy[0],xy[1]))ramps[xy[0]][xy[1]]=((xy[0]+xy[1])&1)==0?1:-1;}
        List<Obstacle> walls=new ArrayList<>(),moving=new ArrayList<>();
        final float hw=WALL_THICKNESS;
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)if(valid(i,j)){
            float xx=centerX(i),zz=centerZ(j),edge=cellSize*.5f;
            // A shared edge is generated once. The boundary has a wall on every side.
            for(int d=0;d<4;d++){
                if((openings[i][j]&(1<<d))!=0)continue;
                if(d==2&&valid(i-1,j))continue;
                if(d==3&&valid(i,j-1))continue;
                if(d==0)walls.add(new Obstacle(xx+edge,zz,hw,edge+hw));
                if(d==2)walls.add(new Obstacle(xx-edge,zz,hw,edge+hw));
                if(d==1)walls.add(new Obstacle(xx,zz+edge,edge+hw,hw));
                if(d==3)walls.add(new Obstacle(xx,zz-edge,edge+hw,hw));
            }
        }
        // Fixed hazard coordinates are authored inside the ten blueprint definitions.
        // Sweeps leave usable space on either side; a single obstacle cannot seal the path permanently.
        for(int k=0;k<b.hazardCells.length;k++){
            int[] xy=b.hazardCells[k];
            if(!valid(xy[0],xy[1]))throw new IllegalStateException("Hazard outside board");
            int openingsHere=openingBits(xy[0],xy[1]);
            boolean runsHorizontal=(openingsHere&5)!=0&&(openingsHere&10)==0;
            // These are physical sliding *walls*, not tiny moving pins. Each gate
            // spans most of the passage width, then retracts sideways far enough
            // for the full ball diameter to clear at the right moment.
            float sweep=cellSize*.84f;
            float longHalf=cellSize*.38f;
            Obstacle o=new Obstacle(centerX(xy[0]),centerZ(xy[1]),
                    runsHorizontal?.068f:longHalf,runsHorizontal?longHalf:.068f,
                    runsHorizontal?0:sweep,runsHorizontal?sweep:0,
                    .75f+.14f*k+.035f*chapter,k*1.07f);
            walls.add(o);moving.add(o);
        }
        obstacles=Collections.unmodifiableList(walls);
        movingObstacles=Collections.unmodifiableList(moving);
        resetAll();
        if(!isSpawnClear())throw new IllegalStateException("Spawn collides on level "+n);
    }
    public String shapeName(){return label;}
    public boolean isCell(int i,int j){return valid(i,j);}
    public int openingBits(int i,int j){return valid(i,j)?openings[i][j]:0;}
    public int rampDirection(int i,int j){return valid(i,j)?ramps[i][j]:0;}
    public float centerX(int i){return (i+.5f-cols*.5f)*cellSize;}
    public float centerZ(int j){return (j+.5f-rows*.5f)*cellSize;}
    public int cellCol(float px){return (int)Math.floor(px/cellSize+cols*.5f);}
    public int cellRow(float pz){return (int)Math.floor(pz/cellSize+rows*.5f);}
    private boolean valid(int i,int j){return i>=0&&j>=0&&i<cols&&j<rows&&occupied[i][j];}
    public float getHeightAt(float px,float pz){
        int i=cellCol(px),j=cellRow(pz);
        return valid(i,j)?ramps[i][j]*(pz-centerZ(j))*.095f:0f;
    }
    public float corridorClearance(){return cellSize-2*WALL_THICKNESS-2*BALL_RADIUS;}
    public void resetAll(){crashes=0;animationTime=0;resetRun();}
    public void resetRun(){x=startX;z=startZ;vx=vz=seconds=0;finished=justCrashed=false;}
    public void stop(){vx=vz=0;}
    public void capVelocity(){
        float mag=(float)Math.hypot(vx,vz);
        if(mag>MAX_SPEED){vx*=MAX_SPEED/mag;vz*=MAX_SPEED/mag;}
    }
    public float maxSpeed(){return MAX_SPEED;}
    /** Finger release is an impulse, never a position change. */
    public void flick(float dx,float dz){
        if(finished)return;
        float mag=(float)Math.hypot(dx,dz);
        if(mag<.08f)return;
        float impulse=Math.min(.95f,mag*.64f);
        vx+=dx/mag*impulse;vz+=dz/mag*impulse;capVelocity();
    }
    /** Overhead inspection: advance only time and hazards; marble is immobile. */
    public void inspect(float dt){
        if(finished||dt<=0)return;
        dt=Math.min(dt,1f/30f);
        animationTime+=dt;seconds+=dt;vx=vz=0;
    }
    /** Fixed-step integration; swept collision samples prevent flick tunnelling. */
    public void step(float dt,float sx,float sz){
        if(finished||dt<=0)return;
        dt=Math.min(dt,1f/30f);
        float before=animationTime;animationTime+=dt;seconds+=dt;
        float m=(float)Math.hypot(sx,sz);
        if(m>1){sx/=m;sz/=m;}
        int i=cellCol(x),j=cellRow(z);
        float gravity=valid(i,j)?ramps[i][j]*.73f:0;
        vx+=sx*ACCEL*dt;vz+=(sz*ACCEL-gravity)*dt;
        float friction=(float)Math.exp(-DRAG*dt);vx*=friction;vz*=friction;capVelocity();
        float ox=x,oz=z;
        int segments=Math.max(1,(int)Math.ceil(Math.hypot(vx*dt,vz*dt)/.016f));
        for(int k=1;k<=segments;k++){
            float t=k/(float)segments;
            x=ox+vx*dt*t;z=oz+vz*dt*t;
            if(hitsAnything(before+dt*t)){
                crashes++;resetRun();justCrashed=true;return;
            }
        }
        if(Math.hypot(x-goalX,z-goalZ)<Math.min(.24f,cellSize*.29f)){
            finished=true;vx=vz=0;
        }
    }
    public boolean isSpawnClear(){
        float px=x,pz=z;x=startX;z=startZ;
        boolean ok=!hitsAnything(0);x=px;z=pz;return ok;
    }
    public boolean hitsAnything(float t){
        if(!valid(cellCol(x),cellRow(z)))return true;
        for(Obstacle o:obstacles)if(touches(o,t))return true;
        return false;
    }
    public boolean touches(Obstacle o,float time){
        float cx=o.atX(time);
        float nearestX=Math.max(cx-o.halfX,Math.min(x,cx+o.halfX));
        float zz=o.atZ(time);
        float nearestZ=Math.max(zz-o.halfZ,Math.min(z,zz+o.halfZ));
        float dx=x-nearestX,dz=z-nearestZ;
        return dx*dx+dz*dz<=BALL_RADIUS*BALL_RADIUS;
    }
    public int wallCount(){return obstacles.size()-movingObstacles.size();}
}
