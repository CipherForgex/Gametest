package com.atelier.marble;

/** Calibrated, radial analogue steering. Independent of Android for numeric tests. */
public final class TiltMath {
    private float centreX,centreY,filteredX,filteredY;
    private boolean calibrated;
    public float x,y;
    public void reset(){calibrated=false;filteredX=filteredY=x=y=0;}
    public boolean isCalibrated(){return calibrated;}
    public void centre(float gx,float gy,float gz){
        centreX=roll(gx,gy,gz);centreY=pitch(gy,gz);
        filteredX=filteredY=x=y=0;calibrated=true;
    }
    private static float roll(float x,float y,float z){return (float)Math.atan2(-x,Math.hypot(y,z));}
    private static float pitch(float y,float z){return (float)Math.atan2(y,z);}
    public void update(float gx,float gy,float gz,float dt,float fullAngle,float deadZone){
        if(!calibrated || !Float.isFinite(gx+gy+gz) || fullAngle<=0){x=y=0;return;}
        float targetX=ControlMath.wrapAngle(roll(gx,gy,gz)-centreX)/fullAngle;
        float targetY=ControlMath.wrapAngle(pitch(gy,gz)-centreY)/fullAngle;
        float a=1f-(float)Math.exp(-Math.max(0,Math.min(dt,.1f))/.085f);
        filteredX+=(targetX-filteredX)*a;filteredY+=(targetY-filteredY)*a;
        float magnitude=(float)Math.hypot(filteredX,filteredY);
        float dead=Math.max(0,Math.min(.2f,deadZone));
        if(magnitude<=dead){x=y=0;return;}
        float strength=(float)Math.pow(Math.min(1,(magnitude-dead)/(1-dead)),1.35);
        x=filteredX/magnitude*strength;y=filteredY/magnitude*strength;
    }
}
