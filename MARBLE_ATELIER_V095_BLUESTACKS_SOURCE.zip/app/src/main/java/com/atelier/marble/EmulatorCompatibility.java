package com.atelier.marble;

import android.os.Build;

/** Minimal emulator compatibility detection. Never changes mobile gameplay. */
final class EmulatorCompatibility {
    private EmulatorCompatibility() { }

    static String runtimeAbi() {
        String[] abis = Build.SUPPORTED_ABIS;
        return abis != null && abis.length > 0 ? abis[0] : "unknown";
    }

    static boolean isX86Runtime() {
        String abi = runtimeAbi();
        return "x86_64".equals(abi) || "x86".equals(abi);
    }

    // A conservative initial preset avoids high-cost screen-space effects on
    // virtualized x86 GPU drivers. User selection and saved preferences always win.
    static int initialGraphicsProfile() {
        return isX86Runtime() ? GraphicsProbe.BALANCED : GraphicsProbe.STUDIO;
    }
}
