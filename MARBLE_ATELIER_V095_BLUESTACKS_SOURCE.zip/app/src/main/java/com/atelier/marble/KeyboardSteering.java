package com.atelier.marble;

/** Android-independent held-key steering. No IME, UI elements or per-frame allocations. */
final class KeyboardSteering {
    static final int W=1, A=2, S=4, D=8;
    static final int UP=16, LEFT=32, DOWN=64, RIGHT=128;
    private static final int ALL=W|A|S|D|UP|LEFT|DOWN|RIGHT;
    private int held;

    void setHeld(int key,boolean down){
        if((key&ALL)!=key || Integer.bitCount(key)!=1)return;
        if(down)held|=key;
        else held&=~key;
    }
    boolean anyHeld(){return held!=0;}
    void clear(){held=0;}
    float screenX(){
        final float x=((held&(D|RIGHT))!=0?1:0)-((held&(A|LEFT))!=0?1:0);
        final float y=rawY();
        return x!=0&&y!=0?x*0.70710678f:x;
    }
    float screenY(){
        final float y=rawY();
        final float x=((held&(D|RIGHT))!=0?1:0)-((held&(A|LEFT))!=0?1:0);
        return x!=0&&y!=0?y*0.70710678f:y;
    }
    private float rawY(){
        return ((held&(S|DOWN))!=0?1:0)-((held&(W|UP))!=0?1:0);
    }
}
