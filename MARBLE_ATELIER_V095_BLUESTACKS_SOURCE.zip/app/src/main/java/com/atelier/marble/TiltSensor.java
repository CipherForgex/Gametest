package com.atelier.marble;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.view.Surface;

/** Fused orientation preferred; gravity then filtered accelerometer fallback. UI-thread callbacks. */
public final class TiltSensor implements SensorEventListener {
    private final Activity activity;
    private final SensorManager manager;
    private final Sensor sensor;
    private final float[] rotation=new float[9];
    private final TiltMath math=new TiltMath();
    private float gx,gy,gz,ax,ay,az;
    private long previousTimestamp,lastReading;
    private boolean registered,hasReading;
    private int displayRotation=-1;
    public float fullAngle=(float)Math.toRadians(25),deadZone=.03f;
    public TiltSensor(Activity activity){
        this.activity=activity;manager=(SensorManager)activity.getSystemService(Activity.SENSOR_SERVICE);
        Sensor selected=null;
        if(manager!=null){
            for(int type:new int[]{Sensor.TYPE_GAME_ROTATION_VECTOR,Sensor.TYPE_GRAVITY,Sensor.TYPE_ACCELEROMETER}){
                selected=manager.getDefaultSensor(type);if(selected!=null)break;
            }
        }
        sensor=selected;
    }
    public boolean available(){return sensor!=null;}
    public boolean start(){
        if(registered)return true;
        if(!available())return false;
        hasReading=false;previousTimestamp=0;math.reset();
        try{registered=manager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_GAME);}
        catch(RuntimeException failure){registered=false;}
        return registered;
    }
    public void stop(){if(manager!=null)manager.unregisterListener(this);registered=false;hasReading=false;math.reset();}
    public boolean fresh(){return registered&&hasReading&&SystemClock.elapsedRealtime()-lastReading<300;}
    public boolean centre(){if(!fresh())return false;math.centre(gx,gy,gz);return true;}
    public boolean ready(){return fresh()&&math.isCalibrated();}
    public float x(){return ready()?math.x:0;}
    public float y(){return ready()?math.y:0;}
    @Override public void onSensorChanged(SensorEvent event){
        float dt=previousTimestamp==0?.02f:Math.min(.1f,(event.timestamp-previousTimestamp)*1e-9f);
        previousTimestamp=event.timestamp;
        float x,y,z;
        if(event.sensor.getType()==Sensor.TYPE_GAME_ROTATION_VECTOR){
            SensorManager.getRotationMatrixFromVector(rotation,event.values);
            x=rotation[6];y=rotation[7];z=rotation[8];
        }else{
            x=event.values[0];y=event.values[1];z=event.values[2];
            if(event.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
                float a=hasReading?1f-(float)Math.exp(-dt/.25f):1f;
                ax+=(x-ax)*a;ay+=(y-ay)*a;az+=(z-az)*a;x=ax;y=ay;z=az;
            }
        }
        if(!Float.isFinite(x+y+z)||x*x+y*y+z*z<.01f)return;
        int display=activity.getWindowManager().getDefaultDisplay().getRotation();
        if(displayRotation!=-1&&displayRotation!=display)math.reset();
        displayRotation=display;
        switch(display){
            case Surface.ROTATION_90:gx=y;gy=-x;break;
            case Surface.ROTATION_180:gx=-x;gy=-y;break;
            case Surface.ROTATION_270:gx=-y;gy=x;break;
            default:gx=x;gy=y;
        }
        gz=z;hasReading=true;lastReading=SystemClock.elapsedRealtime();
        math.update(gx,gy,gz,dt,fullAngle,deadZone);
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
}
