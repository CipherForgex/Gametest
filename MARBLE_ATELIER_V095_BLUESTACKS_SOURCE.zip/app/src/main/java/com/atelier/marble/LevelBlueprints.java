package com.atelier.marble;

/** Twenty fixed maze blueprints across two volumes. No runtime maze generator and no hidden collision walls.
 * Hex cell symbols are NESW passage bits; dot is outside the actual board.
 * Curated as static designs for the ten distinct silhouette families.
 */
public final class LevelBlueprints {
  private LevelBlueprints() {}
  public static final int VOLUME_SIZE = 10;
  public static final int COUNT = 20;
  public static int volumeOf(int level){at(level);return (level-1)/VOLUME_SIZE;}
  public static int chapterOf(int level){at(level);return (level-1)%VOLUME_SIZE+1;}
  public static final class Blueprint {
    public final String name; public final String[] rows; public final int startX,startY,goalX,goalY;
    public final int[][] hazardCells,rampCells;
    Blueprint(String name,String[] rows,int sx,int sy,int gx,int gy,int[][] hazardCells,int[][] rampCells){
      this.name=name;this.rows=rows;startX=sx;startY=sy;goalX=gx;goalY=gy;this.hazardCells=hazardCells;this.rampCells=rampCells;
    }
  }
  public static final Blueprint[] MAPS = {
    // Level 1: CIRCLE, 61 traversable cells, solution requires 10 corridor transitions.
    new Blueprint("CIRCLE",new String[]{"...356...",".3696956.",".a95d54a.","2b55435d6","bc356956a","96a1d56a8",".a95629e.",".943cb5c.","...81c..."},3,8,4,5,new int[][]{},new int[][]{}),
    // Level 2: DIAMOND, 97 traversable cells, solution requires 16 corridor transitions.
    new Blueprint("DIAMOND",new String[]{"...35562...","..3c34ab6..",".3d696aa94.","2a2a3ca9636","a9ea95d69ca","b6a9556a36a","a8a374aaaaa","96a896a9cbc",".9e35cb63c.","..9c368a8..","...1c95c..."},3,10,3,4,new int[][]{},new int[][]{}),
    // Level 3: OCTAGON, 124 traversable cells, solution requires 26 corridor transitions.
    new Blueprint("OCTAGON",new String[]{"...157616...",".3755c96976.",".895562968a.","36356ab695d6","a9c3caaa363c","a17c3c8aaa96","b6a1d63ca96a","aa956a96a29c","8b56a96aa974",".96a95cbc3e.",".1ca355c3c8.","...89555c..."},3,11,4,8,new int[][]{},new int[][]{}),
    // Level 4: HEXAGON, 153 traversable cells, solution requires 39 corridor transitions.
    new Blueprint("HEXAGON",new String[]{"...3556174...",".23e15d69636.","3ea9556a3ea96","aab435caa896a","89c3c36ab63ca","356a2aaa8aa2a","b69c9ca96aaaa","a95563d4aaaaa","a163cb63cabca","96aa3c9c1dc3e","1dea9556363e8",".1ca235cabc8.","...89d55c8..."},3,12,8,6,new int[][]{{4,3}},new int[][]{}),
    // Level 5: SPIRAL, 196 traversable cells, solution requires 54 corridor transitions.
    new Blueprint("SPIRAL",new String[]{"37755435557562","aa8363c235c3ca","a95c9c3ea3695e","963543eaaa9568","2a956aaa9d5496","bc36bca956356a","95ca83c35ca2aa","356a3c2974aa9e","a1c9c3d5c3cb5c","b5555d562a3c34","96355569ea9696","3c9563c1c9695e","9435ca3563c35c","15c15dc1dc1d54"},0,13,12,13,new int[][]{{6,13},{12,5}},new int[][]{}),
    // Level 6: STAR, 126 traversable cells, solution requires 68 corridor transitions.
    new Blueprint("STAR",new String[]{".........36.....","........3e96....","..34...3ca2a....",".3c374.a2abc....",".97c9769caa.....","..835e955ca36...","...9683562aa9562","....b5c3ca9c349e","...3c36a1d63d55c","..2a3ca9569d4...",".3c9c3d6296.....",".9635c.aa3d6....","..9c...9ea3c....","........8ab4....",".........88....."},2,9,9,6,new int[][]{{4,10},{9,4},{11,5}},new int[][]{}),
    // Level 7: INFINITY, 225 traversable cells, solution requires 86 corridor transitions.
    new Blueprint("INFINITY",new String[]{"...236.....156...",".36aa974.3556976.","1ebca296.a3696a96","3c83dd497caa3ca1e","a36b4356a2aa96b6a","bcaa3c1de9c95e8aa","96aa9561c355696aa","3c9c36963c3696aaa","a176a95c96a96a9ca","968a95635c96ab56a","3c3d749c356aa83ca","96a1e357c3caa3c3c","1e968a3c.95c9c2b4",".95c3e94.15763dc.","...1c8.....89c..."},3,14,12,3,new int[][]{{9,12},{12,12},{10,6},{4,8},{7,4}},new int[][]{}),
    // Level 8: GEAR, 159 traversable cells, solution requires 101 corridor transitions.
    new Blueprint("GEAR",new String[]{".................",".....16...36.....",".....3d4.1ea.....","..2..95575ca..2..","..b55555c16955e..","..955635569563c..","...35ca36975ca...",".35e35ca96a35c34.","1e2ab55c3ca961d74",".9ca9563c2a2a35c.","...963c969dcaa...","..35c835e356ab6..","..b556968969dca..","..8..96b56a2..8..",".....3e8.9ea.....",".....88...9c.....","................."},5,15,11,10,new int[][]{{3,9},{7,4},{14,5},{9,11},{8,10},{4,7}},new int[][]{{10,2},{7,12}}),
    // Level 9: CLOVER, 155 traversable cells, solution requires 120 corridor transitions.
    new Blueprint("CLOVER",new String[]{"........356........",".......3d496.......",".......a363e.......","......2aa9c96......","......bc9615c......","......9569636......","..236355c3ea96374..","23dca9562a8a29c9756","aa16b62aa95dc35683e","9d6aa9cab5635c3c3c8","..9c9569c3c961d5c..","......a36962a......","......bc96bca......","......962aa3c......",".......bc9ca.......",".......8357c.......","........81c........"},8,16,2,8,new int[][]{{12,9},{18,7},{11,7},{9,2},{7,4},{7,9},{9,14},{4,7}},new int[][]{{15,7},{10,0},{10,12}}),
    // Level 10: MASTER, 272 traversable cells, solution requires 145 corridor transitions.
    new Blueprint("MASTER",new String[]{".........236.........","........3ea96........","....34.3c8b4b6.36....","...1d63d63c3c95c96...","...37ca29c3c15555e...","...a83c9769555636a...","...95d57c95636aaaa...","..3635683569caaaa96..",".3c9c3c3c2956aaa9696.","2b563c1d6b63c89d69696","9d6a9555ca9c1761e2968",".1e961763c355c96bc3c.","..9496aaa3c1635c83c..","...35ca9ca35c9635e...","...b61d63cb556ab6a...","...aa369c1c36aa8aa...","...8aa97556aabd5e8...","....9c.9629ca8.1c....","........9d43c........",".........15c........."},9,19,12,3,new int[][]{{9,16},{3,13},{3,7},{7,10},{11,9},{6,11},{11,11},{14,15},{19,10},{15,9}},new int[][]{{4,14},{5,9},{9,11},{14,11},{18,9}}) ,
    // Volume 2: ten fixed Beacon Harbour maps, curated silhouettes and increasing routes.
    new Blueprint("FJORD",new String[]{".3435556.",".b5c363e.",".956aaaa.",".368aaaa.",".a95c9ca.",".956175c.","...96a...","...3ca...","...81c..."},3,8,3,4,new int[][]{},new int[][]{}),
    new Blueprint("ICE BRIDGE",new String[]{"3762...3754","8aaa...a956","3caa...943c","a3c95763696","a9556aaa96a","a363dc9c29e","aaaa...3e2a","aa9c...a9ca","8954...955c"},0,8,3,7,new int[][]{},new int[][]{}),
    new Blueprint("TERRACES",new String[]{"356355563756","b4a96369c96a","83d4aa9623ca",".a35ca3ca968",".bc35ca1f4a.",".97c3696a3c.","..a3ca1dc96.","..aa295563c.","..8ab5749e..","...894955c.."},3,9,5,0,new int[][]{{9,6}},new int[][]{}),
    new Blueprint("CRESCENT",new String[]{"....15756....","..355694976..",".3e23d555c94.",".aa9d6.......","3c956a.......","b543ca.......","835c2a.......",".a17dc.......",".96955555634.","..95555569c..","....1555c...."},4,10,9,9,new int[][]{{3,6},{5,2}},new int[][]{}),
    new Blueprint("HOURGLASS",new String[]{".35755556176.",".83c3562a3e8.","..97c3cbca8..","...9696a3c...","....94abc....",".....3ca.....",".....a3c.....",".....a96.....","....3c2a2....","...3d6aa96...","..1c3ca96b6..",".355c3f49c96.",".8155c95555c."},1,12,6,11,new int[][]{{5,3},{5,0},{7,7}},new int[][]{}),
    new Blueprint("ICE ISLES",new String[]{"361756...155576","a96a3c...3635ca","969c96...a9c34a","3e361c...b56b6a","a8aa35761d4aaaa","95c9d4a9635c89c",".....3c3ca.....","17623d696975616","3ca9c3c1d6b695e","96955e...a8962a","3c354a...963caa","a2b63c...2a96aa","89c9d4...9d5c9c"},0,12,12,5,new int[][]{{5,7},{9,9},{11,8},{10,1}},new int[][]{{12,11}}),
    new Blueprint("SNOWFLAKE",new String[]{"176....356....374",".8b6...a1c...1e8.","..8b6..b56..17c..","...8b6.83e.17c...","....8975ca17c....",".....3c3695c.....","35556a3c955555756","b6369c9555743683e","89c9563635c3c95c8",".....9c9e36a.....","....17568a9d6....","...37c.96a.1e2...","..1e8..3ca..9d6..",".37c...95e...1e2.","1c8....15c....9d4"},0,14,12,2,new int[][]{{9,12},{15,7},{6,6},{5,8},{4,7}},new int[][]{{5,9}}),
    new Blueprint("BRAIDED FJORD",new String[]{"...374.....236...",".35c8357543eaa36.",".a355c2955caa9ca.",".bc235d6357c962a.",".a1de35ea1c35dca.",".956aa1c955e355c.","...a8a.....a96...","...96a.....a2a...","...1dc.....aaa...",".35555563569c956.",".963743ca1d5556a.",".3c895d6956374aa.",".a35563c35ca969e.",".9d54a95c15d695c.","...15c.....1d4..."},3,14,5,4,new int[][]{{6,9},{9,11},{15,10},{14,1},{9,5},{6,1}},new int[][]{{9,12},{12,5},{8,3}}),
    new Blueprint("CRYSTAL CROWN",new String[]{"...236..376..356...","...bca..aa8..a3e...","...a2a..a96..aaa...","...aa963c3e23ca8...","...ab4aa2a9c9696...","...ab69ca9636a3c...","...a8975c3ea9c96...","...956a36aaa354a...","...23caa9c8bc35c...","...bc1e9555e3c36...","...a37c3636aa3ca...","...aaa3e9ca89d4a...","...9caa836a3556a...","...15c97ca9c15dc...",".......96956.......",".......1c35e.......",".......15c1c......."},7,16,3,13,new int[][]{{8,10},{15,13},{15,8},{13,0},{11,9},{9,5},{6,5},{3,6}},new int[][]{{14,13},{14,2},{7,8},{6,4}}),
    new Blueprint("BEACON",new String[]{"......3437556......","....23d5ca35c36....","...3e9635e835cb6...","..2a96aa1c3c36aa2..",".3ea3caa35d4a9c9e2.",".a8a95c9d435c355ca.","1d6a16..23e..9617e2","36a96a..aa8..2a3caa","a9d69d55e95569ea1dc","962a2356a23696bc356","3e9deb49eaa95c83c3e","a8368a..9ca..36a3ca","96a96a..35c..a9ca3c",".aa2a96295556974aa.",".9ea95cb561695c3e8.","..9d636a1d5d634a8..","...1dc9e35569c3c...","....155ca34975c....","......15c955c......"},6,18,2,4,new int[][]{{16,12},{13,11},{10,12},{9,7},{13,1},{8,2},{5,5},{4,8},{5,13},{1,13}},new int[][]{{14,11},{12,8},{9,4},{5,3},{6,13}})
  };
  public static Blueprint at(int level){if(level<1||level>COUNT)throw new IllegalArgumentException("Level "+level);return MAPS[level-1];}
}
