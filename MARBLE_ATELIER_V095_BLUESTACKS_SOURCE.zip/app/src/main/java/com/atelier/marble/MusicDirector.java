package com.atelier.marble;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.AudioFocusRequest;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.util.ArrayList;
import java.util.List;

/** Two-track asynchronous crossfades. Music owns no SoundPool channels. */
public final class MusicDirector {
    private final Context context;
    private final AudioManager audioManager;
    private final AudioFocusRequest focusRequest;
    private boolean focusGranted;
    private float focusDuck=1;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final List<Track> tracks=new ArrayList<>();
    private String desired="";
    private boolean active,disposed;
    private float volume=.45f,duck=1;
    private int generation;
    private long lastTick;
    private static final class Track {
        final MediaPlayer player;final String path;final int generation;
        float gain,target;boolean ready;
        Track(MediaPlayer p,String path,int gen){player=p;this.path=path;generation=gen;}
    }
    private final Runnable tick=new Runnable(){public void run(){
        if(!active||disposed)return;
        long now=SystemClock.elapsedRealtime();float dt=lastTick==0?.05f:Math.min(.2f,(now-lastTick)/1000f);lastTick=now;
        float alpha=1-(float)Math.exp(-dt/.42f);
        for(int i=tracks.size()-1;i>=0;i--){
            Track t=tracks.get(i);if(!t.ready)continue;
            t.gain+=(t.target-t.gain)*alpha;
            if(t.target==0&&t.gain<.002f){release(t);tracks.remove(i);continue;}
            try{t.player.setVolume(t.gain*volume*duck*focusDuck,t.gain*volume*duck*focusDuck);}catch(IllegalStateException ignored){}
        }
        handler.postDelayed(this,50);
    }};
    public MusicDirector(Context context){
        this.context=context.getApplicationContext();
        audioManager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setOnAudioFocusChangeListener(change->{
                if(disposed||!active)return;
                if(change==AudioManager.AUDIOFOCUS_GAIN){
                    focusGranted=true;focusDuck=1;
                    if(tracks.isEmpty()&&volume>0&&!desired.isEmpty())load(desired);
                    else for(Track t:tracks)if(t.ready)try{t.player.start();}catch(IllegalStateException ignored){}
                }else if(change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK){focusDuck=.18f;}
                else {focusGranted=false;for(Track t:tracks)if(t.ready)try{t.player.pause();}catch(IllegalStateException ignored){}}
            },handler).build();
    }
    private boolean focus(){
        if(focusGranted)return true;
        focusGranted=audioManager.requestAudioFocus(focusRequest)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        return focusGranted;
    }
    public void scene(int volumeIndex,boolean gameplay){
        String path="music/"+(volumeIndex==0?"sanctuary":"aurora")+(gameplay?"_game":"_menu")+".ogg";
        if(path.equals(desired))return;
        desired=path;if(active&&volume>0&&focus())load(path);
    }
    public void volume(float value){
        volume=Math.max(0,Math.min(1,value));
        if(volume==0){stopTracks();audioManager.abandonAudioFocusRequest(focusRequest);focusGranted=false;return;}
        if(active&&tracks.isEmpty()&&!desired.isEmpty()&&focus())load(desired);
    }
    public void duck(boolean paused){duck=paused?.35f:1f;}
    public void resume(){
        if(active||disposed)return;active=true;lastTick=0;
        if(volume>0&&!desired.isEmpty()&&focus())load(desired);
        handler.post(tick);
    }
    public void suspend(){active=false;handler.removeCallbacks(tick);stopTracks();audioManager.abandonAudioFocusRequest(focusRequest);focusGranted=false;focusDuck=1;}
    private void load(String path){
        generation++;
        // A rapidly changed volume cannot leave several pending decoders alive.
        for(int i=tracks.size()-1;i>=0;i--)if(!tracks.get(i).ready){release(tracks.remove(i));}
        MediaPlayer player=new MediaPlayer();Track track=new Track(player,path,generation);
        try(AssetFileDescriptor fd=context.getAssets().openFd(path)){
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());
            player.setLooping(true);player.setVolume(0,0);tracks.add(track);
            player.setOnPreparedListener(p->{
                if(disposed||!active||track.generation!=generation||volume==0){tracks.remove(track);release(track);return;}
                for(Track t:tracks)t.target=0;
                track.ready=true;track.target=1;
                if(focusGranted)try{p.start();}catch(IllegalStateException unavailable){tracks.remove(track);release(track);return;}
                while(tracks.size()>2){
                    Track quietest=null;for(Track t:tracks)if(t!=track&&(quietest==null||t.gain<quietest.gain))quietest=t;
                    if(quietest==null)break;tracks.remove(quietest);release(quietest);
                }
            });
            player.setOnErrorListener((p,what,extra)->{
                android.util.Log.w("MarbleAtelier","Music unavailable: "+path+" ("+what+","+extra+")");
                tracks.remove(track);release(track);return true;
            });
            player.prepareAsync();
        }catch(Exception error){tracks.remove(track);release(track);android.util.Log.w("MarbleAtelier","Music unavailable: "+path,error);}
    }
    private void release(Track t){try{t.player.release();}catch(RuntimeException ignored){}}
    private void stopTracks(){generation++;for(Track t:tracks)release(t);tracks.clear();}
    public void dispose(){if(disposed)return;suspend();disposed=true;handler.removeCallbacksAndMessages(null);}
}
