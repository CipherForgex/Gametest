# MARBLE ATELIER v0.9.5 (build 19) — BlueStacks 5.22.280.1027

Source base: Library v9 source ZIP, Marble Atelier v0.9.4. Original GitHub-facing source ZIP filename preserved.

## Implemented
- Added x86_64 to Android ABI filters, retaining arm64-v8a. Filament/Filamat dependencies unchanged at 1.75.1.
- Kept explicit OpenGL Filament renderer/material compilation (already appropriate).
- x86 runtime now defaults to Balanced graphics on new installs; user custom graphics settings take precedence. All phone defaults unchanged.
- Physical WASD and arrow input remain invisible; touch/tilt and camera-aware physics unmodified.
- Handle attached keyboard/navigation configuration changes without recreating the Activity.
- Version bumped to v0.9.5 build 19.
- No changes to maps, scene geometry, scenery, music, progress storage, Filament texture mipmap flags or physics.

## BlueStacks configuration
1. Create Pie 64-bit or Android 11 64-bit instance in BlueStacks 5.22.280.1027. Nougat below Android API 28 cannot install this app.
2. Set ABI to x86 & ARM, with x86 64-bit and ARM 64-bit selected if Custom is offered.
3. Choose OpenGL Only initially; game is compiled with OpenGL renderer. If it works with Vulkan & OpenGL that is also fine.
4. Try 4 CPU cores and 4 GB RAM if host supports this.
5. Install v0.9.5 APK using BlueStacks side toolbar Install APK or drag-and-drop into instance.
6. In the BlueStacks Game controls menu, turn Game controls OFF to prevent its key mapping from consuming WASD. Then click game window, start a level, test WASD and arrow diagonals.
7. If frame rate is limited, choose Balanced / SAFE in the game's Graphics Lab.

## Verification and remaining work
- Source QA scripts inspect multi-ABI filters, renderer, keyboard and graphics defaults.
- GitHub Actions must confirm APK actually includes arm64-v8a and x86_64 native libfilament-jni + libfilamat-jni, is signed and Android 9+.
- A genuine BlueStacks 5.22.280.1027 installation, first-frame render, input events, materials, sound, and FPS still require your PC. No claim of tested emulator runtime.
- Installation can conflict with a differently signed existing APK; avoid uninstall if preserving local progress is important.
