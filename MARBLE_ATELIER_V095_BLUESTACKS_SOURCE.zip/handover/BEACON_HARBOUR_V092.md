# Beacon Harbour — 0.9.2 / version code 16

Volume 2 is now Beacon Harbour throughout the menu and theme selection. Its final map display name is BEACON. Existing map IDs, layouts, progress and records are preserved. Internal aurora asset names remain compatible.

The maze sits on a solid stepped slate foundation with metal bands and recessed warm lighting. A shoreline lighthouse has a balcony, lantern, conical roof and spotlight rotating once every 90 seconds. Four boats gently bob; one follows a slow cruising path. A jetty, navigation lights, keeper’s house and reeds populate the shore. These are animated scenery, not interactive boat controls or fluid simulation. The former aurora curtains are removed.

Java compilation against Android 36 and Filament/Filamat 1.75.1 passed. Twenty-map physics/collider tests, terrain mesh checks, project preflight, visual contracts and vnext contracts passed. APK packaging and signature validation are performed with Android SDK tools. Actual phone rendering, lighthouse beam appearance, animation performance and volume switching require device review.

Install the new direct APK over the previous direct Sanctuary/Volumes APK; the package and development signing key are retained. Source ZIP keeps its existing filename for the supplied GitHub workflow.
