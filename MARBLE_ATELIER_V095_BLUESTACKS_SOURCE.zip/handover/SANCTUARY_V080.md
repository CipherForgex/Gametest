# Sanctuary 0.8.0

Implemented in the native renderer, not a static mockup: 34 fractured surrounding cliffs, five deep supports, water plane, distant waterfall ribbons, individual leaf geometry and branches; deep textured board foundation; continuous world-scaled stone UVs; brass trim; goal tile with a circular aperture and lit lower socket; corrected cylinder side geometry; warm sun / cool fill and matching HDR sky/reflections; DPCF soft shadows, high-profile screen reflections and valley fog.

The existing collision footprint and ten mazes are retained. The reference bridge mechanisms were not added as new game rules. Glass is Filament solid screen-space transmission with IOR 1.52 and absorption; shader failure is reported in Graphics Lab and uses polished opaque fallback. SAFE mode disables expensive effects.

Menu styling, settings surfaces, compact expandable camera controls, and a live rendered Marble Vault replace the old large HUD and painted marble preview. First launch of this art version selects dark stone and pearl; subsequent choices persist.

Verified: all Java against Android 36 and actual Filament / Filamat 1.75.1 jars, preflight / asset gates, ten-level route and collision checks, camera math, 100000-step quaternion stability, 3% dead zone and progressive tilt checks. APK dex/resources/native libraries packaged and signature verified.

NOT VERIFIED: Android runtime shader compilation, rendered screenshots, touchscreen layouts, S25 sensor behavior, frame rate, memory and thermal performance. Water and waterfall are static geometry; there is no simulated fluid, volumetric cloud or ray tracing. Trees and rocks are generated meshes rather than scanned art. Final cinematic quality must be judged on-device.

Direct APK and source debug build use com.atelier.marble.sanctuary and the label Marble Atelier Sanctuary. The local APK uses a development signing key distinct from GitHub debug signing. Switching between them may require uninstalling this Sanctuary test app. Earlier Studio installation is separate.
