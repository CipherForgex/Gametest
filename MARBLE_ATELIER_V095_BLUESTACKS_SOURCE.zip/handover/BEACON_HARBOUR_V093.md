# MARBLE ATELIER — Beacon Harbour 0.9.3 / code 17

## Source of truth
Continued from Library `/MARBLE_ATELIER_V060_STUDIO.zip`, original version 7, which contained v0.9.2 (code 16). The source ZIP filename is deliberately unchanged to preserve GitHub Actions workflow input. The unchanged 0.9.2 APK remains a rollback candidate, **not** the new 0.9.3 binary.

## Changes authorised (11 October 2026)

1. **Hybrid coastal-crag support**: Replaced the conspicuous upside-down pyramid created by three descending slabs. A procedural irregular ten-ring, 96-sector stratified rock mesh rises from below the lake to a shallow machined slate crown. The large rock silhouette widens toward the natural shoreline and has changes of slope, fractured ledges and offset surfaces. The crown has discreet engineered buttresses, joint seams and warm inset details. The natural rock uses restrained charcoal/sand-grey terrain detail, visually distinct from the maze walls. The new mesh is decorative only; maze geometry and colliders are untouched.
2. **Water-sparkle mitigation**: Increased landscape water PBR roughness 0.20 → 0.54, reduced metallic 0.15 → 0.035 and clearcoat 0.62 → 0.08. Original water texture and the boats' reflections are retained. This targets the repeating bright-dot shimmer seen in the phone video and is **not visually proven** until a new Android screen recording.
3. **Camera framing**: Pinch zoom limit tightened from 0.52–2.60 to 0.66–2.40; a soft bound limits how far the following focal point moves from board centre. Full 360-degree orbit, manual controls and playable overhead remain. Feel/UX needs checking on a real phone.
4. **Restrained scenery population**: Four channel marker buoys and subtle dock fittings near the existing jetty. Boats, lighthouse, its 90-second sweep, reeds, shoreline and original mountain environment preserved.
5. **Gameplay preservation**: 20 fixed blueprints unchanged; volume IDs, map names, save keys, music and physics unchanged; mipmap flag `Texture.Usage.DEFAULT | Texture.Usage.GEN_MIPMAPPABLE` preserved.

## Verification scope

**Passed in source environment**: twenty-level route and collider checks (including all 20 unique fixed blueprints, 3,644 wall colliders, 74 moving hazards); landscape mesh geometry; graphics presets/contract checks; rolling and tilt checks; startup precondition guard; audio/asset presence and PNG integrity; project preflight; new harbour-specific source contract; original map/audio/metadata bytewise preservation audit; source ZIP CRC test.

**Not executed**: Android 36 compile, Gradle assembly, dexing, Filamat shader execution, signed 0.9.3 APK generation, GPU rendering or S25 Ultra FPS. This environment does not have an Android SDK/Gradle/Filament Android dependencies installed and cannot reach the necessary download servers. Existing claims of compilation/package verification apply to **v0.9.2 only**. Do not advertise a 0.9.3 APK as tested/installed.

## GitHub compilation instructions

Replace the existing root `MARBLE_ATELIER_V060_STUDIO.zip` in the repository with this updated archive. Keep `.github/workflows/build-apk.yml` in the GitHub repository; its existing workflow already extracts this ZIP and runs Gradle. The updated workflow inside the archive also adds `python3 tools/test_harbour_v093.py`, but GitHub only executes a workflow YAML from `.github/workflows` in the repository itself. Build and download the debug APK from the resulting Actions run. Source ZIP's internal `app/build.gradle` sets version `0.9.3`, code 17. GitHub debug signing may differ from earlier direct-install APK signing; a signature conflict is not a game-code crash.

## User playtest follow-up

Capture a slow harbour orbit with the full rocky base visible and the rotating beacon beam crossing the lake. Revisit the angle where bright dots previously appeared. Test pinch at min/max zoom, ball follow near the maze edges, touch and tilt gameplay, Sanctuary visual continuity, both volume selections and music. Compare MAX and BALANCED graphics for shimmer and frame pacing.
