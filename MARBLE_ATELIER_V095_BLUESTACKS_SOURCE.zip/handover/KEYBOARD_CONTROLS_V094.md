# MARBLE ATELIER v0.9.4 (18) — Hardware Keyboard Input

Source: exact Library v8 of MARBLE_ATELIER_V060_STUDIO.zip, building on Harbour v0.9.3.

- New `KeyboardSteering.java` tracks concurrent W/A/S/D and arrow keys (including key repeat and opposing directions).
- `MainActivity.dispatchKeyEvent` intercepts gameplay movement keys before HUD focus can consume them; modifier combos are not intercepted. No Android IME, soft keyboard or new HUD controls.
- Diagonals are normalized; uses `ControlMath` to map keyboard directions through the current camera yaw, then calls the existing physics step, with no direct coordinate modification.
- Key-held input temporarily overrides touch/tilt; ordinary controls remain when released. Emulator tilt-calibration can be bypassed by pressing movement key; session-only fallback, no preference writes.
- Clears held keys on focus loss, pause, level changes, menu return, win or lifecycle pause.
- No changes to scenery, geometry, audio, maps, records, graphics settings or signed APK keys.

Testing: `bash tools/test_keyboard.sh` (pure Java key-state and static Android wiring); `python3 tools/check_project.py`, `bash tools/test_physics.sh`, `bash tools/test_tilt.sh`, `bash tools/test_rolling.sh`, `bash tools/test_graphics.sh`, `python3 tools/test_harbour_v093.py`, `python3 tools/test_visual_upgrade.py`, `python3 tools/test_vnext_contracts.py`. Compile and emulator testing must still be performed with Android 36 / Filament dependencies on GitHub.
