# V0.7.0 tilt controls

## Play
Tilt is selected by default on devices with a supported motion sensor. Start a level, hold the phone comfortably, then tap Centre & play. Tap Centre during play to pause and choose a new neutral angle. Resume after a pause also asks for calibration. Touch mode is available from calibration or Settings > Tilt & touch; Try tilt on the touch HUD switches back.

The default dead zone is 3% of the full steering tilt range, radial across both axes, not 3 degrees. Balanced reaches full steering force at 25 degrees from neutral (dead zone approximately 0.75 degrees). Precise uses 35 degrees; Responsive uses 17. Dead zone can cycle through 3%, 5%, 8%, 1%. Preferences persist.

Steering increases smoothly beyond the dead zone using a progressive response curve. More tilt adds more force to the existing acceleration/friction simulation, with its existing speed cap. Opposite tilt brakes, then reverses. Centre removes steering force; momentum and existing ramp gravity still act. No direct position or velocity teleport is used for steering.

## Implementation
- Android GAME_ROTATION_VECTOR preferred, then GRAVITY, then low-pass-filtered ACCELEROMETER. Game rotation provides fused attitude without requiring magnetic north.
- Device/display axes are mapped before calibration. Camera yaw maps the screen steering vector to the maze every rendered frame.
- Time-based 85ms steering smoothing; accelerometer-only fallback additionally filters gravity at 250ms.
- Fresh-reading gate (300ms): sensor loss or display rotation invalidation pauses play for calibration. Registration failure/no sensor falls back to touch.
- Listeners register while the foreground activity uses tilt, unregister when backgrounded or switching to touch. Backgrounding pauses the game and clears input.
- Single-finger flick is disabled in tilt mode. Two-finger camera gestures remain available and suppress steering until fingers lift.
- Existing GEN_MIPMAPPABLE graphics-startup fix retained.

## Verification
PASS Java 17 compilation of all app sources against Android API 36 and Filament 1.75.1.
PASS neutral calibration at a comfortable angle; 3% radial dead zone; continuous threshold; monotonic steering force; reverse input; diagonal cap; smoothing onset; zero force at neutral; sample-rate independence; 90-degree camera mapping; lifecycle reset.
PASS existing level physics, graphics switches, visual/source contracts, texture integrity and quaternion-rolling tests.
The old workflow's test_rolling.sh entry point now also invokes test_tilt.sh.

Not verified: physical sensor direction/latency and comfort on an S25 Ultra, startup/rendering on hardware, on-device pause/resume and camera gestures. No emulator or hardware sensor test is claimed. If either axis feels reversed or twitchy, report which direction you tilted and which way the ball moved.

## Build
Version 0.7.0, code 12. The ZIP keeps the name MARBLE_ATELIER_V060_STUDIO.zip for compatibility with your existing workflow. Replace that repository ZIP and rerun Actions; no YAML edit required. Studio debug package remains separate from the original game.

Android references:
https://developer.android.com/develop/sensors-and-location/sensors/sensors_position
https://developer.android.com/develop/sensors-and-location/sensors/sensors_motion
https://developer.android.com/develop/sensors-and-location/sensors/sensors_overview
