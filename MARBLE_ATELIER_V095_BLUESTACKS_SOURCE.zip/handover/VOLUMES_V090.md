# Volumes 0.9.0

## Implemented

Sanctuary keeps its original ten map definitions and warm world. Aurora adds Fjord, Ice Bridge, Terraces, Crescent, Hourglass, Ice Isles, Snowflake, Braided Fjord, Crystal Crown and Aurora. Footprints and fixed passage layouts differ from Volume 1. Solution distances rise 12 → 22 → 33 → 46 → 60 → 77 → 96 → 116 → 139 → 162. Difficulty scaling restarts at chapter 1, avoiding impossible narrow corridors on global maps 11–20. Gates and ramps are included in later maps.

Aurora's independent scene uses pale CC0 marble, silver trim, cold lighting, a blue HDR reflection/sky environment, fjord water, generated ice formations and translucent, softly animated light curtains. Shader failures are recorded with a simpler glow fallback. Menu typography, accents and panel colors switch with the volume.

A volume selector drives live menu scenery. Per-volume continue and records are isolated, Sanctuary's existing progress key is preserved, and chapter numbers remain 01–10. Volume endpoints do not spill into the next volume.

Original music: Sanctuary menu/game (56.471 s) and Aurora menu/game (53.333 s). Authored chord progressions and melodies are synthesized into piano/bell/pad voices without external samples. Gameplay tracks have lower decoded RMS/peaks than menu tracks. Note tails and reverb wrap around the loop. Android MediaPlayer provides looping, asynchronous prepare and two-track crossfades. Music/effects sliders persist independently; music-off releases players. Backgrounding releases audio and focus; foregrounding resumes the desired track. Audio focus loss pauses tracks or ducks them as requested by Android.

## Verified locally

Java compilation against Android SDK 36 / actual Filament & Filamat 1.75.1 jars. Twenty unique connected solvable maps, all passage centrelines free of fixed invisible colliders, spawn/goal/reset and sliding gate clearances. Per-volume navigation and corrupt-progress clamping. Original Sanctuary map data unchanged against the preceding source ZIP. Existing rolling and tilt checks pass. All four Ogg tracks decode to stereo PCM; no clipping or large loop-boundary jump; quieter gameplay arrangements. 44 valid material maps. APK resources, dex, native libraries, stored Ogg/WAV assets and signature checked.

## Still needs device verification

Aurora appearance, transparency sorting, actual shader execution, frame rate and thermals; music listening quality, decoder loop timing, crossfade transitions, focus interruption and sliders on S25 Ultra. No physical device or booted Android emulator was available. Headless checks are not screenshot proof. The music is an original synthesized arrangement, not a live orchestral recording.
