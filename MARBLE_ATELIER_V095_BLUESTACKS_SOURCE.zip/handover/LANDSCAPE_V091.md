# Aurora landscape revision 0.9.1

The white ice columns and round snow caps have been removed from Volume 2. Its world is now a continuous generated alpine basin with three broad overlapping mountain ridges, a lake, subtle water ripple maps, shoreline boulders and layered pine meshes. Narrow metal supports replace the large stone foundation columns. The mountain terrain is its own 12,769-vertex mesh, rather than Sanctuary's repeated cliff primitive.

Aurora board maps now use muted neutral slate values. Sun illumination, ambient intensity, blue color cast and exposure have been reduced; distance fog and two faint aurora curtains give depth without overwhelming the playing surface. Warm Sanctuary lighting is explicitly restored when changing volumes.

The twenty map definitions, gameplay physics, volume progress rules and all four music files were compared byte-for-byte to 0.9.0 and remain unchanged.

Verified: full Java compilation against Android/Filament jars; all twenty route/collider checks; terrain index limits, winding, finite coordinates, normalized normals, lake/mountain height and clearance for three representative maze footprints. Asset preflight and APK signature/package checks passed.

Remaining device checks: actual landscape composition, brightness, shoreline material appearance, orbit views, frame rate and thermal performance on S25 Ultra. No new runtime shader was introduced for terrain or water; they use the existing textured PBR material. Water ripples are static normal maps, not a fluid simulation. Generated terrain/trees are original project work.
