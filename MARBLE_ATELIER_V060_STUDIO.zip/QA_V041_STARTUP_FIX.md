# Marble Atelier V0.4.1 — Filament JNI startup hotfix

## Reported device failure
Samsung S25 Ultra screenshot: MARBLE ATELIER / Graphics could not initialise / UnsatisfiedLinkError: No implementation found for `com.google.android.filament.TextureSampler.nCreateSampler(...)`.

## Confirmed source root cause
Java instance field initializers execute before the `FilamentBoard(Activity)` constructor body. V0.4 initialized `TextureSampler` in the field declaration, before `Filament.init()`. As a result its JNI `nCreateSampler()` call was attempted before the native Filament library had been loaded.

## V0.4.1 change
- Declare `private final TextureSampler textureSampler;` without native construction.
- Call `Filament.init()` first in `FilamentBoard(Activity)`.
- Construct sampler immediately after native load, before creating `Engine`.
- Add `tools/test_filament_startup.py` (also invoked by the general preflight).
- Raise versionCode from 5 to 6, versionName to `0.4.1`.
- Keep exactly ten levels, physics, textures, menu and gameplay otherwise unchanged.

## Local test results
- PASS: the startup order static regression test.
- PASS: intentional reintroduction of field initializer causes startup regression test failure.
- PASS: `tools/check_project.py` (asset integrity, contracts, dependencies).
- PASS: `tools/test_physics.sh` (10 levels, 35 moving barriers, 10 ramps, collision/reset, flick, overhead, goal).
- PASS: clean ZIP extraction and rerun of all local checks.
- NOT RUN: Android compilation (no Android SDK/Gradle dependencies locally).
- NOT RUN: launch/Filament rendering on Samsung.

## Device instructions / caveats
Upload the updated `MARBLE_ATELIER_GAME.zip` under the exact same name to GitHub and use `.github/workflows/build-apk.yml` from the assistant's full inline YAML. Run the workflow and install the artifact APK. If Android reports `App not installed` due to signature mismatch with a previous CI debug build, the older app may need to be uninstalled, which erases its local best times/preferences. Please back up anything important first; avoiding this requires using a persistent debug signing key across CI runs. Never use a public test signing key as a production signing key.

## Limitations
This source hotfix addresses the crash visible in the supplied screenshot, but cannot guarantee there are no subsequent Filament shader, texture, GPU-driver or runtime errors. The APK launch and gameplay must be tested on the phone. Do not claim a verified working APK before that succeeds.
