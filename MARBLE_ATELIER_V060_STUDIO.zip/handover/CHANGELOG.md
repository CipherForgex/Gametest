# 0.6.1 startup fix

Added the required Filament GEN_MIPMAPPABLE texture usage flag. Fixes the reported generateMipmaps startup precondition exception. Version code 11. Existing GitHub workflow remains compatible. Device retest required.

# Marble Atelier 0.6.0 — Studio materials and motion

Based on the supplied VNext source (0.5.0, version code 9). New version: 0.6.0 / 10.

- Replaced all 40 material maps: distinct dark stone, titanium, ivory marble, frost, warm stone and violet ceramic families. The eight marble designs now have recognisable veins, ribbons or maker marks.
- Added a 64px-per-face HDR studio environment, prefiltered by Filament for roughness-aware reflections. Warm softbox and cool strip highlights are evaluated continuously across cubemap faces.
- Added trilinear mipmapping. Disabled bitmap alpha premultiplication: normal-map alpha encodes roughness, not transparency.
- Increased marble sphere from 30 × 20 to 64 × 40 segments. Corrected non-orthogonal pole tangents. Materials remain opaque PBR: glacier/quartz are stone/glaze finishes, not transmissive glass.
- Replaced one-facet wall shoulders with four-segment rounded shoulders. Collision footprints unchanged. Reduced batched geometry count per batch to remain below 16-bit vertex limits.
- Slimmed the maze chassis, replaced the stacked square support with a cylindrical pedestal, and added external sculptural props and studio floor inlays. No prop enters the playable collision area.
- Replaced Euler spin with accumulated, normalised quaternion rolling using angle = distance / radius. Decorative rings share the ball orientation.
- Added visual interpolation between fixed 60Hz physics steps. Resets clear pose and interpolation; no artificial spin across teleports. Collision rules and ten authored levels retained.
- Reworked main-menu typography and navigation spacing; redesigned settings categories with descriptions; added button ripple feedback.
- Added visible labels and tooltips to camera controls, separated restart, and added an in-game camera/gesture help panel that pauses the run.

Four stone families derive from Poly Haven CC0 white_marble and marble_01. Remaining maps, the studio environment and runtime meshes are original mathematical assets. Source maps and verified MD5 values are bundled under tools/source_materials. No purchased packs or downloaded 3D models are represented as included.
