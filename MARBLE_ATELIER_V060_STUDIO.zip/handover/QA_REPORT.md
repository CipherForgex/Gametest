# V0.6.1 startup hotfix

The S25 Ultra screenshot confirmed a native Filament precondition failure: `generateMipmaps` was called on a texture missing `GEN_MIPMAPPABLE` usage. This was introduced by the V0.6 mipmap change. The texture builder now explicitly combines `Texture.Usage.DEFAULT | Texture.Usage.GEN_MIPMAPPABLE`, retaining upload and sampling permissions.

Confirmed against Filament v1.75.1 Texture.java. A preflight regression guard now checks the required flag. The reflection cubemap uses generatePrefilterMipmap, a separate CPU filtering/upload path, and does not call generateMipmaps.

Version code 11 / version 0.6.1. ZIP filename remains MARBLE_ATELIER_V060_STUDIO.zip so the existing GitHub workflow can be used unchanged. Replace the old repository ZIP; rerun Actions.

Device startup still needs retesting; compilation and structural checks cannot prove runtime rendering. Previous V0.6 results follow for context.

# V0.6.0 verification — 11 October 2026

## Passed
- Java 17 compilation of all game source against Android API 36 and actual Filament / Filamat 1.75.1 libraries. Android deprecation notes only.
- SDK packaging using aapt2, d8, zipalign and apksigner. Signature v3, ZIP integrity and 16 KiB alignment checks passed.
- Ten maze tests: solvable routes, increasing route length, collision/opening consistency, hazards, ramps, goals, restart, flick and camera/control maths.
- Graphics feature switches, fallback and diagnostic reporting tests.
- Quaternion rolling: full circumference, quarter-turn direction, reversal, diagonal reversal, reset, and orthonormality after 100,000 movements.
- All 40 runtime PNGs passed header, size, chunk CRC and completion checks; three WAV cues valid.
- Poly Haven downloads verified against provider MD5 values; source maps and provenance included.
- Existing visual/source contracts passed. Structural checks are not rendering proof.

## Not verified
- Gradle assembleDebug failed to resolve the Android build plugin through this environment's network connection. The provided APK was compiled and packaged directly with Android SDK tools. The supplied standard Gradle GitHub workflow has not been run on GitHub in this session.
- Android emulator software boot did not complete during the runtime attempt. No gameplay screenshot, GPU render or successful app startup is claimed.
- S25 Ultra frame rate, thermal behaviour, visual appearance and sustained gameplay still need device testing. No guaranteed 60/120 FPS claim.
- Balls are genuine high-resolution sphere geometry with PBR finishes, not downloaded GLB models. Transmissive glass is not implemented.
- Rotation matches horizontal travelled distance. The existing physics engine does not simulate angular slip or full rigid-body ramp rolling.

## Installation
The development APK is `Marble Atelier Studio`, package `com.atelier.marble.studio`. It installs beside the original game, with independent progress. Release package ID remains unchanged. GitHub debug signing may differ from this APK; a later conflicting Studio build can require removing only the Studio test installation, losing its test progress. Keep your original game installed.

## Device checks
1. Launch Studio; compare the ivory board and dark marble with the old game. Check for an error/fallback page.
2. Open menus/settings/help. Help should pause the timer; resume should preserve the run.
3. Roll slowly, reverse and turn: surface patterns should roll with travel. Wall resets should not spin or slide across the board.
4. Test rotate/pinch/top view/reset, steering and permanently visible walls.
5. Compare SAFE, BALANCED, STUDIO and MAX for shimmer or lighting faults. Export the graphics report if needed.
6. Check moving walls and ball contact height on ramp levels.

Raw local output: TEST_RESULTS.txt, JAVA_COMPILE.txt, APK_VERIFICATION.txt. Older reports are in v050/.
