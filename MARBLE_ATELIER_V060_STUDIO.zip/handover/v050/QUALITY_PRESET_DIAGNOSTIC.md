# Quality-preset symptom: glitches disappear on Maximum

**Observed by user**: visual glitches appear on non-Maximum modes; turning graphics to Maximum reportedly stops them. No device video annotated by per-preset capture was available as a live, reproducible Android render in this coding environment.

## Source-based differential, V0.4.3
- Maximum enables experimental reflections, higher SSAO/bloom, temporal AA, multisampling, dynamic resolution, high-profile fog and optional DPCF/VSM shadow type (by reflective Filament API calls where available).
- Studio enables temporal AA, AO and bloom, some fog/vignette, dynamic resolution, but not Maximum-only reflection/MSAA.
- Balanced disables several effects, uses FXAA/AO, dynamic resolution.
- Safe disables additional effects, previously **disabled FXAA entirely** while retaining all geometry/material construction; all modes use same scene content.
- Probe records attempted runtime reflection calls, but currently cannot prove a GPU feature was accepted unless Filament didn't throw. Feature toggles are not an authoritative frame capture.

## Applied source changes
1. FXAA is enabled as a consistent lightweight correctness-independent baseline for **all** tiers. Optional high-end features remain selectable. This reduces edges/shimmer differences but is NOT proof it fixes the reported glitches.
2. Near/far projection updated from `.1 / 180` to `.28 / 140` for improved depth precision. Must verify long-range view geometry and clipping on the device.
3. Wall and base meshes remain independent of quality settings and all walls remain visible. No shader variants are chosen by selected graphics tier in game code.
4. Kept existing experimental reflection/MSAA/fog switches intact; no silent removal of graphics capabilities or defaulting everything to Maximum.

## Hypotheses (NOT confirmed causes)
- Different anti-aliasing, dynamic-resolution or temporal-AA combinations expose thin-edge shimmer/aliasing.
- Camera/depth precision and coplanar metal edges cause z-fighting dependent on shader/AA mode.
- Reflective optional Filament API calls degrade differently across installed GPUs/drivers.
- Incomplete native resources/async shader compilation or lifecycle synchronization.

## Reproduction request
On Samsung S25 Ultra run each of levels 1, 5, 8, 10 in SAFE, BALANCED, STUDIO, MAX. Capture same location and camera angle with preset label visible. Record whether walls vanish, surfaces flicker, texture appears incorrect, or postprocess halos shimmer. Export Graphics Lab diagnostic for each mode. If repeating, isolate TAA/MSAA/dynamic-resolution/shadow/reflection toggles one at a time, then address confirmed root cause. Without those captures, bug status remains **OPEN / UNVERIFIED**.
