# Copy/paste GitHub Android build instructions

This source ZIP is an Android Studio/Gradle project **at ZIP root**, not a compiled app. It is designed for your Android-phone GitHub workflow, retaining the old 'one source ZIP uploaded to repository root' approach.

1. In your GitHub repository, upload **`MARBLE_ATELIER_VNEXT_VISUAL_GAMEPLAY_SPRINT.zip`** as a single file to the repository root (the files inside this archive do not need individually uploading). Keep V0.4.3 safe.
2. Open **`.github/workflows/build-apk.yml`** on the GitHub website. Create it if absent and paste in the separately provided `MARBLE_ATELIER_VNEXT_GITHUB_BUILD.yml` contents. GitHub cannot read a workflow buried inside an uploaded ZIP to trigger itself; it must exist as a real repository YAML file.
3. In **Actions**, choose **Build Marble Atelier V0.5.0 APK**, click **Run workflow** on your build branch.
4. Wait for **green Build APK** and **Verify APK** steps. Under Artifacts, download **MARBLE_ATELIER_V050_INSTALL_APK**. Extract artifact ZIP and install `app-debug.apk` (if signing certificates match previous installed app).
5. If red, download **MARBLE_ATELIER_V050_BUILD_LOGS**, open the first red step and return the logs for an exact compile fix. The source isn't an APK until this build works.

### Under the hood
- Java 17, Android platform 36 and build-tools 36, Gradle 8.13 (via `gradle/actions/setup-gradle@v4`), Android Gradle Plugin 8.13.2.
- The workflow extracts the uploaded source ZIP in CI and performs project/static/physics/graphics contracts, builds debug APK and verifies APK signature plus two Filament native libraries.
- No Android wrapper JAR is bundled, so the CI action explicitly installs Gradle.
- Only test-signed debug APKs: **not production Play Store releases**.
- Potential install conflict: each fresh debug-keystore signature may differ, so do **not** uninstall an existing app casually if its stored progress is important. For smooth upgrades, set up a stable test keystore in GitHub encrypted secrets.
