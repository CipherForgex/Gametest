# MARBLE ATELIER V0.5 — Luxury Product Studio

## Chosen production direction
A handcrafted *ivory-ceramic and champagne-metal precision instrument*, suspended above a quiet blue-black product-photography cyclorama. The maze and moving marble are the product; the environment does not borrow the maze's own texture. No neon spectacle and no oversized futuristic slab.

### Visual material roles
- **Floor**: subdued ivory honed-stone original PBR texture; broad areas stay visually calm while microfine geological lines add depth.
- **Walls**: subtly darker, warmer ceramic with 3D chamfered upper shoulder and separate metallic detail cap; collision footprint unchanged.
- **Manufactured housing**: charcoal anodised physical layers following the authored cell silhouette, narrow champagne edge, recessed inner band, exterior machine-metal strips, dark stepped pedestal and subtle under-clearance.
- **Backdrop**: neutral blue-black matte studio stage, never the same floor/wall texture; skybox dark. Physically separated from playfield.
- **Hero marble**: smoked-quartz coloured original procedural surface, with existing eight selectable finishes preserved. Default set to smoked quartz for sharp value contrast against ivory; rolling movement remains physically driven.
- **Lighting**: existing Filament lit PBR, warm key, cold fill, low rim; neither simulated IBL from a fake image nor unlicensed HDRI. Keep restrained bloom and optional AO.
- **UI**: warmer bone-white display type and cool-gray supporting text. Existing working pages remain, rather than replacing navigation with a new untested interface.

### Implementation bounds
- `FilamentBoard.java`: static decorative geometry below ground; no new obstacle collisions, preserves all authored obstacle transforms.
- `MainActivity.java`: default new-install theme becomes ivory; previously stored choices still read. Playable top-down view; camera geometry does not lock input.
- `VisualStyles.java`: existing eight skin indices and texture keys remain, with skin #3 display renamed SMOKED QUARTZ.
- `tools/generate_atelier_materials.py`: 40 deterministic, locally made 512×512 PBR maps. `normalrough` stores OpenGL-style tangent normal XYZ and roughness in alpha. Not 8K sources rebranded as mobile quality.

### Device inspection checklist
At game size, confirm ball-to-floor edge readability; inspect top-down, orbit and moving doors; confirm tile seams do not read as unwanted cracks; inspect floor metal trim intensity on all six selectable themes. Exact matching before/after real game screenshots and 10-minute thermal tests await a real Android device.
