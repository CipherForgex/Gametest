# Marble Atelier V0.5.0 — Luxury Product Studio source revision

This is a **substantive SOURCE change**, not a signed/tested Android release. The complete project is suitable for uploading to GitHub and running the separate included build workflow. Do not call it an installable APK until an actual Gradle build succeeds.

## Implemented from V0.4.3
1. **Maze presentation:** 12 redesigned floor/wall source materials (24 maps), smaller fine-grain finish, floor-vs-wall value separation, restrained wall saturation, new inset crown highlight and foot grooves; retains all physical wall footprints.
2. **Pedestal:** removed the visually crude full-board under-slab design, added a narrower tiered plinth and dark inset edge bands, chamfered multi-layer irregular body and bronze rim to follow the 10 authored maze silhouettes.
3. **Background:** abandoned theme-matching texture; uses separate dark neutral studio PBR material and stage at -2.15, dark skybox, offset color/value from hero maze.
4. **Marbles:** eight regenerated 512×512 finish pairs (16 assets), selected contrasting original `SMOKED QUARTZ` finish as default for first installs; preserves all existing IDs and skin choices.
5. **Camera/gameplay:** overhead view now allows active drag/flick motion instead of locking the ball. Physics still uses the same fixed-step implementation, saved times and level data.
6. **Graphics:** consistent lightweight FXAA across presets and improved camera depth precision; 11 pre-existing experimental feature switches preserved. Underlying user-reported MAX-only bug still requires device reproduction.
7. **UI polish:** warmer editorial palette and first-run ivory/champagne theme default, while stored user theme/marble choices remain honored.
8. **CI and QA:** included GitHub Actions APK workflow, headless smoke tests, material provenance and full worklist/reproduction plan.

## What did *not* happen
- No compatible HDRI was downloaded or integrated. The container DNS cannot reach outside file hosts; researched sources are linked in docs.
- No Google Filament/Android Gradle compilation, actual APK, phone frame screenshots, or physical-device performance tests.
- No wall collision rules, authored ten level layouts, records, progress, or offline architecture were removed.
- No three-hour continuous session was performed: the environment permitted a shorter interactive engineering pass. Dates and command evidence are given precisely; no fabricated time log.

See `QA_REPORT.md`, `QUALITY_PRESET_DIAGNOSTIC.md`, `WORKLIST.md` and `KNOWN_ISSUES_AND_NEXT_STEPS.md` for remaining verification.
