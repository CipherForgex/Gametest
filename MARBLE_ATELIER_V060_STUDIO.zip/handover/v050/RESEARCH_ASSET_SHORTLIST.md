# Verified asset/style shortlist — October 11, 2026

All candidate pages below were researched for inspiration or eventual integration; none of these external files were installed, due to a download-network DNS block. URLs are references, not an integration claim.

## 6 studio HDRI reference candidates, with licenses verified per page

| Candidate | Source / author | License displayed | Decision |
|---|---|---|---|
| Studio Small 01 | https://polyhaven.com/a/studio_small_01 — Greg Zaal | CC0 | Shortlist 1, hard speculars/curtains |
| Studio Small 02 | https://polyhaven.com/a/studio_small_02 — Greg Zaal | CC0 | Shortlist 2, cool key/black backdrop |
| Studio Small 04 | https://polyhaven.com/a/studio_small_04 — Greg Zaal | CC0 | Strong opposing rim, risk exaggerated highlights |
| Studio Small 05 | https://polyhaven.com/a/studio_small_05 — Greg Zaal | CC0 | High contrast, risk too dark on phone |
| Studio Small 06 | https://polyhaven.com/a/studio_small_06 — Greg Zaal | CC0 | Warm/cool mixed light, candidate only |
| Studio Small 07 | https://polyhaven.com/a/studio_small_07 — Greg Zaal | CC0 | Harsh lamp, reject for default |

Two further HDRIs required by the original 8+ candidate target were not independently verified. Marked unfinished, not fabricated.

## 11 relevant texture / model references and procedural alternatives

| Candidate | Page / author when known | Suitability | Decision |
|---|---|---|---|
| Marble 01 | https://polyhaven.com/a/marble_01 — Rob Tuytel | clean manufactured slab | shortlist |
| Marble Tiles | https://polyhaven.com/a/marble_tiles — Charlotte Baglioni | pattern too coarse for maze | reject |
| White Marble | https://polyhaven.com/a/white_marble — Dario Barresi | apparently vault gated at review | unavailable |
| Marble Rock 01 | https://polyhaven.com/a/marble_rock_01 — Amal Kumar | rugged outdoor look | reject |
| Marble Rock 02 | https://polyhaven.com/a/marble_rock_02 — Amal Kumar | too rocky to imply precision | reject |
| Marble Cliff 01 | https://polyhaven.com/a/marble_cliff_01 — Amal Kumar | scale and cracks unsuitable | reject |
| Marble Cliff 02 | https://polyhaven.com/a/marble_cliff_02 — Amal Kumar | visibly worn | reject |
| Marble Cliff 03 | https://polyhaven.com/a/marble_cliff_03 — Amal Kumar | outdoor cliff reference | reject |
| Marble Cliff 04 | https://polyhaven.com/a/marble_cliff_04 — Amal Kumar | outdoor geological noise | reject |
| Marble Cliff 05 | https://polyhaven.com/a/marble_cliff_05 — Amal Kumar | rough outdoor stone | reject |
| Kenney Marble Kit | https://kenney.nl/assets/marble-kit — Kenney | CC0 game kit, 160 assets | not imported; existing 10 levels are handcrafted |

## 12 specifically created material candidates (original in-repository source)

- Obsidian honed slate floor; Obsidian satin mineral wall
- Industrial titanium floor; Industrial brushed warm wall
- **Ivory limestone floor; Ivory ceramic wall — chosen default**
- Frosted alabaster floor; Frost mineral wall
- Ember travertine floor; Ember oxide ceramic wall
- Celestial blue-violet stone floor; Celestial warm-grey wall

Added eight ball candidates through original maps: chrome, glacier, gold, smoked quartz, pearl, copper, neon and nebula. This produces 12 surface + 8 ball = **20 authored material candidates**, not 20 third-party downloadable files. Any requirement for 20 separately vetted internet assets remains deferred.

## Licensing and engine references

- Poly Haven general CC0 rights: https://polyhaven.com/license . Specific asset rights still verified on the relevant candidate page.
- Kenney Marble Kit CC0: https://kenney.nl/assets/marble-kit .
- Filament material & rendering implementation: https://github.com/google/filament and https://google.github.io/filament/main/materials.html .
- Android frame-time measurement guidance: https://developer.android.com/games/optimize/framerate . A frame interval estimate alone is not a GPU FPS measurement.

## Download/technical feasibility

Current editing container cannot resolve external hosts. No asset CDN or Filament cmgen binary fetched. Procedural maps generated locally instead. Future integration requires compatible cmgen/matc, mobile mipmaps, glTF vertex/tangent/collision inspection, and FPS regression tests. Never embed public page thumbnails into this game.
