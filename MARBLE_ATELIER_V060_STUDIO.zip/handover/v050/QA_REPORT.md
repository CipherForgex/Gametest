# V0.5.0 source-only quality assurance — 11 October 2026

## Test environment and scope
- Original source: `MARBLE_ATELIER_V043_BACKUP.zip` found in user's Library and separately materialized. A NEW working copy was edited; V0.4.3 source backup remains untouched.
- Coding host: Linux / OpenJDK 17 (`javac` available). Android SDK, Android Debug Bridge, Gradle and Filament native runtime **not installed**. Attempts to resolve Gradle downloads through the container failed with `curl: (6) Could not resolve host`.
- Mobile device: Samsung Galaxy S25 Ultra **not connected** to this host. No emulator, physical screen capture or measured GPU FPS from this sprint.
- Target file format: native Android Java + Filament/Filamat 1.75.1 + AGP 8.13.2 + Gradle 8.13.

## Headless tests run (actual results)

| Command | Result | Scope |
|---|---|---|
| `python3 tools/check_project.py` | PASS | 10 blueprints, source contracts, startup constructor ordering, normal maps, assets, no internet permission, persistence keys |
| `bash tools/test_physics.sh` | PASS | Compiled `MarblePhysics.java`, `LevelBlueprints.java`, `ControlMath.java` with javac; ten solvable routes and minimum clearances, 35 moving obstacles/10 ramps across suite |
| `bash tools/test_graphics.sh` | PASS | Source/test harness for feature flags and safe fallbacks; not an Android GPU test |
| `python3 tools/test_visual_upgrade.py` | PASS | Source structure and all 40 material image checks; not a native render |
| `python3 tools/test_vnext_contracts.py` | PASS | Overhead source/input flow, independent stage/chassis/cap detailing, texture difference and dimensions |
| YAML parse with PyYAML | PASS | YAML structure checked (parser 1.1 treats `on` as boolean; Actions event key intact) |
| Final ZIP integrity, safe extraction and extracted-project smoke tests | PASS | 102 files at project root; checksum in external text file |
| `gradle :app:assembleDebug` | NOT RUN | Gradle + Android SDK unavailable; external downloads blocked |
| `adb install`, game launch, Filament on-device inspection | NOT RUN | No physical device or Android emulator |
| Profile FPS / GPU stress | NOT RUN | No graphics runtime; previous Choreographer log is NOT GPU benchmark |

Full headless command output: `handover/logs/HEADLESS_QA_2026-10-11.txt`.

## Preserved behavior and evidence
- Source retains exactly 10 manually authored level blueprints with saved `v04_progress` and `v04_best_*` preference keys.
- Original `MarblePhysics` source remains unchanged; running level-completion, collision and moving-door logic is not rewritten.
- Existing sound effects, level select, time records, eight marble customisations, six optional themes and settings controls retained.
- Overhead mode now sends steering to the same fixed-step `physics.step()` path as normal camera angles. Source contract passes, user-device touch behavior remains to be checked.
- Existing Graphics Lab switches remain; AA/depth adjustments are precautionary, NOT a confirmed root-cause repair for user-reported non-Max artifacts.

## Art changes *actually* verified
Static source confirms new stage material independent of floor textures, new decorative chamfered foundation and perimeter/crown detailing, and regenerated image files. See `qa/VNEXT_MATERIAL_STUDIES.png` (a **source texture swatch sheet**, not a screenshot of a running Android game). Their actual 3D perceptual improvement has NOT been verified on the device.

## Outstanding QA gate decisions
- **Android build gate OPEN**: Must run GitHub Actions/Gradle compile, inspect error logs, and fix any version-specific Java API errors before declaring an installable release.
- **Graphics correctness gate OPEN**: Test SAFE/BALANCED/STUDIO/MAX on Samsung S25 Ultra; capture bug and compare matched frames.
- **Maze presentation gate OPEN**: Inspect overhead, edge highlights, tile joins, frame color separation and marble silhouette on handset.
- **Performance gate OPEN**: 60 FPS is a target, not a measurement; test sustained p50/p95/p99 frame times and thermals.
- **User-facing APK unverified**: no APK created in this environment; ZIP is the deliverable.
