# Asset provenance and rights

## Actually shipped

| Asset(s) | Origin | Rights | Integration | Notes |
|---|---|---|---|---|
| 24 `app/src/main/assets/materials/{family}_{floor,wall}_{albedo,normalrough}.png` | Original deterministic material-generator script in `tools/generate_atelier_materials.py` | Original project-generated assets | Bundled, 512×512 each | Six existing families, distinct floor/wall values |
| 16 `app/src/main/assets/materials/balls/{skin}_{albedo,normalrough}.png` | Same original generator | Original project-generated assets | Bundled, 512×512 | Eight existing IDs including dark smoked-quartz default |
| Static Filament meshes and new pedestal / edge bands | Hand-coded source geometry `FilamentBoard.java` | Original | Runtime native geometry | No downloaded mesh pack |
| 3 `app/src/main/assets/sfx/{tap,impact,complete}.wav` | Inherited from V0.4.3, project handover describes original procedural sound | Earlier user-provided source rights statement | Preserved as-is | Not independently regenerated this sprint |
| Launcher `app_icon.png` | Inherited earlier project icon | See `LICENSING_AND_ASSETS.md` | Preserved | Trademark review before public publishing |
| Filament/Filamat 1.75.1 | https://github.com/google/filament | Apache-2.0 | Gradle dependencies, no source redistribution | Existing `APACHE_2_0_LICENSE.txt` and third-party notices retained |

## Researched but NOT shipped
- https://kenney.nl/assets/marble-kit — 160 CC0 track assets; visually less suitable for this handcrafted maze geometry.
- https://polyhaven.com/a/studio_small_01 — CC0 HDRI by Greg Zaal, candidate for IBL after cmgen build validation.
- https://polyhaven.com/a/studio_small_02 — CC0 HDRI by Greg Zaal, alternative black-backdrop soft key.
- https://polyhaven.com/a/studio_small_04 — CC0 HDRI by Greg Zaal, stronger product rim lighting.
- https://polyhaven.com/a/studio_small_05 — CC0 HDRI by Greg Zaal, high contrast.
- https://polyhaven.com/a/studio_small_06 — CC0 HDRI by Greg Zaal, brighter two-colour key.
- https://polyhaven.com/a/studio_small_07 — CC0 HDRI by Greg Zaal, harder high contrast.
- https://polyhaven.com/a/marble_01 — CC0 slab material by Rob Tuytel.
- https://polyhaven.com/a/marble_tiles — CC0 marble tile material by Charlotte Baglioni.
- https://polyhaven.com/a/marble_rock_01 and https://polyhaven.com/a/marble_rock_02 — CC0 rocky materials by Amal Kumar; rejected for clean surfaces.
- https://polyhaven.com/a/white_marble — apparently vault-locked at inspection, not treated as available to download despite page describing CC0.
- https://polyhaven.com/license — publisher-wide licensing statement.

**No third-party model, HDRI or texture was downloaded into this package.** Network file-download access from the source editing environment failed DNS resolution. The research shortlist is not a claim of licensed integration. Audio and pre-existing dependencies are from inherited V0.4.3 and should be independently audited before commercial release.
