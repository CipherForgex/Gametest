# Remaining issues and immediate validation priorities

## P0 — Android build / runtime still unverified
**Next:** use `.github/workflows/build-apk.yml` with the entire VNext source ZIP. Run `Build Marble Atelier V0.5.0 APK` manually via Actions. Do not claim the game installs until Gradle/APK signer pass and a device install succeeds. CI workflow depends on a separately installed Gradle 8.13 and Android SDK 36; source ZIP does not include a native gradlew wrapper JAR.

## P0 — Reported glitches disappear on MAX quality
**Next:** reproduce on S25 Ultra in all four graphics modes with consistent viewpoint. Compare Choreographer diagnostic logs and record rendering effects individually. FXAA/depth were adjusted, but the cause remains unknown. See `QUALITY_PRESET_DIAGNOSTIC.md`.

## P0 — New 3D presentation requires a game screenshot
**Next:** compare V0.4.3 and V0.5.0 at exact camera framing, same level and same zoom. Check from normal/orbit/overhead view that pedestal is genuinely better and theme contrast readable. A 2D texture atlas does not prove a 3D render.

## P1 — More tactile gameplay polish
Retest overhead steering, moving doors, ramp fair paths, timer and pause lifecycle; tune input curves only after real feedback. No new physical features were invented without validating existing ten levels.

## P1 — Filament engine pipeline and asset loading
Current runtime Filamat material generation is retained for safety. Benchmark cold-start hitches. Investigate compatible offline-compiled materials and filtered 1K HDRI with cmgen for physically plausible hero-marble reflections; do not bundle source images without a verified license and tested KTX pipeline.

## P1 — Consistent incremental app updates
GitHub Actions creates a debug APK signed by the workflow runner. An existing install may have a different test signing certificate. Android then refuses in-place upgrade; uninstalling can erase local progress. For regular testing, configure a **stable, securely stored test signing key** via GitHub encrypted secrets before expecting repeated upgrades. Never ship a public debug private key with source.

## P2 — Accessibility and wider handset regression
Test contrast, screen cutouts, alternate aspect ratios, native Back behavior, accessibility services and resource limits on non-S25 devices.

## Delivery warning
This ZIP is a compile candidate, not a 'fixed APK'. V0.4.3 remains the fallback. Do not overwrite the working release until CI and phone checks succeed.
