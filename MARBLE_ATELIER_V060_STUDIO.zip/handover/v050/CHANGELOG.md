# Practical change history

2026-10-11 — recovered V0.4.3 source ZIP and read handover. Established that prior visuals reused theme floor map for broad stage, overhead disabled physics, no workflow or Gradle wrapper was bundled.

2026-10-11 — produced working copy. Rebuilt decorative podium stack, stage separation, per-exposed-cell edge strips, chamfered underside and floor vs wall physical material separation, without changing wall/ball colliders or ten-level definitions.

2026-10-11 — regenerated 24 original board maps + 16 original marble maps at 512×512, created clearly labeled 2D swatch QA image and preserved texture paths/IDs.

2026-10-11 — enabled movement in overhead camera; changed initial theme to ivory and initial ball to smoked quartz for new installs only. Kept older saved preference keys and persisted choices.

2026-10-11 — set consistent FXAA across quality modes and altered camera near/far clipping. Graphical bug cause not yet confirmed.

2026-10-11 — added inset sidewall grooves/top inlays, additional pure-stdlib contracts, GitHub workflow and documented missing native Android runtime. Headless tests passed, final source ZIP integrity checked separately.
