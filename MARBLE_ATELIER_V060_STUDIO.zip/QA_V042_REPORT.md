# Marble Atelier V0.4.2 Graphics Stress Release — QA

## Changes implemented in source
- Gameplay / maze blueprint count unchanged: exactly ten fixed maps, no reintroduction of 100 procedural maps.
- Four runtime graphics profiles: MAXIMUM (fresh-install test default), STUDIO, BALANCED, SAFE.
- Eleven individual feature-isolation switches: SSR, TAA, MSAA, fog, depth of field, vignette, dynamic resolution, shadowing, refraction, SSAO, bloom.
- Advanced Filament physically based surface parameters for clearcoat and anisotropic highlights; emissive goal; baseline shader fallbacks.
- Cinematic lighting rig expanded with warm and cool point lights; retained textured surface roughness/normal maps, shadow-casting directional light, exposure and spherical-harmonic ambient lighting.
- Individual capability logging and approximate frame-delivery stats; share/copy diagnostics and saved previous-session report.
- Recovery to SAFE profile after incomplete graphical boot before enough frames to mark stable.
- Android versionCode 7 / versionName 0.4.2; unchanged package ID and local-records keys.

## Executed local checks
- `python3 tools/check_project.py`: PASS, source / asset integrity / SDK / V0.4.2 contracts / Filament.init order.
- `bash tools/test_physics.sh`: PASS, all ten mazes, spawn, paths, collision/reset, 35 moving gates, 10 ramps, flick and camera math.
- `bash tools/test_graphics.sh`: PASS, GraphicsProbe Java compilation and tests for options not available, per-effect bitmask, recording of skipped frames, profile fallback, source contracts.
- Validated YAML syntax and expected GitHub workflow steps.
- Executed clean ZIP extraction and reran the same tests from the unpacked source.

## Important limitations / release gate
- No Android SDK, Gradle executable, Filament libraries or attached Samsung test device is available locally. There is **no actual Android compilation or app launch result in this QA log**.
- GitHub Action must compile and verify debug APK; a successful compile still does not validate native Filamat shader compilation on device.
- Experimental rendering passes use version-tolerant reflection: absent/rejected APIs are reported as UNAVAILABLE. A request is not proof an effect rendered.
- There is NO HDR prefiltered specular environment cubemap: this iteration improves physical shading but will not reproduce concept-art quality reflections.
- Maximum mode may be slow, artifact, or crash on some drivers; reports are approximate Choreographer frame delivery, not GPU timing. For fatal native crashes capture Android bug report/logcat if possible.
- Current maze walls are still modular tiles rather than the curved, handcrafted geometry referenced earlier. This graphics-only version deliberately avoids changing gameplay geometry.
- No pre-release signature verification for the real APK has been performed in this environment.

## Suggested device checks
1. Confirm launch and main menu after GitHub build. If startup fails, re-launch to test automatic SAFE recovery.
2. Level 1 with MAXIMUM: inspect chrome highlights, surface material, glow and shadows.
3. Level 5: orbit camera and compare shadows/fog; use Graphics Lab individual toggles.
4. Level 10: record frame rate estimate, stutter, graphical artifacts and heat.
5. Flip SSR, DOF, shadows and MSAA individually to isolate problems; share current and previous reports.
6. Confirm stored best times still present when installed over previous debug build using consistent signing key.
