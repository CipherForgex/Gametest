package com.atelier.marble;

/** Accumulated world-space no-slip rotation. No Android dependency; tested on the JVM. */
public final class RollingOrientation {
    private double x,y,z,w=1;
    public void reset(){x=y=z=0;w=1;}
    public void advance(float dx,float dz,float radius){
        double distance=Math.hypot(dx,dz);
        if(distance<1e-9 || radius<=0)return;
        double half=distance/(2*radius), k=Math.sin(half)/distance;
        double ax=dz*k, az=-dx*k, aw=Math.cos(half);
        double nx=aw*x-az*y+ax*w;
        double ny=aw*y+az*x-ax*z;
        double nz=aw*z+ax*y+az*w;
        double nw=aw*w-ax*x-az*z;
        double norm=Math.sqrt(nx*nx+ny*ny+nz*nz+nw*nw);
        x=nx/norm;y=ny/norm;z=nz/norm;w=nw/norm;
    }
    public float[] matrix(){
        return new float[]{(float)(1-2*(y*y+z*z)),(float)(2*(x*y+z*w)),(float)(2*(x*z-y*w)),0,
            (float)(2*(x*y-z*w)),(float)(1-2*(x*x+z*z)),(float)(2*(y*z+x*w)),0,
            (float)(2*(x*z+y*w)),(float)(2*(y*z-x*w)),(float)(1-2*(x*x+y*y)),0,0,0,0,1};
    }
}
