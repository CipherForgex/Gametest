package com.atelier.marble;

/** Camera-relative, length-preserving mapping. Moving the camera never changes maze coordinates. */
public final class ControlMath {
    private ControlMath(){}
    public static float worldX(float screenX,float screenY,float yaw){
        return (float)(screenX*Math.cos(yaw)+screenY*Math.sin(yaw));
    }
    public static float worldZ(float screenX,float screenY,float yaw){
        return (float)(-screenX*Math.sin(yaw)+screenY*Math.cos(yaw));
    }
    public static float wrapAngle(float radians){
        return (float)Math.atan2(Math.sin(radians),Math.cos(radians));
    }
}
