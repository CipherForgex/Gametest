package com.atelier.marble;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Filament mobile visual-stress harness. All experimental effects are feature-gated.
 * Reflection avoids linking a newer View.java API into a released older Filament AAR.
 * An absent / rejected native option is recorded and never misreported as enabled.
 * No accounts, telemetry or internet access. The report remains entirely on device.
 */
public final class GraphicsProbe {
    public static final String[] NAMES={"MAXIMUM / STRESS TEST", "STUDIO / HIGH", "BALANCED", "SAFE"};
    public static final int MAXIMUM=0, STUDIO=1, BALANCED=2, SAFE=3;
    public static final String[] FEATURES={"SCREEN REFLECTIONS","TEMPORAL AA","MULTISAMPLE AA",
        "FOG","DEPTH OF FIELD","VIGNETTE","DYNAMIC RESOLUTION","SHADOWS",
        "SCREEN REFRACTION","AMBIENT OCCLUSION","BLOOM"};
    private int disabledMask=0;
    public int disabledMask(){return disabledMask;}
    public boolean allowed(int i){return (disabledMask&(1<<i))==0;}
    public void setDisabledMask(int mask){disabledMask=mask&((1<<FEATURES.length)-1);}
    private final List<String> events=new ArrayList<>();
    private long frames, skipped; private double fps=60, worstMs=0;
    private int profile=STUDIO;

    public int profile(){return profile;}
    public String label(){return NAMES[profile];}
    public GraphicsProbe(){events.add("Graphics probe ready; no network logging");}
    public void note(String msg){
        if(events.size()>=75)events.remove(0);
        events.add(msg);
    }
    public void frame(float dt,boolean rendered){
        frames++;if(!rendered)skipped++;
        if(dt>0){double instantaneous=Math.min(240,1.0/dt);fps=fps*.94+instantaneous*.06;worstMs=Math.max(worstMs,dt*1000);}
    }
    public String report(){
        StringBuilder sb=new StringBuilder("MARBLE ATELIER • GPU STRESS REPORT\n")
          .append("Profile: ").append(label()).append('\n')
          .append("OS: ").append(System.getProperty("os.version","unknown")).append('\n')
          .append("Frames: ").append(frames).append("  skipped: ").append(skipped)
          .append("\nApprox frame delivery: ").append(String.format(Locale.US,"%.1f",fps))
          .append(" FPS  longest: ").append(String.format(Locale.US,"%.1f",worstMs)).append(" ms\n")
          .append("NOTE: Choreographer interval, not calibrated GPU render timing.\n\n");
        sb.append("EXPERIMENTAL FEATURE SWITCHES:\n");
        for(int i=0;i<FEATURES.length;i++)sb.append("  ").append(allowed(i)?"ALLOWED ":"DISABLED ").append(FEATURES[i]).append('\n');
        for(String e:events)sb.append(e).append('\n');
        return sb.toString();
    }
    private static void field(Object target,String name,Object value) throws Exception {
        Field f=target.getClass().getField(name);
        if(f.getType()==float.class)f.setFloat(target,((Number)value).floatValue());
        else if(f.getType()==int.class)f.setInt(target,((Number)value).intValue());
        else if(f.getType()==boolean.class)f.setBoolean(target,(Boolean)value);
        else f.set(target,value);
    }
    private void options(Object view, String name, String[][] values){
        try{
            Class<?> type=Class.forName("com.google.android.filament.View$"+name);
            Object options=type.getDeclaredConstructor().newInstance();
            for(String[] pair:values){
                String v=pair[1];
                Object val="true".equals(v)?Boolean.TRUE:"false".equals(v)?Boolean.FALSE:
                    (v.contains(".")?Float.parseFloat(v):Integer.parseInt(v));
                try { field(options,pair[0],val); }
                catch(NoSuchFieldException missing){note("OPTION FIELD NOT AVAILABLE "+name+"."+pair[0]);}
            }
            Method setter=view.getClass().getMethod("set"+name,type);
            setter.invoke(view,options);
            note("ON  "+name);
        }catch(Throwable ex){
            Throwable cause=ex.getCause()==null?ex:ex.getCause();
            note("UNAVAILABLE "+name+" — "+cause.getClass().getSimpleName()+": "+cause.getMessage());
        }
    }
    private void booleanSetting(Object view,String method,boolean value){
        try{view.getClass().getMethod(method,boolean.class).invoke(view,value);note((value?"ON  ":"OFF ")+method);}
        catch(Throwable ex){note("UNAVAILABLE "+method+" ("+ex.getClass().getSimpleName()+")");}
    }
    @SuppressWarnings({"rawtypes","unchecked"})
    private void enumSetting(Object view,String method,String... candidates){
        try{
            Class e=Class.forName("com.google.android.filament.View$ShadowType");
            Object value=null;
            for(String candidate:candidates){try{value=Enum.valueOf(e,candidate);break;}catch(IllegalArgumentException ignored){}}
            if(value==null){note("UNAVAILABLE "+method+": enum not in Filament version");return;}
            view.getClass().getMethod(method,e).invoke(view,value);
            note("ON  "+method+"="+value);
        }catch(Throwable ex){note("UNAVAILABLE "+method+" ("+ex.getClass().getSimpleName()+")");}
    }
    public void configure(Object view,int requested){
        profile=Math.max(MAXIMUM,Math.min(SAFE,requested));
        note("--- Requested "+label()+" ---");
        boolean ultra=profile==MAXIMUM;
        boolean high=profile<=STUDIO;
        boolean nonSafe=profile!=SAFE;
        booleanSetting(view,"setShadowingEnabled",nonSafe&&allowed(7));
        booleanSetting(view,"setScreenSpaceRefractionEnabled",ultra&&allowed(8));
        // Higher-end view effects, subject to Filament 1.75.1 API presence and GPU support.
        options(view,"ScreenSpaceReflectionsOptions",new String[][]{
          {"enabled",Boolean.toString(ultra&&allowed(0))}, {"thickness","0.20"},{"bias","0.04"},
          {"maxDistance","14.0"},{"stride","2.0"}});
        options(view,"TemporalAntiAliasingOptions",new String[][]{
          {"enabled",Boolean.toString(high&&allowed(1))}, {"filterWidth","1.0"}});
        options(view,"MultiSampleAntiAliasingOptions",new String[][]{
          {"enabled",Boolean.toString(ultra&&allowed(2))},{"sampleCount","4"}});
        options(view,"FogOptions",new String[][]{
          {"enabled",Boolean.toString(high&&allowed(3))}, {"distance","24.0"},
          {"maximumOpacity","0.35"},{"height","-3.0"},{"heightFalloff","0.2"},
          {"density","0.012"}});
        options(view,"DepthOfFieldOptions",new String[][]{
          {"enabled",Boolean.toString(ultra&&allowed(4))},{"cocScale","0.25"}});
        options(view,"VignetteOptions",new String[][]{
          {"enabled",Boolean.toString(high&&allowed(5))},{"midPoint","0.62"},{"roundness","0.85"},
          {"feather","0.45"}});
        options(view,"DynamicResolutionOptions",new String[][]{
          {"enabled",Boolean.toString(nonSafe&&allowed(6))},{"homogeneousScaling","true"}});
        if(ultra&&allowed(7))enumSetting(view,"setShadowType","VSM","DPCF","PCF");
        if(!high)note("Studio-only cinematic features reduced by selected profile");
    }
}
