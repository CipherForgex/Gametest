package com.atelier.marble;

import android.app.Activity;
import android.opengl.Matrix;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.google.android.filament.Texture;
import com.google.android.filament.TextureSampler;
import com.google.android.filament.android.TextureHelper;
import java.io.IOException;
import java.util.Arrays;
import android.view.Choreographer;
import android.view.Surface;
import android.view.SurfaceView;

import com.google.android.filament.Box;
import com.google.android.filament.Camera;
import com.google.android.filament.Colors;
import com.google.android.filament.Engine;
import com.google.android.filament.EntityManager;
import com.google.android.filament.Filament;
import com.google.android.filament.IndexBuffer;
import com.google.android.filament.IndirectLight;
import com.google.android.filament.LightManager;
import com.google.android.filament.Material;
import com.google.android.filament.MaterialInstance;
import com.google.android.filament.MathUtils;
import com.google.android.filament.RenderableManager;
import com.google.android.filament.Renderer;
import com.google.android.filament.Scene;
import com.google.android.filament.Skybox;
import com.google.android.filament.SwapChain;
import com.google.android.filament.VertexBuffer;
import com.google.android.filament.View;
import com.google.android.filament.Viewport;
import com.google.android.filament.android.DisplayHelper;
import com.google.android.filament.android.FilamentHelper;
import com.google.android.filament.android.UiHelper;
import com.google.android.filament.filamat.MaterialBuilder;
import com.google.android.filament.filamat.MaterialPackage;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * Native Filament PBR preview/game board. All engine operations run on the Activity UI thread.
 * Self-contained: generated geometry, runtime-generated Filamat shaders, no external 3D models.
 */
public final class FilamentBoard implements UiHelper.RendererCallback, Choreographer.FrameCallback {
    private final SurfaceView surface;
    private final UiHelper uiHelper;
    private final DisplayHelper displayHelper;
    private final Engine engine;
    private final Renderer renderer;
    private final Scene scene;
    private final View view;
    private final Camera camera;
    private final Texture studioReflection;
    private final Material material;
    private final Material texturedMaterial;
    private final Activity context;
    private final Texture[][] albedos=new Texture[6][2], details=new Texture[6][2];
    private final Texture[] ballAlbedos=new Texture[8],ballDetails=new Texture[8];
    private final List<Mesh> batchedMeshes=new ArrayList<>();
    // IMPORTANT: TextureSampler creates a native Filament handle. Never construct it in
    // a field initializer: Java executes field initializers BEFORE the constructor body
    // calls Filament.init(), causing UnsatisfiedLinkError: nCreateSampler on Android.
    private final TextureSampler textureSampler;
    private long lastRenderNanos=0;
    private final GraphicsProbe graphicsProbe=new GraphicsProbe();
    public String getGraphicsReport(){return graphicsProbe.report();}
    public String getGraphicsProfileName(){return graphicsProbe.label();}
    public void setGraphicsDisabledMask(int mask){graphicsProbe.setDisabledMask(mask);}
    public int getGraphicsDisabledMask(){return graphicsProbe.disabledMask();}
    public int getGraphicsProfile(){return graphicsProbe.profile();}

    private final IndirectLight ambient;
    private final Skybox skybox;
    private final List<MaterialInstance> materialInstances = new ArrayList<>();
    private final List<Mesh> meshes = new ArrayList<>();
    private final List<Integer> entities = new ArrayList<>();
    private final List<Integer> lights = new ArrayList<>();
    private final Mesh cube, sphere, torus, cylinder;
    // A separate neutral photographic cyclorama. No theme-derived textures: the playing
    // surface needs a distinct value and color temperature for mobile legibility.
    private static final float STUDIO_STAGE_DEPTH = -2.15f;
    private SwapChain swapChain;
    private int ballEntity,ballRingEntity;
    private final List<MovingVisual> movingPieces=new ArrayList<>();
    private static final class MovingVisual {
        final int entity;final MarblePhysics.Obstacle obstacle;final float height,halfX,halfY,halfZ;
        MovingVisual(int e,MarblePhysics.Obstacle o,float h,float hx,float hy,float hz){
            entity=e;obstacle=o;height=h;halfX=hx;halfY=hy;halfZ=hz;
        }
    }
    private int level = 1;
    private int themeIndex=0, ballSkin=0;
    private boolean overview=false,followBall=true;
    private float yaw=0,targetYaw=0,zoom=1.0f,targetZoom=1.0f,overviewBlend=0f,targetOverview=0f;
    private float focusX=0,focusZ=0,panX=0,panZ=0;
    public int getLoadedLevel(){return level;}
    // No fading, visibility assist, or hidden wall entities anywhere in V0.4.
    private MarblePhysics currentLevel;

    private boolean running;
    private boolean disposed;
    private float ballX, ballZ, lastBallX, lastBallZ, sink;
    private final RollingOrientation rolling = new RollingOrientation();

    private static final class Mesh {
        final VertexBuffer vertices;
        final IndexBuffer indices;
        final int indexCount;
        Mesh(VertexBuffer vertices, IndexBuffer indices, int indexCount) {
            this.vertices=vertices; this.indices=indices; this.indexCount=indexCount;
        }
    }

    public FilamentBoard(Activity activity) {
        // Load filament-jni before constructing ANY native-backed Filament objects.
        // This must precede TextureSampler, Engine, Texture.Builder, etc.
        Filament.init();
        textureSampler = new TextureSampler(
            TextureSampler.MinFilter.LINEAR_MIPMAP_LINEAR,
            TextureSampler.MagFilter.LINEAR,
            TextureSampler.WrapMode.REPEAT);
        context=activity;
        surface = new SurfaceView(activity);
        surface.setKeepScreenOn(true);
        displayHelper = new DisplayHelper(activity);
        engine = Engine.create(Engine.Backend.OPENGL);
        renderer = engine.createRenderer();
        scene = engine.createScene();
        view = engine.createView();
        camera = engine.createCamera(EntityManager.get().create());
        view.setScene(scene);
        view.setCamera(camera);
        // Filament built-in free rendering: contact occlusion, antialiasing, and restrained bloom.
        view.setAntiAliasing(View.AntiAliasing.FXAA);
        View.AmbientOcclusionOptions occlusion = new View.AmbientOcclusionOptions();
        occlusion.enabled = true;
        occlusion.radius = .42f;
        occlusion.intensity = 1.20f;
        view.setAmbientOcclusionOptions(occlusion);
        View.BloomOptions bloom = new View.BloomOptions();
        bloom.enabled = true;
        bloom.strength = .09f;
        view.setBloomOptions(bloom);
        // Cinematic effects are independently instrumented and downgrade gracefully.
        // Android settings page can switch between MAX, STUDIO, BALANCED and SAFE.
        graphicsProbe.configure(view, GraphicsProbe.SAFE);
        // A restrained charcoal environment; the stage carries the highlights.
        skybox = new Skybox.Builder().color(0.000012f, 0.000022f, 0.000043f, 1f).build(engine);
        scene.setSkybox(skybox);
        studioReflection=createStudioReflection();
        ambient = new IndirectLight.Builder().reflections(studioReflection).irradiance(1, new float[]{0.46f, 0.53f, 0.64f})
                .intensity(8500f).build(engine);
        scene.setIndirectLight(ambient);
        refreshCamera();
        camera.setExposure(8.0f, 1.0f/80.0f, 100f);
        // Generating a single PBR material on-device avoids a desktop-only matc step.
        MaterialBuilder.init();
        String shader = "void material(inout MaterialInputs material) {\n"
                + "  prepareMaterial(material);\n"
                + "  material.baseColor.rgb = materialParams.baseColor;\n"
                + "  material.metallic = materialParams.metallic;\n"
                + "  material.roughness = materialParams.roughness;\n"
                + "  material.reflectance = 0.65;\n"
                + "  material.clearCoat = materialParams.clearCoat;\n"
                + "  material.clearCoatRoughness = 0.09;\n"
                + "  material.anisotropy = materialParams.anisotropy;\n"
                + "  material.emissive = float4(materialParams.baseColor * materialParams.emissive, 1.0);\n"
                + "}\n";
        MaterialPackage pkg;
        try {
            pkg = new MaterialBuilder()
                .name("AtelierPBR")
                .platform(MaterialBuilder.Platform.MOBILE)
                .targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3, "baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "roughness")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "clearCoat")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "anisotropy")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "emissive")
                .material(shader)
                .build(engine);
        if (!pkg.isValid()) throw new IllegalStateException("Advanced Filamat package invalid");
            graphicsProbe.note("ON  advanced PBR clearcoat, anisotropy and emissive");
        } catch(Throwable err) {
            graphicsProbe.note("FALLBACK advanced PBR: "+err.getClass().getSimpleName());
            String fallback="void material(inout MaterialInputs material) {\n"+
                "  prepareMaterial(material);\n"+
                "  material.baseColor.rgb=materialParams.baseColor;\n"+
                "  material.metallic=materialParams.metallic;\n"+
                "  material.roughness=materialParams.roughness;\n"+
                "}\n";
            pkg=new MaterialBuilder().name("AtelierSafePBR")
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"roughness")
                .material(fallback).build(engine);
            if(!pkg.isValid())throw new IllegalStateException("Safe PBR shader invalid",err);
        }
        ByteBuffer data = pkg.getBuffer();
        material = new Material.Builder().payload(data, data.remaining()).build(engine);
        // Texture-backed material uses original, locally generated albedo and tangent-space
        // normal+roughness maps. Material colour is a neutral multiplier, not a theme swatch.
        String texturedShader="void material(inout MaterialInputs material) {\n"+
            "  float4 texel=texture(materialParams_albedoMap,getUV0());\n"+
            "  float4 detail=texture(materialParams_normalRoughMap,getUV0());\n"+
            // Filament normal maps must be set before prepareMaterial(): tangent frame conversion.
            "  material.normal=normalize(detail.rgb*2.0-1.0);\n"+
            "  prepareMaterial(material);\n"+
            "  material.baseColor.rgb=texel.rgb*materialParams.baseColor;\n"+
            "  material.metallic=materialParams.metallic;\n"+
            "  material.roughness=clamp(materialParams.roughness*(0.6+detail.a*0.9),0.08,1.0);\n"+
            "  material.reflectance=0.6;\n"+
            "  material.clearCoat=materialParams.clearCoat;\n"+
            "  material.clearCoatRoughness=0.10;\n"+
            "  material.anisotropy=materialParams.anisotropy;\n"+
            "}\n";
        MaterialPackage texturedPkg;
        try {
            texturedPkg=new MaterialBuilder()
            .name("AtelierTexturedPBR")
            .platform(MaterialBuilder.Platform.MOBILE)
            .targetApi(MaterialBuilder.TargetApi.OPENGL)
            .shading(MaterialBuilder.Shading.LIT)
            .require(MaterialBuilder.VertexAttribute.UV0)
            .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"baseColor")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"metallic")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"roughness")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"clearCoat")
            .uniformParameter(MaterialBuilder.UniformType.FLOAT,"anisotropy")
            .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"albedoMap")
            .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"normalRoughMap")
            .material(texturedShader).build(engine);
        if(!texturedPkg.isValid()) throw new IllegalStateException("Advanced textured shader invalid");
            graphicsProbe.note("ON  coated anisotropic textured material");
        } catch(Throwable err) {
            graphicsProbe.note("FALLBACK textured PBR: "+err.getClass().getSimpleName());
            String safeTextured="void material(inout MaterialInputs material) {\n"+
                "  float4 t=texture(materialParams_albedoMap,getUV0());\n"+
                "  float4 d=texture(materialParams_normalRoughMap,getUV0());\n"+
                "  material.normal=normalize(d.rgb*2.0-1.0);\n"+
                "  prepareMaterial(material);\n"+
                "  material.baseColor.rgb=t.rgb*materialParams.baseColor;\n"+
                "  material.metallic=materialParams.metallic;\n"+
                "  material.roughness=clamp(materialParams.roughness*(0.6+d.a*0.9),0.08,1.0);\n"+
                "}\n";
            texturedPkg=new MaterialBuilder().name("AtelierSafeTextured")
                .platform(MaterialBuilder.Platform.MOBILE).targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT).require(MaterialBuilder.VertexAttribute.UV0)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3,"baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT,"roughness")
                .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                    MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"albedoMap")
                .samplerParameter(MaterialBuilder.SamplerType.SAMPLER_2D,
                    MaterialBuilder.SamplerFormat.FLOAT,MaterialBuilder.ParameterPrecision.DEFAULT,"normalRoughMap")
                .material(safeTextured).build(engine);
            if(!texturedPkg.isValid())throw new IllegalStateException("Safe textured shader invalid",err);
        }
        ByteBuffer packed=texturedPkg.getBuffer();
        texturedMaterial=new Material.Builder().payload(packed,packed.remaining()).build(engine);
        MaterialBuilder.shutdown();
        cube=makeCube(); sphere=makeSphere(64, 40); torus=makeTorus(48, 12); cylinder=makeCylinder(40);
        createLights();
        setLevel(1);
        uiHelper = new UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK);
        uiHelper.setRenderCallback(this);
        uiHelper.attachTo(surface);
    }

    /** Camera is a pure view change: it never rotates or moves the physics world. */
    public float getYaw(){return yaw;}
    public void rotateCamera(float degrees){
        // Angle is animated in updateCamera, never jumped in the click handler.
        targetYaw+=(float)Math.toRadians(degrees);
    }
    public void changeZoom(float multiplier){
        targetZoom=Math.max(.52f,Math.min(2.60f,targetZoom*multiplier));
    }
    public void toggleOverview(){
        overview=!overview;targetOverview=overview?1f:0f;
    }
    public boolean isOverview(){return overview;}
    public boolean controlsLocked(){return false;} // Camera framing NEVER disables marble input.
    public void resetCamera(){
        overview=false;targetOverview=0;
        targetYaw=0;targetZoom=1f;
        // Smoothly return to the marble instead of snapping.
    }
    public void setFollowBall(boolean on){followBall=on;}
    public void setQuality(boolean high){setGraphicsProfile(high?GraphicsProbe.STUDIO:GraphicsProbe.BALANCED);}
    public void setGraphicsProfile(int profile){
        graphicsProbe.configure(view,profile);
        boolean max=profile==GraphicsProbe.MAXIMUM;
        boolean expensive=profile<=GraphicsProbe.STUDIO;
        View.AmbientOcclusionOptions ao=new View.AmbientOcclusionOptions();
        ao.enabled=profile!=GraphicsProbe.SAFE && graphicsProbe.allowed(9);
        ao.radius=max?0.64f:.42f;
        ao.intensity=max?1.52f:1.20f;
        view.setAmbientOcclusionOptions(ao);
        View.BloomOptions bloom=new View.BloomOptions();
        bloom.enabled=expensive && graphicsProbe.allowed(10);
        bloom.strength=max?.20f:.105f;
        view.setBloomOptions(bloom);
        view.setAntiAliasing(View.AntiAliasing.FXAA); // No geometry correctness differences between presets.
        graphicsProbe.note("ON  SSAO="+ao.enabled+" / bloom="+bloom.enabled+" / FXAA=true for every preset");
    }
    public void setVisibilityAssist(boolean ignored){
        // Legacy API intentionally does nothing: wall visibility is permanent.
    }
    public void applyStyle(int theme,int skin,int requestedLevel){
        int nextTheme=Math.floorMod(theme,VisualStyles.THEMES.length);
        int nextBall=Math.floorMod(skin,VisualStyles.MARBLES.length);
        boolean reload=nextTheme!=themeIndex||nextBall!=ballSkin||currentLevel==null||level!=requestedLevel;
        themeIndex=nextTheme;
        ballSkin=nextBall;
        // Change stage AND appearance atomically, avoiding an intermediate wrong-level
        // render and duplicate GPU texture/mesh allocations during navigation.
        if(reload)setLevel(requestedLevel);
    }
    private void refreshCamera(){
        if(camera==null)return;
        // Overhead is a PLAYABLE camera mode. Camera moves, collision world does not.
        // Distance scales with the actual footprint, not a fixed guess per level.
        double boardSize=currentLevel==null?9.0:Math.max(currentLevel.cols*currentLevel.cellSize,currentLevel.rows*currentLevel.cellSize);
        double distance=(boardSize*.64+6.6 + (boardSize*1.42+8.5)*overviewBlend)*zoom;
        double horizontal=distance*(.69*(1-overviewBlend)+.001*overviewBlend);
        double height=distance*(.96*(1-overviewBlend)+1.0*overviewBlend);
        double tx=focusX*(1-overviewBlend)+panX*overviewBlend;
        double tz=focusZ*(1-overviewBlend)+panZ*overviewBlend;
        camera.lookAt(tx+Math.sin(yaw)*horizontal,height,tz+Math.cos(yaw)*horizontal,
            tx,0,tz,0,1,0);
    }
    private void updateCamera(float dt){
        float a=1f-(float)Math.exp(-8.0f*Math.min(dt,.05f));
        // Angular interpolation uses the shortest wrapped delta for 0/360 transitions.
        float delta=(float)Math.atan2(Math.sin(targetYaw-yaw),Math.cos(targetYaw-yaw));
        yaw+=delta*a;
        zoom+=(targetZoom-zoom)*a;
        overviewBlend+=(targetOverview-overviewBlend)*a;
        if(overviewBlend<.0005f&&targetOverview==0)overviewBlend=0;
        refreshCamera();
    }

    public SurfaceView getSurface() { return surface; }
    public void setRunning(boolean isRunning) {
        if (disposed || running == isRunning) return;
        running = isRunning;
        if(running)lastRenderNanos=0;
        if (running) Choreographer.getInstance().postFrameCallback(this);
        else Choreographer.getInstance().removeFrameCallback(this);
    }
    public void setLevel(int nextLevel) {
        level = nextLevel;
        movingPieces.clear();ballRingEntity=0;
        for (int entity : entities) {
            scene.removeEntity(entity);
            engine.destroyEntity(entity);
            EntityManager.get().destroy(entity);
        }
        entities.clear();
        for(Mesh mesh:batchedMeshes){
            engine.destroyVertexBuffer(mesh.vertices);engine.destroyIndexBuffer(mesh.indices);
        }
        meshes.removeAll(batchedMeshes);batchedMeshes.clear();
        for (MaterialInstance mi : materialInstances) engine.destroyMaterialInstance(mi);
        materialInstances.clear();
        MarblePhysics game = new MarblePhysics(level);currentLevel=game;
        // The outer silhouette is cut from exactly the playable maze cells.
        // No decorative rectangle underneath lets players bypass the true maze.
        int[] colors=VisualStyles.PALETTES[themeIndex];
        // Ceramic/stone top against a carbon-anodised sculptural chassis.
        // The base is deliberately NOT textured like the floor (V0.4.3's main visual issue).
        MaterialInstance podium=paint(0x252D36,.40f,.42f);
        MaterialInstance chassisInset=paint(0x111A23,.62f,.51f);
        MaterialInstance floor=texturedPaint(.08f,.52f,themeIndex,0);
        MaterialInstance brass=paint(colors[4],.80f,.23f);
        MaterialInstance rim=paint(colors[3],.77f,.18f);
        MaterialInstance wall=texturedPaint(.12f,.36f,themeIndex,1);
        MaterialInstance railLine=paint(colors[5],.26f,.31f);
        MaterialInstance goalGlow=paint(colors[6],.21f,.19f);
        tryParam(goalGlow,"emissive",.48f);
        MaterialInstance launch=paint(colors[4],.48f,.30f);
        float c=game.cellSize;
        // A low-contrast studio cyclorama, BELOW the board. It has no collider,
        // cannot change gameplay and masks the empty overexposed background.
        // Made from the same licensed-original PBR maps as the chosen environment.
        MaterialInstance studioBackdrop=paint(0x101B2A,.02f,.94f);
        MaterialInstance podiumEdge=paint(0xAD997A,.68f,.28f);
        MaterialInstance underside=paint(0x080E15,.40f,.47f);
        float span=Math.max(game.cols,game.rows)*c;
        addBox(0,STUDIO_STAGE_DEPTH,0,span*2.15f,.045f,span*2.15f,studioBackdrop);
        // Narrow mechanically stacked pedestal, with a deep dark shadow gap under
        // the irregular maze silhouette. Much smaller than the old exposed slab.
        addShape(cylinder,0,-1.59f,0,span*.18f,.50f,span*.18f,underside);
        addShape(cylinder,0,-1.06f,0,span*.19f,.025f,span*.19f,podiumEdge);
        addShape(cylinder,0,-.86f,0,span*.16f,.17f,span*.16f,podium);
        // Sculptural props remain outside the entire board footprint and below play height.
        MaterialInstance porcelain=paint(0xC9C0AF,.03f,.36f);
        MaterialInstance darkStone=paint(0x293E43,.08f,.62f);
        float side=game.halfWidth+2.0f, rear=-game.halfLength-2.2f;
        addShape(cylinder,-side,-1.72f,rear,1.05f,.38f,1.05f,darkStone);
        addShape(sphere,-side,-.90f,rear,.48f,.48f,.48f,porcelain);
        addShape(torus,side,-1.72f,rear,1.1f,.20f,1.1f,podiumEdge);
        addShape(cylinder,side,-1.96f,rear,.72f,.16f,.72f,porcelain);
        // Long inlaid studio seams provide depth without matching the maze texture.
        List<BoxPart> studioSeams=new ArrayList<>();
        for(int i=-3;i<=3;i++)studioSeams.add(new BoxPart(i*span*.55f,STUDIO_STAGE_DEPTH+.047f,0,.007f,.002f,span*2.1f));
        addBoxBatch(studioSeams,darkStone);
        // Batched static meshes: thousands of tiles become seven draw calls.
        List<BoxPart> base=new ArrayList<>(),floorTiles=new ArrayList<>(),gold=new ArrayList<>(),inlay=new ArrayList<>();
        List<BoxPart> edgeBands=new ArrayList<>(),edgePins=new ArrayList<>();
        List<BoxPart> walls=new ArrayList<>(),caps=new ArrayList<>(),sideGrooves=new ArrayList<>(),capInlays=new ArrayList<>();
        for(int ix=0;ix<game.cols;ix++)for(int iz=0;iz<game.rows;iz++)if(game.isCell(ix,iz)){
            float px=game.centerX(ix),pz=game.centerZ(iz);
            base.add(new BoxPart(px,-.47f,pz,c*.497f,.16f,c*.497f));
            // A three-material chassis profile instead of theme-matching slabs.
            gold.add(new BoxPart(px,-.315f,pz,c*.498f,.016f,c*.498f));
            inlay.add(new BoxPart(px,-.277f,pz,c*.495f,.025f,c*.495f));
            float slope=game.rampDirection(ix,iz)*.095f;
            floorTiles.add(new BoxPart(px,-.151f,pz,c*.498f,.15f,c*.498f,
                (float)-Math.atan(slope)));
            if(slope!=0)addBox(px,-.005f,pz,c*.43f,.008f,.018f,goalGlow);
            // Cut the perimeter ONLY along exposed exterior cell faces. Cosmetic
            // geometry is far below collision Y=0; authored routes are untouched.
            float outside=c*.498f;
            if(!game.isCell(ix-1,iz)){
                edgeBands.add(new BoxPart(px-outside,-.49f,pz,.019f,.065f,c*.475f));
                edgePins.add(new BoxPart(px-outside,-.61f,pz,.029f,.014f,c*.452f));
            }
            if(!game.isCell(ix+1,iz)){
                edgeBands.add(new BoxPart(px+outside,-.49f,pz,.019f,.065f,c*.475f));
                edgePins.add(new BoxPart(px+outside,-.61f,pz,.029f,.014f,c*.452f));
            }
            if(!game.isCell(ix,iz-1)){
                edgeBands.add(new BoxPart(px,-.49f,pz-outside,c*.475f,.065f,.019f));
                edgePins.add(new BoxPart(px,-.61f,pz-outside,c*.452f,.014f,.029f));
            }
            if(!game.isCell(ix,iz+1)){
                edgeBands.add(new BoxPart(px,-.49f,pz+outside,c*.475f,.065f,.019f));
                edgePins.add(new BoxPart(px,-.61f,pz+outside,c*.452f,.014f,.029f));
            }
        }
        for(MarblePhysics.Obstacle o:game.obstacles){
            if(o.moving){
                int block=addBox(o.x,.17f,o.z,o.halfX,.17f,o.halfZ,wall);
                int cap=addBox(o.x,.349f,o.z,o.halfX,.011f,o.halfZ,rim);
                movingPieces.add(new MovingVisual(block,o,.17f,o.halfX,.17f,o.halfZ));
                movingPieces.add(new MovingVisual(cap,o,.349f,o.halfX,.011f,o.halfZ));
            }else{
                walls.add(new BoxPart(o.x,.17f,o.z,o.halfX,.17f,o.halfZ));
                caps.add(new BoxPart(o.x,.349f,o.z,Math.max(.012f,o.halfX-.036f),.006f,Math.max(.012f,o.halfZ-.036f)));
                // Inset fine machinery grooves on both faces of the wall near its base.
                // These remain inside the collision envelope (purely visual recess lines).
                if(o.halfX>o.halfZ){
                    float depth=Math.max(.001f,o.halfZ-.012f);
                    sideGrooves.add(new BoxPart(o.x,.058f,o.z-depth,o.halfX*.94f,.008f,.007f));
                    sideGrooves.add(new BoxPart(o.x,.058f,o.z+depth,o.halfX*.94f,.008f,.007f));
                    capInlays.add(new BoxPart(o.x,.357f,o.z,o.halfX*.88f,.0025f,.007f));
                }else{
                    float depth=Math.max(.001f,o.halfX-.012f);
                    sideGrooves.add(new BoxPart(o.x-depth,.058f,o.z,.007f,.008f,o.halfZ*.94f));
                    sideGrooves.add(new BoxPart(o.x+depth,.058f,o.z,.007f,.008f,o.halfZ*.94f));
                    capInlays.add(new BoxPart(o.x,.357f,o.z,.007f,.0025f,o.halfZ*.88f));
                }
            }
        }
        addChamferedWallBatch(base,podium);
        addBoxBatch(gold,podiumEdge);addBoxBatch(inlay,chassisInset);
        addBoxBatch(edgeBands,chassisInset);addBoxBatch(edgePins,podiumEdge);
        addBoxBatch(floorTiles,floor);addChamferedWallBatch(walls,wall);
        // Twin recessed foot grooves and a narrow crown inlay make walls read as
        // precision-machined components, without moving any physical surface.
        addBoxBatch(sideGrooves,chassisInset);addBoxBatch(caps,rim);
        addBoxBatch(capInlays,podiumEdge);
        addShape(cylinder,game.startX,.006f,game.startZ,.27f,.014f,.27f,launch);
        addShape(torus,game.startX,.017f,game.startZ,.29f,.040f,.29f,goalGlow);
        addShape(cylinder,game.goalX,.018f,game.goalZ,.27f,.012f,.27f,railLine);
        addShape(torus,game.goalX,.031f,game.goalZ,.38f,.044f,.38f,brass);
        addShape(torus,game.goalX,.046f,game.goalZ,.26f,.041f,.26f,goalGlow);
        MaterialInstance ball=texturedBallPaint(ballSkin);
        ballEntity=addShape(sphere,game.x,MarblePhysics.BALL_RADIUS+game.getHeightAt(game.x,game.z),game.z,MarblePhysics.BALL_RADIUS,
            MarblePhysics.BALL_RADIUS,MarblePhysics.BALL_RADIUS,ball);
        if(ballSkin==2||ballSkin==5||ballSkin>=6){
            MaterialInstance trim=paint(ballSkin==6?0x2CF6FF:ballSkin==7?0xF4B8FF:colors[4],.71f,.17f);
            ballRingEntity=addShape(torus,game.x,.17f,game.z,.143f,.143f,.143f,trim);
        }
        ballX=lastBallX=game.x;ballZ=lastBallZ=game.z;
        rolling.reset();sink=0;
        focusX=game.x;focusZ=game.z;panX=0;panZ=0;
        refreshCamera();
        updateMovingWalls(game);
    }

    private static void tryParam(MaterialInstance mi,String name,float value){
        // A fallback shader may not expose an experimental material uniform.
        try{mi.setParameter(name,value);}catch(RuntimeException unavailable){}
    }
    private MaterialInstance paint(int rgb,float metal,float rough){
        return m(((rgb>>16)&255)/255f,((rgb>>8)&255)/255f,(rgb&255)/255f,metal,rough);
    }
    private int addTiltedBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat,float angle){
        int entity=addBox(x,y,z,sx,sy,sz,mat);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.rotateM(matrix,0,angle,1,0,0);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        return entity;
    }

    public void updateMovingWalls(MarblePhysics game){
        if(disposed||game==null)return;
        for(MovingVisual p:movingPieces){
            float[] matrix=identity();
            Matrix.translateM(matrix,0,p.obstacle.atX(game.animationTime),p.height,
                p.obstacle.atZ(game.animationTime));
            Matrix.scaleM(matrix,0,p.halfX,p.halfY,p.halfZ);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(p.entity),matrix);
        }
    }

    private Texture ballTexture(int skin,boolean detail){
        Texture[] store=detail?ballDetails:ballAlbedos;
        if(store[skin]!=null)return store[skin];
        String name="materials/balls/"+VisualStyles.BALL_TEXTURE_KEYS[skin]+
            (detail?"_normalrough.png":"_albedo.png");
        store[skin]=readTexture(name,detail);return store[skin];
    }
    private MaterialInstance texturedBallPaint(int skin){
        MaterialInstance mi=texturedMaterial.createInstance();
        mi.setParameter("baseColor",Colors.RgbType.SRGB,1f,1f,1f);
        mi.setParameter("metallic",VisualStyles.METAL[skin]);
        mi.setParameter("roughness",VisualStyles.ROUGH[skin]);
        tryParam(mi,"clearCoat",skin==0||skin==2||skin==4||skin==7?.95f:.56f);
        tryParam(mi,"anisotropy",skin==0||skin==2||skin==5?.25f:0f);
        mi.setParameter("albedoMap",ballTexture(skin,false),textureSampler);
        mi.setParameter("normalRoughMap",ballTexture(skin,true),textureSampler);
        materialInstances.add(mi);return mi;
    }
    private Texture readTexture(String name,boolean detail){
        try(java.io.InputStream stream=context.getAssets().open(name)){
            BitmapFactory.Options decode=new BitmapFactory.Options();
            // Alpha stores roughness, not opacity. Premultiplication corrupts normals.
            decode.inPremultiplied=false;decode.inScaled=false;
            Bitmap bm=BitmapFactory.decodeStream(stream,null,decode);
            if(bm==null)throw new IllegalStateException("Could not decode "+name);
            Texture result=new Texture.Builder().width(bm.getWidth()).height(bm.getHeight())
                .levels(0xff).sampler(Texture.Sampler.SAMPLER_2D)
                .usage(Texture.Usage.DEFAULT | Texture.Usage.GEN_MIPMAPPABLE)
                .format(detail?Texture.InternalFormat.RGBA8:Texture.InternalFormat.SRGB8_A8)
                .build(engine);
            TextureHelper.setBitmap(engine,result,0,bm);
            result.generateMipmaps(engine);
            return result;
        }catch(IOException ex){throw new IllegalStateException("Missing material asset "+name,ex);}
    }
    private Texture texture(int theme,int kind,boolean detail){
        Texture[][] store=detail?details:albedos;
        if(store[theme][kind]!=null)return store[theme][kind];
        String name=VisualStyles.TEXTURE_KEYS[theme]+"_"+(kind==0?"floor":"wall")+
            (detail?"_normalrough.png":"_albedo.png");
        store[theme][kind]=readTexture("materials/"+name,detail);
        return store[theme][kind];
    }
    private MaterialInstance texturedPaint(float metal,float rough,int theme,int kind){
        MaterialInstance mi=texturedMaterial.createInstance();
        mi.setParameter("baseColor",Colors.RgbType.SRGB,1f,1f,1f);
        mi.setParameter("metallic",metal);
        mi.setParameter("roughness",rough);
        tryParam(mi,"clearCoat",kind==0?.20f:.52f);
        tryParam(mi,"anisotropy",metal>.3f?.35f:0f);
        mi.setParameter("albedoMap",texture(theme,kind,false),textureSampler);
        mi.setParameter("normalRoughMap",texture(theme,kind,true),textureSampler);
        materialInstances.add(mi);
        return mi;
    }
    private static final class BoxPart {
        final float x,y,z,hx,hy,hz,ax;
        BoxPart(float x,float y,float z,float hx,float hy,float hz){this(x,y,z,hx,hy,hz,0);}
        BoxPart(float x,float y,float z,float hx,float hy,float hz,float ax){
            this.x=x;this.y=y;this.z=z;this.hx=hx;this.hy=hy;this.hz=hz;this.ax=ax;
        }
    }
    /** Combine same-material boxes into one vertex/index buffer (low mobile draw-call count). */
    private void addBoxBatch(List<BoxPart> pieces,MaterialInstance mat){
        if(pieces.isEmpty())return;
        if(pieces.size()*24>64000)throw new IllegalStateException("Batch index overflow");
        final float[][] face={
            {-1,-1,1, 1,-1,1, 1,1,1,-1,1,1},
            {1,-1,-1,-1,-1,-1,-1,1,-1,1,1,-1},
            {1,-1,1,1,-1,-1,1,1,-1,1,1,1},
            {-1,-1,-1,-1,-1,1,-1,1,1,-1,1,-1},
            {-1,1,1,1,1,1,1,1,-1,-1,1,-1},
            {-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,1}
        };
        final float[][] normals={{0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}};
        float[] vertices=new float[pieces.size()*72],normal=new float[vertices.length];
        float[] tex=new float[pieces.size()*48];int[] indexes=new int[pieces.size()*36];
        for(int b=0;b<pieces.size();b++){
            BoxPart p=pieces.get(b);float sin=(float)Math.sin(p.ax),cos=(float)Math.cos(p.ax);
            for(int f=0;f<6;f++)for(int v=0;v<4;v++){
                int i=b*24+f*4+v;float lx=face[f][v*3],ly=face[f][v*3+1],lz=face[f][v*3+2];
                float yy=ly*p.hy,zz=lz*p.hz;
                vertices[i*3]=p.x+lx*p.hx;
                vertices[i*3+1]=p.y+cos*yy-sin*zz;
                vertices[i*3+2]=p.z+sin*yy+cos*zz;
                float nx=normals[f][0],ny=normals[f][1],nz=normals[f][2];
                normal[i*3]=nx;normal[i*3+1]=cos*ny-sin*nz;
                normal[i*3+2]=sin*ny+cos*nz;
                float u=(ny!=0?lx:nx!=0?lz:lx)*.5f+.5f;
                float vv=(ny!=0?lz:ly)*.5f+.5f;
                tex[i*2]=u;tex[i*2+1]=vv;
            }
            for(int f=0;f<6;f++){
                int v=b*24+f*4,j=b*36+f*6;
                indexes[j]=v;indexes[j+1]=v+1;indexes[j+2]=v+2;
                indexes[j+3]=v;indexes[j+4]=v+2;indexes[j+5]=v+3;
            }
        }
        Mesh group=upload(vertices,normal,tex,indexes);
        batchedMeshes.add(group);
        addShape(group,0,0,0,1,1,1,mat);
    }
    /**
     * Actual chamfered top edges, not a color-only outline. Colliders stay authoritative
     * and at the exact un-bevelled footprint, so no invisible wall is introduced.
     * Only visual vertices and normals are changed; walls remain permanently visible.
     */
    private void addChamferedWallBatch(List<BoxPart> pieces, MaterialInstance material) {
        final int segments=4, faces=4*(segments+1)+1, max=700;
        for(int start=0;start<pieces.size();start+=max){
            int count=Math.min(max,pieces.size()-start);
            float[] vertex=new float[count*faces*4*3],normals=new float[vertex.length];
            float[] uv=new float[count*faces*4*2];int[] indices=new int[count*faces*6];
            for(int i=0;i<count;i++){
                BoxPart b=pieces.get(start+i);
                float x0=b.x-b.hx,x1=b.x+b.hx,z0=b.z-b.hz,z1=b.z+b.hz;
                float y0=b.y-b.hy,y1=b.y+b.hy;
                float bevel=Math.min(.055f,Math.min(b.hx,b.hz)*.42f);
                float[][] prev={{x0,y0,z0},{x1,y0,z0},{x1,y0,z1},{x0,y0,z1}};
                int face=0;
                for(int ring=0;ring<=segments;ring++){
                    double angle=ring*Math.PI/(2*segments);
                    float inset=bevel*(1-(float)Math.cos(angle));
                    float y=y1-bevel+bevel*(float)Math.sin(angle);
                    float[][] next={{x0+inset,y,z0+inset},{x1-inset,y,z0+inset},
                        {x1-inset,y,z1-inset},{x0+inset,y,z1-inset}};
                    for(int side=0;side<4;side++){
                        int n=(side+1)%4;
                        face=emitFace(i,face,faces,prev[side],prev[n],next[n],next[side],vertex,normals,uv,indices);
                    }
                    prev=next;
                }
                emitFace(i,face,faces,prev[0],prev[1],prev[2],prev[3],vertex,normals,uv,indices);
            }
            Mesh mesh=upload(vertex,normals,uv,indices);
            batchedMeshes.add(mesh);addShape(mesh,0,0,0,1,1,1,material);
        }
    }
    private static int emitFace(int item,int face,int faces,float[] a,float[] b,float[] c,float[] d,
            float[] vertex,float[] normal,float[] uv,int[] indices){
        int vi=(item*faces+face)*4,ii=(item*faces+face)*6;
        float[] e={b[0]-a[0],b[1]-a[1],b[2]-a[2]};
        float[] f={d[0]-a[0],d[1]-a[1],d[2]-a[2]};
        float nx=f[1]*e[2]-f[2]*e[1],ny=f[2]*e[0]-f[0]*e[2],nz=f[0]*e[1]-f[1]*e[0];
        float inv=1f/Math.max(.00001f,(float)Math.sqrt(nx*nx+ny*ny+nz*nz));
        float[][] q={a,b,c,d};
        for(int j=0;j<4;j++){
            int v=vi+j;vertex[v*3]=q[j][0];vertex[v*3+1]=q[j][1];vertex[v*3+2]=q[j][2];
            normal[v*3]=nx*inv;normal[v*3+1]=ny*inv;normal[v*3+2]=nz*inv;
            // World-projected UVs keep texture scales coherent between wall segments.
            uv[v*2]=(Math.abs(ny)>.7f?q[j][0]:Math.abs(nx)>.7f?q[j][2]:q[j][0])*.9f;
            uv[v*2+1]=(Math.abs(ny)>.7f?q[j][2]:q[j][1])*.9f;
        }
        indices[ii]=vi;indices[ii+1]=vi+2;indices[ii+2]=vi+1;
        indices[ii+3]=vi;indices[ii+4]=vi+3;indices[ii+5]=vi+2;
        return face+1;
    }

    public void resetBallPose(float x,float z){lastBallX=x;lastBallZ=z;rolling.reset();sink=0;}

    public void updateBall(float x, float z, boolean scored, float dt) {
        if (disposed || ballEntity == 0) return;
        rolling.advance(x-lastBallX,z-lastBallZ,MarblePhysics.BALL_RADIUS);
        lastBallX=x; lastBallZ=z;
        if (scored) sink = Math.min(1f,sink+dt*1.3f);
        float shrink = 1f - .70f*sink;
        float altitude = MarblePhysics.BALL_RADIUS + (currentLevel==null?0:currentLevel.getHeightAt(x,z)) - sink*.46f;
        float[] matrix = identity();
        Matrix.translateM(matrix,0,x,altitude,z);
        float[] rotation=rolling.matrix();
        float[] rotated=new float[16];
        Matrix.multiplyMM(rotated,0,matrix,0,rotation,0);matrix=rotated;
        Matrix.scaleM(matrix,0,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink);
        int instance=engine.getTransformManager().getInstance(ballEntity);
        engine.getTransformManager().setTransform(instance,matrix);
        if(ballRingEntity!=0){
            float[] ring=identity();Matrix.translateM(ring,0,x,altitude,z);
            float[] oriented=new float[16];Matrix.multiplyMM(oriented,0,ring,0,rotation,0);ring=oriented;
            Matrix.scaleM(ring,0,.143f*shrink,.143f*shrink,.143f*shrink);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(ballRingEntity),ring);
        }
        if(followBall){
            float damping=1f-(float)Math.exp(-4.3f*Math.min(dt,.05f));
            // Gentle look-ahead without jumping at each flick or sudden reset.
            float predictedX=x;
            float predictedZ=z;
            focusX+=(predictedX-focusX)*damping;
            focusZ+=(predictedZ-focusZ)*damping;
        }
        ballX=x;ballZ=z;
    }

    private MaterialInstance m(float r,float g,float b,float metallic,float roughness) {
        MaterialInstance mi=material.createInstance();
        mi.setParameter("baseColor", Colors.RgbType.SRGB,r,g,b);
        mi.setParameter("metallic",metallic);
        mi.setParameter("roughness",roughness);
        tryParam(mi,"clearCoat",roughness<.3f?.86f:.16f);
        tryParam(mi,"anisotropy",metallic>.65f?.30f:0f);
        tryParam(mi,"emissive",0f);
        materialInstances.add(mi);
        return mi;
    }
    private int addBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        return addShape(cube,x,y,z,sx,sy,sz,mat);
    }
    private int addShape(Mesh mesh,float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        int entity=EntityManager.get().create();
        new RenderableManager.Builder(1)
                .boundingBox(new Box(0f,0f,0f,1.25f,1.25f,1.25f))
                .geometry(0,RenderableManager.PrimitiveType.TRIANGLES,mesh.vertices,mesh.indices,0,mesh.indexCount)
                .material(0,mat)
                .castShadows(true)
                .receiveShadows(true)
                .culling(false)
                .build(engine,entity);
        scene.addEntity(entity);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        entities.add(entity);
        return entity;
    }
    private static float[] identity() { float[] m=new float[16]; Matrix.setIdentityM(m,0);return m; }
    /** Six continuous HDR faces, filtered by Filament for roughness-aware reflections. */
    private Texture createStudioReflection(){
        final int size=64;
        ByteBuffer bytes=ByteBuffer.allocateDirect(6*size*size*3*4).order(ByteOrder.nativeOrder());
        FloatBuffer pixels=bytes.asFloatBuffer();int[] offsets=new int[6];
        for(int face=0;face<6;face++){
            offsets[face]=face*size*size*3*4;
            for(int row=0;row<size;row++)for(int col=0;col<size;col++){
                float u=2f*(col+.5f)/size-1,v=2f*(row+.5f)/size-1;
                float x=0,y=0,z=0;
                switch(face){
                    case 0:x=1;y=-v;z=-u;break;case 1:x=-1;y=-v;z=u;break;
                    case 2:x=u;y=1;z=v;break;case 3:x=u;y=-1;z=-v;break;
                    case 4:x=u;y=-v;z=1;break;default:x=-u;y=-v;z=-1;
                }
                float inv=1f/(float)Math.sqrt(x*x+y*y+z*z);x*=inv;y*=inv;z*=inv;
                // Wide softboxes, warm key and cool strip; evaluated in direction space.
                float key=(float)Math.exp(-((x+.48f)*(x+.48f)*18+(y-.72f)*(y-.72f)*35+(z-.48f)*(z-.48f)*8));
                float strip=(float)Math.exp(-((x-.82f)*(x-.82f)*90+(y-.25f)*(y-.25f)*4+(z+.52f)*(z+.52f)*14));
                float ceiling=Math.max(0,y)*.07f;
                pixels.put(.025f+ceiling+key*3.0f+strip*.72f);
                pixels.put(.034f+ceiling+key*2.65f+strip*.93f);
                pixels.put(.045f+ceiling+key*2.15f+strip*1.3f);
            }
        }
        pixels.flip();
        Texture texture=new Texture.Builder().width(size).height(size).levels(0xff)
            .sampler(Texture.Sampler.SAMPLER_CUBEMAP).format(Texture.InternalFormat.R11F_G11F_B10F).build(engine);
        Texture.PrefilterOptions options=new Texture.PrefilterOptions();options.sampleCount=64;options.mirror=false;
        texture.generatePrefilterMipmap(engine,new Texture.PixelBufferDescriptor(pixels,Texture.Format.RGB,Texture.Type.FLOAT),offsets,options);
        return texture;
    }
    private void createLights() {
        directional(-.42f,-1f,-.56f,60000f,1f,.93f,.84f);
        int fill=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(4f,7f,5f)
                .color(.60f,.74f,1f).intensity(16000f).falloff(21f).build(engine,fill);
        scene.addEntity(fill);lights.add(fill);
        int key=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(-9f,9f,-5f)
            .color(.94f,.81f,.62f).intensity(13000f).falloff(26f).build(engine,key);
        scene.addEntity(key);lights.add(key);
        int rimLight=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(0f,5f,-11f)
            .color(.44f,.67f,1f).intensity(9000f).falloff(30f).build(engine,rimLight);
        scene.addEntity(rimLight);lights.add(rimLight);
    }
    private void directional(float x,float y,float z,float lux,float r,float g,float b) {
        int light=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.DIRECTIONAL)
                .direction(x,y,z).color(r,g,b).intensity(lux).castShadows(true).build(engine,light);
        scene.addEntity(light);lights.add(light);
    }

    // Geometry packing: positions + tangent-frame quaternion, matching Filament lit materials.
    private Mesh upload(float[] vertex,float[] normals,int[] indices){
        int n=vertex.length/3;float[] uv=new float[n*2];
        for(int i=0;i<n;i++){
            uv[i*2]=vertex[i*3]*.5f+.5f;
            uv[i*2+1]=vertex[i*3+2]*.5f+.5f;
        }
        return upload(vertex,normals,uv,indices);
    }
    private Mesh upload(float[] vertex,float[] normals,float[] uv,int[] indices){
        int n=vertex.length/3;
        ByteBuffer verts=ByteBuffer.allocateDirect(n*36).order(ByteOrder.nativeOrder());
        for(int i=0;i<n;i++){
            float nx=normals[3*i],ny=normals[3*i+1],nz=normals[3*i+2];
            float tx,ty=0f,tz;
            if(Math.abs(ny)>.92f){
                // Project onto the normal plane: the old constant X tangent was
                // not perpendicular on the upper sphere, distorting highlights.
                tx=1f-nx*nx;ty=-nx*ny;tz=-nx*nz;
                float length=(float)Math.sqrt(tx*tx+ty*ty+tz*tz);
                tx/=length;ty/=length;tz/=length;
            }
            else{float len=(float)Math.hypot(nz,nx);tx=nz/len;tz=-nx/len;}
            float bx=ny*tz-nz*ty,by=nz*tx-nx*tz,bz=nx*ty-ny*tx;
            float[] q=new float[4];MathUtils.packTangentFrame(tx,ty,tz,bx,by,bz,nx,ny,nz,q);
            verts.putFloat(vertex[i*3]).putFloat(vertex[i*3+1]).putFloat(vertex[i*3+2]);
            for(float v:q)verts.putFloat(v);
            verts.putFloat(uv[i*2]).putFloat(uv[i*2+1]);
        }
        verts.flip();
        ByteBuffer faces=ByteBuffer.allocateDirect(indices.length*2).order(ByteOrder.nativeOrder());
        for(int idx:indices){if(idx<0||idx>65535)throw new IllegalStateException("Mesh too large");faces.putShort((short)idx);}
        faces.flip();
        VertexBuffer vb=new VertexBuffer.Builder().bufferCount(1).vertexCount(n)
            .attribute(VertexBuffer.VertexAttribute.POSITION,0,VertexBuffer.AttributeType.FLOAT3,0,36)
            .attribute(VertexBuffer.VertexAttribute.TANGENTS,0,VertexBuffer.AttributeType.FLOAT4,12,36)
            .attribute(VertexBuffer.VertexAttribute.UV0,0,VertexBuffer.AttributeType.FLOAT2,28,36)
            .build(engine);
        vb.setBufferAt(engine,0,verts);
        IndexBuffer ib=new IndexBuffer.Builder().indexCount(indices.length)
            .bufferType(IndexBuffer.Builder.IndexType.USHORT).build(engine);
        ib.setBuffer(engine,faces);
        Mesh mesh=new Mesh(vb,ib,indices.length);meshes.add(mesh);return mesh;
    }
    private Mesh makeCube() {
        float[][] vertices = {
                {-1,-1,1, 1,-1,1, 1,1,1, -1,1,1},
                {1,-1,-1, -1,-1,-1, -1,1,-1, 1,1,-1},
                {1,-1,1, 1,-1,-1, 1,1,-1, 1,1,1},
                {-1,-1,-1, -1,-1,1, -1,1,1, -1,1,-1},
                {-1,1,1, 1,1,1, 1,1,-1, -1,1,-1},
                {-1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,1}
        };
        float[][] normals={{0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}};
        float[] p=new float[72],n=new float[72];int[] idx=new int[36];
        for(int f=0;f<6;f++) {
            for(int j=0;j<4;j++) for(int c=0;c<3;c++) {p[f*12+j*3+c]=vertices[f][j*3+c];n[f*12+j*3+c]=normals[f][c];}
            int t=f*6,v=f*4; idx[t]=v;idx[t+1]=v+1;idx[t+2]=v+2;idx[t+3]=v;idx[t+4]=v+2;idx[t+5]=v+3;
        }
        return upload(p,n,idx);
    }
    private Mesh makeSphere(int slices,int stacks) {
        int count=(slices+1)*(stacks+1);
        float[] p=new float[count*3],n=new float[count*3],uv=new float[count*2];
        int[] indices=new int[slices*stacks*6];
        int t=0;
        for(int j=0;j<=stacks;j++) {
            double a=Math.PI*j/stacks;
            for(int i=0;i<=slices;i++) {
                double b=2*Math.PI*i/slices;
                int o=(j*(slices+1)+i)*3;
                float nx=(float)(Math.sin(a)*Math.cos(b)),ny=(float)Math.cos(a),nz=(float)(Math.sin(a)*Math.sin(b));
                p[o]=n[o]=nx;p[o+1]=n[o+1]=ny;p[o+2]=n[o+2]=nz;
                int vi=j*(slices+1)+i;uv[vi*2]=i/(float)slices;uv[vi*2+1]=j/(float)stacks;
            }
        }
        for(int j=0;j<stacks;j++) for(int i=0;i<slices;i++) {
            int a=j*(slices+1)+i,b=a+slices+1;
            indices[t++]=a;indices[t++]=a+1;indices[t++]=b;
            indices[t++]=a+1;indices[t++]=b+1;indices[t++]=b;
        }
        return upload(p,n,uv,indices);
    }
    private Mesh makeTorus(int slices,int sides) {
        int count=(slices+1)*(sides+1);
        float[] p=new float[count*3],n=new float[count*3];int[] idx=new int[slices*sides*6];int t=0;
        for(int a=0;a<=slices;a++) for(int b=0;b<=sides;b++) {
            double angle=a*Math.PI*2/slices,v=b*Math.PI*2/sides;
            float cs=(float)Math.cos(angle),sn=(float)Math.sin(angle),cv=(float)Math.cos(v),sv=(float)Math.sin(v);
            int o=(a*(sides+1)+b)*3;
            p[o]=(1f+.075f*cv)*cs;p[o+1]=.075f*sv;p[o+2]=(1f+.075f*cv)*sn;
            n[o]=cv*cs;n[o+1]=sv;n[o+2]=cv*sn;
        }
        for(int a=0;a<slices;a++) for(int b=0;b<sides;b++) {
            int v=a*(sides+1)+b,w=v+sides+1;
            idx[t++]=v;idx[t++]=v+1;idx[t++]=w;
            idx[t++]=w;idx[t++]=v+1;idx[t++]=w+1;
        }
        return upload(p,n,idx);
    }
    private Mesh makeCylinder(int segments) {
        float[] p=new float[(segments+1)*2*3],n=new float[p.length];
        int[] idx=new int[segments*6];int t=0;
        for(int j=0;j<2;j++) for(int i=0;i<=segments;i++) {
            int k=(j*(segments+1)+i)*3;double angle=2*Math.PI*i/segments;
            p[k]=(float)Math.cos(angle);p[k+1]=j==0?1:-1;p[k+2]=(float)Math.sin(angle);
            n[k]=0;n[k+1]=j==0?1:-1;n[k+2]=0;
        }
        // A pair of planar discs formed as triangle fans around first rim vertex.
        for(int j=0;j<2;j++) for(int i=1;i<segments-1;i++) {
            int k=j*(segments+1); idx[t++]=k;idx[t++]=j==0?k+i+1:k+i;idx[t++]=j==0?k+i:k+i+1;
        }
        // Allocate a new index array sized for only real triangles.
        int[] used=new int[t];System.arraycopy(idx,0,used,0,t);
        return upload(p,n,used);
    }

    @Override public void onNativeWindowChanged(Surface surface) {
        if (swapChain != null) engine.destroySwapChain(swapChain);
        swapChain=engine.createSwapChain(surface);
        if (this.surface.getDisplay()!=null) displayHelper.attach(renderer,this.surface.getDisplay());
    }
    @Override public void onDetachedFromSurface() {
        displayHelper.detach();
        if(swapChain!=null) {engine.destroySwapChain(swapChain);engine.flushAndWait();swapChain=null;}
    }
    @Override public void onResized(int width,int height) {
        if (height<=0) return;
        double aspect=(double)width/height;
        camera.setProjection(46.0,aspect,0.28,140.0,Camera.Fov.VERTICAL);
        view.setViewport(new Viewport(0,0,width,height));
        FilamentHelper.synchronizePendingFrames(engine);
    }
    @Override public void doFrame(long timeNanos) {
        if(!running||disposed)return;
        float elapsed=lastRenderNanos==0?1f/60f:Math.min(.06f,(timeNanos-lastRenderNanos)*1e-9f);
        lastRenderNanos=timeNanos;
        updateCamera(elapsed);
        boolean rendered=false;
        if (uiHelper.isReadyToRender() && swapChain != null && renderer.beginFrame(swapChain,timeNanos)) {
            renderer.render(view);renderer.endFrame();rendered=true;
        }
        graphicsProbe.frame(elapsed,rendered);
        Choreographer.getInstance().postFrameCallback(this);
    }
    public void dispose() {
        if(disposed)return;
        setRunning(false);
        uiHelper.detach();
        for(int id:entities) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(int id:lights) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(Mesh mesh:meshes) {engine.destroyVertexBuffer(mesh.vertices);engine.destroyIndexBuffer(mesh.indices);}
        for(MaterialInstance mi:materialInstances) engine.destroyMaterialInstance(mi);
        engine.destroyMaterial(material);
        engine.destroyMaterial(texturedMaterial);
        for(int t=0;t<6;t++)for(int k=0;k<2;k++){
            if(albedos[t][k]!=null)engine.destroyTexture(albedos[t][k]);
            if(details[t][k]!=null)engine.destroyTexture(details[t][k]);
        }
        for(int t=0;t<8;t++){
            if(ballAlbedos[t]!=null)engine.destroyTexture(ballAlbedos[t]);
            if(ballDetails[t]!=null)engine.destroyTexture(ballDetails[t]);
        }
        engine.destroyIndirectLight(ambient);
        engine.destroyTexture(studioReflection);
        engine.destroySkybox(skybox);
        engine.destroyRenderer(renderer);
        engine.destroyView(view);
        engine.destroyScene(scene);
        engine.destroyCameraComponent(camera.getEntity());
        EntityManager.get().destroy(camera.getEntity());
        engine.destroy();
        disposed=true;
    }
}
