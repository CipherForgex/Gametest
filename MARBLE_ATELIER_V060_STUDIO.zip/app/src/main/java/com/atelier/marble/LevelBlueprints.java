package com.atelier.marble;

/** Ten fixed, reviewed maze blueprints. No runtime maze generator and no hidden collision walls.
 * Hex cell symbols are NESW passage bits; dot is outside the actual board.
 * Curated as static designs for the ten distinct silhouette families.
 */
public final class LevelBlueprints {
  private LevelBlueprints() {}
  public static final int COUNT = 10;
  public static final class Blueprint {
    public final String name; public final String[] rows; public final int startX,startY,goalX,goalY;
    public final int[][] hazardCells,rampCells;
    Blueprint(String name,String[] rows,int sx,int sy,int gx,int gy,int[][] hazardCells,int[][] rampCells){
      this.name=name;this.rows=rows;startX=sx;startY=sy;goalX=gx;goalY=gy;this.hazardCells=hazardCells;this.rampCells=rampCells;
    }
  }
  public static final Blueprint[] MAPS = {
    // Level 1: CIRCLE, 61 traversable cells, solution requires 10 corridor transitions.
    new Blueprint("CIRCLE",new String[]{"...356...",".3696956.",".a95d54a.","2b55435d6","bc356956a","96a1d56a8",".a95629e.",".943cb5c.","...81c..."},3,8,4,5,new int[][]{},new int[][]{}),
    // Level 2: DIAMOND, 97 traversable cells, solution requires 16 corridor transitions.
    new Blueprint("DIAMOND",new String[]{"...35562...","..3c34ab6..",".3d696aa94.","2a2a3ca9636","a9ea95d69ca","b6a9556a36a","a8a374aaaaa","96a896a9cbc",".9e35cb63c.","..9c368a8..","...1c95c..."},3,10,3,4,new int[][]{},new int[][]{}),
    // Level 3: OCTAGON, 124 traversable cells, solution requires 26 corridor transitions.
    new Blueprint("OCTAGON",new String[]{"...157616...",".3755c96976.",".895562968a.","36356ab695d6","a9c3caaa363c","a17c3c8aaa96","b6a1d63ca96a","aa956a96a29c","8b56a96aa974",".96a95cbc3e.",".1ca355c3c8.","...89555c..."},3,11,4,8,new int[][]{},new int[][]{}),
    // Level 4: HEXAGON, 153 traversable cells, solution requires 39 corridor transitions.
    new Blueprint("HEXAGON",new String[]{"...3556174...",".23e15d69636.","3ea9556a3ea96","aab435caa896a","89c3c36ab63ca","356a2aaa8aa2a","b69c9ca96aaaa","a95563d4aaaaa","a163cb63cabca","96aa3c9c1dc3e","1dea9556363e8",".1ca235cabc8.","...89d55c8..."},3,12,8,6,new int[][]{{4,3}},new int[][]{}),
    // Level 5: SPIRAL, 196 traversable cells, solution requires 54 corridor transitions.
    new Blueprint("SPIRAL",new String[]{"37755435557562","aa8363c235c3ca","a95c9c3ea3695e","963543eaaa9568","2a956aaa9d5496","bc36bca956356a","95ca83c35ca2aa","356a3c2974aa9e","a1c9c3d5c3cb5c","b5555d562a3c34","96355569ea9696","3c9563c1c9695e","9435ca3563c35c","15c15dc1dc1d54"},0,13,12,13,new int[][]{{6,13},{12,5}},new int[][]{}),
    // Level 6: STAR, 126 traversable cells, solution requires 68 corridor transitions.
    new Blueprint("STAR",new String[]{".........36.....","........3e96....","..34...3ca2a....",".3c374.a2abc....",".97c9769caa.....","..835e955ca36...","...9683562aa9562","....b5c3ca9c349e","...3c36a1d63d55c","..2a3ca9569d4...",".3c9c3d6296.....",".9635c.aa3d6....","..9c...9ea3c....","........8ab4....",".........88....."},2,9,9,6,new int[][]{{4,10},{9,4},{11,5}},new int[][]{}),
    // Level 7: INFINITY, 225 traversable cells, solution requires 86 corridor transitions.
    new Blueprint("INFINITY",new String[]{"...236.....156...",".36aa974.3556976.","1ebca296.a3696a96","3c83dd497caa3ca1e","a36b4356a2aa96b6a","bcaa3c1de9c95e8aa","96aa9561c355696aa","3c9c36963c3696aaa","a176a95c96a96a9ca","968a95635c96ab56a","3c3d749c356aa83ca","96a1e357c3caa3c3c","1e968a3c.95c9c2b4",".95c3e94.15763dc.","...1c8.....89c..."},3,14,12,3,new int[][]{{9,12},{12,12},{10,6},{4,8},{7,4}},new int[][]{}),
    // Level 8: GEAR, 159 traversable cells, solution requires 101 corridor transitions.
    new Blueprint("GEAR",new String[]{".................",".....16...36.....",".....3d4.1ea.....","..2..95575ca..2..","..b55555c16955e..","..955635569563c..","...35ca36975ca...",".35e35ca96a35c34.","1e2ab55c3ca961d74",".9ca9563c2a2a35c.","...963c969dcaa...","..35c835e356ab6..","..b556968969dca..","..8..96b56a2..8..",".....3e8.9ea.....",".....88...9c.....","................."},5,15,11,10,new int[][]{{3,9},{7,4},{14,5},{9,11},{8,10},{4,7}},new int[][]{{10,2},{7,12}}),
    // Level 9: CLOVER, 155 traversable cells, solution requires 120 corridor transitions.
    new Blueprint("CLOVER",new String[]{"........356........",".......3d496.......",".......a363e.......","......2aa9c96......","......bc9615c......","......9569636......","..236355c3ea96374..","23dca9562a8a29c9756","aa16b62aa95dc35683e","9d6aa9cab5635c3c3c8","..9c9569c3c961d5c..","......a36962a......","......bc96bca......","......962aa3c......",".......bc9ca.......",".......8357c.......","........81c........"},8,16,2,8,new int[][]{{12,9},{18,7},{11,7},{9,2},{7,4},{7,9},{9,14},{4,7}},new int[][]{{15,7},{10,0},{10,12}}),
    // Level 10: MASTER, 272 traversable cells, solution requires 145 corridor transitions.
    new Blueprint("MASTER",new String[]{".........236.........","........3ea96........","....34.3c8b4b6.36....","...1d63d63c3c95c96...","...37ca29c3c15555e...","...a83c9769555636a...","...95d57c95636aaaa...","..3635683569caaaa96..",".3c9c3c3c2956aaa9696.","2b563c1d6b63c89d69696","9d6a9555ca9c1761e2968",".1e961763c355c96bc3c.","..9496aaa3c1635c83c..","...35ca9ca35c9635e...","...b61d63cb556ab6a...","...aa369c1c36aa8aa...","...8aa97556aabd5e8...","....9c.9629ca8.1c....","........9d43c........",".........15c........."},9,19,12,3,new int[][]{{9,16},{3,13},{3,7},{7,10},{11,9},{6,11},{11,11},{14,15},{19,10},{15,9}},new int[][]{{4,14},{5,9},{9,11},{14,11},{18,9}})
  };
  public static Blueprint at(int level){if(level<1||level>COUNT)throw new IllegalArgumentException("Level "+level);return MAPS[level-1];}
}
