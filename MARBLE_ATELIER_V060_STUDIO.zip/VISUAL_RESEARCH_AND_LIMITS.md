# Marble Atelier V0.4.3 — Rendering research and release limitations

## Confirmed Filament opportunities

- Filament PBR expects calibrated direct + indirect lighting, rather than simply enabling all expensive post-processing switches. Its official explanation: https://google.github.io/filament/Filament.html
- Image-based lighting with mipmapped reflection cubemaps requires image prefiltering. Official tooling: https://google.github.io/filament/dup/cmgen.html
- Filament's Android sample index includes textured material and image-based-lighting examples: https://google.github.io/filament/dup/android_samples.html
- Poly Haven CC0 HDRIs and materials, legally usable commercially without attribution: https://polyhaven.com/license
- ambientCG offers CC0 physically based materials: https://ambientcg.com/

## What is actually included in this source ZIP

- 40 original, procedural PBR maps (6 surface packs x floor/wall x two maps and 8 ball skins x two maps), mostly 512 x 512.
- A dark 3D stage/floor below the actual gameplay, so the view no longer relies solely on the exposed skybox/background.
- Reduced harsh direct-light intensities, a more restrained skybox, less intense indirect illumination.
- Actual chamfered static wall geometry and thinner metallic highlights, instead of square-topped boxes everywhere.
- Closer default follow-camera composition; existing overhead and 90-degree camera controls retained.
- Collision/reset text is transient again (~1 second), not permanently left at bottom of screen.
- Exactly ten existing levels and gameplay physics, unchanged.

## Not included / not yet verified

- No prefiltered HDR IBL/skybox. The sources above are researched candidate sources only; NONE of those third-party files is bundled.
- No claim to film-quality refraction, perfect real-time mirror reflections, or performance figures without a handset render.
- Bevels are cosmetic: unchanged box colliders deliberately remain authoritative. Their top chamfers are inwards and do not create invisible colliders.
- The dark stage is decorative only, 2+ units below the ball and does not change gameplay.
- No Android SDK/Filament binary runtime in this environment. A successful phone build, screen recording and test session are still required.

## Next graphics milestone after real footage

Compare V0.4.3 phone screenshots against V0.4.2. If lighting and bevel changes pass, integrate one independently verified CC0 1K HDRI, prefilter it with Filament cmgen on GitHub or a known host build, package the generated KTX assets, wire the Android IBL loader, then benchmark the actual chrome ball under controlled conditions.
