# Marble Atelier 0.6.0 — Studio

A native Android / Filament marble maze. Ten levels, six board materials, eight marble finishes, offline play, saved progress and records, camera gestures and graphics settings.

## Build on GitHub
Upload `MARBLE_ATELIER_V060_STUDIO.zip` to the repository root. Paste the supplied workflow into `.github/workflows/build-apk.yml`, then run it under Actions. Download the `MARBLE_ATELIER_V060_INSTALL_APK` artifact and extract its APK.

The source is at the ZIP root. Java 17, Gradle 8.13, Android SDK/build tools 36, AGP 8.13.2 and Filament 1.75.1. Standard builds target arm64-v8a for the Samsung S25 Ultra.

## Controls
Drag to roll. Flick to boost. Two fingers pinch to zoom and twist to orbit. The labelled toolbar rotates, zooms, resets and switches to a playable top view. Camera Help pauses the run and explains each control. Restart is separate.

## Install safely beside your current game
The debug / Studio build uses `com.atelier.marble.studio` and appears as **Marble Atelier Studio**. It installs beside the previous game and keeps its own progress. Your original game and saves stay in place. The supplied APK has a development signature; it is for testing, not Play Store distribution. The release application ID remains `com.atelier.marble`.

## Verification
See `handover/QA_REPORT.md` for exactly what passed and what remains unverified. Prior-version reports are in `handover/v050/`. The material generator is `tools/generate_studio_materials.py`; followed by `tools/import_stone_materials.py`; the older generator remains historical and will overwrite the new designs if run.
