#!/usr/bin/env python3
"""Static JVM/JNI startup ordering regression for Android Filament rendering.

Fail if a new native-backed Filament object can be created before Filament.init().
This detects the V0.4 TextureSampler.nCreateSampler UnsatisfiedLinkError source.
It does not replace an actual Android runtime test.
"""
from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
p=root/'app/src/main/java/com/atelier/marble/FilamentBoard.java'
s=p.read_text(encoding='utf-8')
assert re.search(r'private\s+final\s+TextureSampler\s+textureSampler\s*;',s), \
    'TextureSampler must be declared without a field initializer'
assert not re.search(r'TextureSampler\s+textureSampler\s*=\s*new',s), \
    'BUG: native sampler constructed before Filament.init() (field initializer)'
constructor=re.search(r'public\s+FilamentBoard\s*\(\s*Activity\s+activity\s*\)\s*\{',s)
assert constructor, 'FilamentBoard(Activity) constructor not found'
body=s[constructor.end():]
init=re.search(r'\bFilament\s*\.\s*init\s*\(\s*\)\s*;',body)
sampler=re.search(r'\btextureSampler\s*=\s*new\s+TextureSampler\s*\(',body)
engine=re.search(r'\bengine\s*=\s*Engine\.create\s*\(',body)
assert init and sampler and engine, 'Missing Filament init, sampler, or engine setup'
assert init.start()<sampler.start()<engine.start(), \
    'Filament.init() must precede TextureSampler and Engine creation'
# Also reject known engine-native allocations in instance field initializers.
fields=s[:constructor.start()]
for name in ('TextureSampler','Texture','Engine','Renderer','Material','MaterialBuilder','Skybox','IndirectLight'):
    assert not re.search(r'=\s*new\s+'+name+r'\s*\(',fields), \
        f'Native-backed {name} constructed before Filament.init()'
app=(root/'app/build.gradle').read_text()
assert "filament-android:1.75.1" in app and "filamat-android:1.75.1" in app, \
    'Filament JNI and Java bindings must use matching versions'
print('PASS: Filament.init() executes before native TextureSampler/Engine creation')
print('PASS: No native Filament constructors in instance field initializers')
print('PASS: Filament/Filamat dependency versions aligned')
