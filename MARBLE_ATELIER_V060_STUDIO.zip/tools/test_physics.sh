#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/marble-atelier-v04-tests
javac -encoding UTF-8 -d /tmp/marble-atelier-v04-tests \
  app/src/main/java/com/atelier/marble/{ControlMath,LevelBlueprints,MarblePhysics}.java \
  tools/SmokeCheck.java
java -cp /tmp/marble-atelier-v04-tests SmokeCheck
