"""Original analytic PBR assets. Seamless UV boards and spherical 3D stone marbles.
No baked lighting: highlights come from Filament. Deterministic; no external licenses.
"""
from pathlib import Path
import numpy as np
import io
def save_png(image,path):
    buf=io.BytesIO();image.save(buf,format="PNG",optimize=True)
    data=buf.getvalue();path.write_bytes(data)
    assert path.read_bytes()==data, str(path)
from PIL import Image
P=Path(__file__).resolve().parents[1]/'app/src/main/assets/materials'
S=512
v,u=np.mgrid[0:S,0:S].astype(float)/(S-1)
t=2*np.pi
# Periodic warped fields: different manufactured material families, not one noise tint.
warp=np.sin(t*u)*.3+np.cos(t*v)*.18
vein=np.exp(-np.abs(np.sin(t*(u+v)+2*np.sin(t*v)+warp))*27)
cloud=np.sin(t*u+np.cos(t*v))*np.cos(t*v+np.sin(t*u))
grain=np.sin(t*95*v+np.sin(t*u)*2)*.6+np.sin(t*171*v)*.25

def write(key,rgb,h,rough):
    rgb=np.clip(rgb,0,255).astype('uint8');save_png(Image.fromarray(rgb),P/(key+'_albedo.png'))
    dy,dx=np.gradient(h);n=np.stack((-dx*2,-dy*2,np.ones_like(h)),axis=-1);n/=np.linalg.norm(n,axis=-1,keepdims=True)
    a=np.empty((S,S,4),np.uint8);a[:,:,:3]=np.clip((n*.5+.5)*255,0,255);a[:,:,3]=np.clip(rough,35,240)
    save_png(Image.fromarray(a),P/(key+'_normalrough.png'))
colors={'obsidian':([44,57,63],[146,157,154]),'industrial':([75,82,86],[165,171,169]),'ivory':([214,207,190],[243,236,220]),'frost':([103,135,151],[209,224,228]),'ember':([126,76,62],[206,166,131]),'celestial':([72,66,100],[178,170,201])}
for i,(name,(floor,wall)) in enumerate(colors.items()):
 for kind,base in [('floor',floor),('wall',wall)]:
    if name=='industrial':
        h=grain*.08;shade=grain*3+cloud*3;rough=150+grain*15
    elif name=='ember':
        bands=np.sin(t*8*v+cloud*2);pores=np.maximum(0,np.sin(t*67*u)*np.sin(t*53*v)-.91)
        shade=bands*7-pores*110;h=bands*.14-pores*.4;rough=170+bands*10
    elif name=='celestial':
        shade=cloud*14-vein*24;h=cloud*.09;rough=115+vein*25
    else:
        shade=cloud*(10 if kind=='floor' else 5)-vein*(34 if name=='ivory' else 20)
        h=cloud*.1-vein*.03;rough=140+vein*20+cloud*9
    if kind=='wall': shade=shade*.58+grain*.5;h=h*.5;rough=rough-30
    rgb=np.array(base)[None,None,:]+shade[:,:,None]
    write(name+'_'+kind,rgb,h,rough)
# Evaluate veins in 3D on a sphere: U seam and both poles are intrinsically continuous.
x=np.sin(np.pi*v)*np.cos(t*u);y=np.cos(np.pi*v);z=np.sin(np.pi*v)*np.sin(t*u)
f=np.sin(7*x+3*np.sin(4*z))+np.sin(8*y+2*np.sin(5*x))*.55
ribbon=np.exp(-np.abs(np.sin(f*2+z*5))*22)
swirl=(np.sin(f*2+z*5)+1)/2
balls={'chrome':([197,207,213],[42,57,68]),'glacier':([36,118,153],[194,238,230]),'gold':([202,156,67],[108,64,24]),'obsidian':([19,32,43],[165,174,160]),'pearl':([224,214,204],[189,191,211]),'copper':([174,91,55],[64,118,114]),'neon':([20,88,98],[100,222,203]),'nebula':([59,39,95],[198,156,210])}
for name,(a,b) in balls.items():
    metal=name in ('chrome','gold','copper')
    mix=ribbon*.32 if metal else swirl*.45+ribbon*.48
    rgb=np.array(a)[None,None,:]*(1-mix[:,:,None])+np.array(b)[None,None,:]*mix[:,:,None]
    # Small identifiable maker's dot on metal marbles makes no-slip rolling visible.
    if metal:
        dot=np.exp(-((x-.52)**2+(y-.68)**2+(z-.52)**2)*430)
        rgb-=dot[:,:,None]*65
    write('balls/'+name,rgb,f*.008,65+ribbon*20 if metal else 86+ribbon*20)
print('Wrote 40 original seamless PBR maps, 512 × 512')
