package com.atelier.marble;
public final class TestGraphicsProbe {
    public static void main(String[] args) {
        GraphicsProbe p=new GraphicsProbe();
        if(GraphicsProbe.NAMES.length!=4)throw new AssertionError("Expected four tiers");
        p.configure(new Object(),GraphicsProbe.MAXIMUM);
        String first=p.report();
        if(!first.contains("MAXIMUM")||!first.contains("UNAVAILABLE ScreenSpaceReflectionsOptions"))
            throw new AssertionError("Unsupported features not reported");
        for(int i=0;i<100;i++)p.frame(1f/60f,i%20!=0);
        if(!p.report().contains("Frames: 100  skipped: 5"))throw new AssertionError("Frame count");
        p.setDisabledMask(1<<0);
        if(p.allowed(0)||!p.allowed(1))throw new AssertionError("Effect isolation mask");
        p.configure(new Object(),GraphicsProbe.SAFE);
        if(!p.report().contains("SAFE"))throw new AssertionError("Fallback profile");
        System.out.println("PASS: experimental effect failures recorded, frame stats, SAFE fallback");
    }
}
