"""Pack the bundled CC0 Poly Haven source maps for the mobile renderer.
Run after generate_studio_materials.py. Sources and checksums in source_materials/provenance.json.
"""
from pathlib import Path
import numpy as np
from PIL import Image
import io
root=Path(__file__).resolve().parents[1];src=root/'tools/source_materials';out=root/'app/src/main/assets/materials'
def read(asset,role):
 p=next(src.glob(asset+'_'+role+'.*'),None)
 if p is None:return None
 return np.array(Image.open(p).convert('RGB').resize((512,512),Image.Resampling.LANCZOS)).astype(float)
def save(a,p):
 b=io.BytesIO();Image.fromarray(np.clip(a,0,255).astype('uint8')).save(b,format='PNG',optimize=True);p.write_bytes(b.getvalue())
for theme,asset,tint in [('ivory','white_marble',[1,.975,.91]),('frost','white_marble',[.73,.87,.93]),('obsidian','marble_01',[.27,.34,.39]),('ember','marble_01',[.80,.54,.42])]:
 base=read(asset,'albedo');normal=read(asset,'normal');rough=read(asset,'roughness')[:,:,0]
 if normal is None:normal=np.broadcast_to([128.,128.,255.],(512,512,3)).copy()
 for kind in ['floor','wall']:
  # Real stone grain with a quiet, brighter wall finish for route visibility.
  factor=np.array(tint);color=base*factor
  if kind=='wall':color=color*.78+np.array([242,239,229])*.22
  save(color,out/(theme+'_'+kind+'_albedo.png'))
  n=normal/255*2-1;n[:,:,:2]*=.3;n/=np.linalg.norm(n,axis=2,keepdims=True)
  packed=np.empty((512,512,4));packed[:,:,:3]=(n*.5+.5)*255
  packed[:,:,3]=np.clip(rough*.65+(38 if kind=='floor' else 18),50,220)
  save(packed,out/(theme+'_'+kind+'_normalrough.png'))
print('PASS imported four stone families from two verified CC0 source materials')
