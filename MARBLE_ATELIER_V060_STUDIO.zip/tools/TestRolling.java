import com.atelier.marble.RollingOrientation;
public class TestRolling {
 static void near(float a,float b){if(Math.abs(a-b)>.0001)throw new AssertionError(a+" != "+b);}
 static void identity(float[] m){for(int i=0;i<16;i++)near(m[i],i%5==0?1:0);}
 public static void main(String[] args){
  RollingOrientation q=new RollingOrientation();float r=.145f;
  q.advance((float)(2*Math.PI*r),0,r);identity(q.matrix());
  q.reset();q.advance((float)(Math.PI*r/2),0,r);float[] m=q.matrix();near(m[0],0);near(m[1],-1);near(m[4],1);
  q.advance((float)(-Math.PI*r/2),0,r);identity(q.matrix());
  q.reset();q.advance(.1f,.07f,r);q.advance(-.1f,-.07f,r);identity(q.matrix());
  q.reset();for(int i=0;i<100000;i++)q.advance(.003f,.002f*(i%3-1),r);
  m=q.matrix();for(int a=0;a<3;a++)for(int b=0;b<3;b++){float dot=0;for(int j=0;j<3;j++)dot+=m[a*4+j]*m[b*4+j];near(dot,a==b?1:0);}
  q.reset();identity(q.matrix());
  System.out.println("PASS rolling: circumference, quarter turn direction, reverse, diagonal reversal, 100000-step stability, reset");
 }
}
