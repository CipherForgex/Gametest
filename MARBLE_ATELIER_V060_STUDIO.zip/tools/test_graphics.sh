#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -encoding UTF-8 -d "$out" \
  app/src/main/java/com/atelier/marble/GraphicsProbe.java tools/TestGraphicsProbe.java
java -cp "$out" com.atelier.marble.TestGraphicsProbe
python3 - <<'PYCODE'
from pathlib import Path
render=Path('app/src/main/java/com/atelier/marble/FilamentBoard.java').read_text()
activity=Path('app/src/main/java/com/atelier/marble/MainActivity.java').read_text()
probe=Path('app/src/main/java/com/atelier/marble/GraphicsProbe.java').read_text()
checks={
 'PBR clear coat': 'material.clearCoat' in render,
 'PBR anisotropy': 'material.anisotropy' in render,
 'PBR emissive goal': 'material.emissive' in render and 'tryParam(goalGlow,"emissive"' in render,
 'Shader compile fallback': 'FALLBACK advanced PBR' in render and 'FALLBACK textured PBR' in render,
 'Multiple lights': 'int rimLight=' in render and 'int key=' in render,
 'Effect selection UI': 'GRAPHICS LAB' in activity and 'GraphicsProbe.FEATURES' in activity,
 'Crash recovery': 'graphics_boot_pending' in activity and 'GraphicsProbe.SAFE' in activity,
 'In-app offline diagnostic export': 'previousGraphicsReport()' in activity and 'ACTION_SEND' in activity,
 '11 individual feature switches': probe.count('"BLOOM"')==1 and '"SCREEN REFLECTIONS"' in probe,
 'No wall hiding': 'walls.remove(' not in render and 'entities.remove(' not in render,
 'Ten-level limit': 'LEVEL_COUNT = 100' not in Path('app/src/main/java/com/atelier/marble/MarblePhysics.java').read_text()
}
for name,ok in checks.items():
 assert ok,name
 print('PASS graphics-contract:',name)
PYCODE
