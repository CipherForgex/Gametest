"""Deterministic ORIGINAL phone-resolution materials, not externally downloaded imagery.
Diffuse sRGB and linear tangent-space (OpenGL +Y) normal / roughness alpha packing.
"""
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter, ImageDraw, ImageFont
from scipy.ndimage import gaussian_filter
root=Path(__file__).resolve().parents[1]
out=root/'app/src/main/assets/materials'
S=512
Y,X=np.mgrid[0:S,0:S].astype(np.float32)

def fields(seed):
    rng=np.random.default_rng(seed)
    a=gaussian_filter(rng.standard_normal((S,S)),46,mode='wrap')*72
    b=gaussian_filter(rng.standard_normal((S,S)),12,mode='wrap')*21
    c=gaussian_filter(rng.standard_normal((S,S)),3,mode='wrap')*5
    f=gaussian_filter(rng.standard_normal((S,S)),1.0,mode='wrap')*1.4
    return rng,a,b,c,f

def save_pair(name,base,shade,height,rough=140):
    base=np.asarray(base,dtype=float)
    rgb=np.clip(base[None,None,:] + shade[:,:,None],0,255).astype('uint8')
    Image.fromarray(rgb,'RGB').save(out/(name+'_albedo.png'),optimize=True)
    dy,dx=np.gradient(height)
    strength=4.0
    vec=np.stack((-dx*strength,-dy*strength,np.ones_like(dx)),axis=-1)
    vec/=np.linalg.norm(vec,axis=2,keepdims=True)
    rgba=np.empty((S,S,4),dtype=np.uint8)
    rgba[:,:,:3]=np.clip((vec*.5+.5)*255,0,255).astype('uint8')
    rgba[:,:,3]=np.clip(rough+shade*.29,40,235).astype('uint8')
    Image.fromarray(rgba,'RGBA').save(out/(name+'_normalrough.png'),optimize=True)

# Crisp but quiet; no graphic texture should compete with navigation.
materials={
  'obsidian':((63,77,90),(115,127,136),'honed slate'),
  'industrial':((135,139,135),(183,177,168),'industrial titanium'),
  'ivory':((225,220,208),(181,176,161),'warm honed ivory'),
  'frost':((196,210,218),(144,162,174),'alabaster'),
  'ember':((136,116,111),(174,143,125),'red travertine'),
  'celestial':((147,145,172),(184,178,194),'silver-violet ceramic'),
}
for index,(name,(floor,wall,_)) in enumerate(materials.items()):
    for j,(kind,color) in enumerate((('floor',floor),('wall',wall))):
        rng,a,b,c,f=fields(2101+index*13+j)
        # Geological veins are wavering hairlines rather than repeated zebra stripes.
        warpx=X + 35*np.sin(Y/97+a*.18)+b*.35
        warpy=Y + 24*np.cos(X/122+b*.25)
        edge=np.cos(warpx*.042+warpy*.015)
        veins=np.clip((np.abs(edge)-.963)/.037,0,1)
        # A faint cross-grain on vertical walls, softly tonal.
        grain=np.sin((X*.25+Y*.019)+a*.015)*(.7 if kind=='floor' else 1.05)
        cloud=(a*.19+b*.43+c*.65+f*.68)-veins*(8 if name in ('ivory','frost') else 5)+grain
        bump=(a*.025+b*.07+c*.17+f*.15)-veins*.39
        save_pair(name+'_'+kind,color,cloud,bump,rough=135 if kind=='floor' else 125)

balls={
'chrome':((188,200,208),.65,'satin liquid titanium'),
'glacier':((149,201,215),.72,'frost opal'),
'gold':((205,169,91),.65,'champagne alloy'),
'obsidian':((63,80,93),1.0,'midnight volcanic glass'),
'pearl':((226,217,207),1.0,'milk opal pearl'),
'copper':((180,115,83),.76,'aged polished copper'),
'neon':((85,193,197),.70,'aqua enamel'),
'nebula':((135,135,179),.82,'amethyst agate')}
for index,(name,(base,ampl,desc)) in enumerate(balls.items()):
    rng,a,b,c,f=fields(540+index*37)
    curl=np.sin(X*.020+Y*.012+a*.36+b*.15+np.sin(Y*.035+a*.20)*2.5)
    swirls=np.sin(X*.009-Y*.024+c*.35+curl*2.1)
    fine=np.cos(X*.045+Y*.035+b*.2)
    ribbon=np.clip((np.abs(swirls)-.94)/.06,0,1)
    cloudy=a*.45+b*.65+c*.46+f*.63
    if name=='pearl':
        # Nacre tonal variation, luminous ivory vs pale steel/rose veins, not a mirror ball.
        tint=np.stack((cloudy+fine*1.5-ribbon*9,cloudy+fine*.8-ribbon*10,cloudy+swirls*3.1-ribbon*8),axis=2)
    elif name in ('chrome','gold','copper'):
        tint=np.stack((cloudy+swirls*4,cloudy+fine*2,cloudy+curl*3),axis=2)
    else:
        tint=np.stack((cloudy+swirls*4-ribbon*5,cloudy+curl*5-ribbon*8,cloudy+fine*5-ribbon*3),axis=2)
    rgb=np.clip(np.array(base)[None,None,:]+tint*ampl,0,255).astype('uint8')
    Image.fromarray(rgb,'RGB').save(out/'balls'/(name+'_albedo.png'),optimize=True)
    height=(a*.025+b*.06+c*.14+f*.11+curl*.18+ribbon*.30)*ampl
    dy,dx=np.gradient(height)
    normal=np.stack((-dx*3.,-dy*3.,np.ones_like(dx)),axis=-1)
    normal/=np.linalg.norm(normal,axis=2,keepdims=True)
    rgba=np.empty((S,S,4),np.uint8)
    rgba[:,:,:3]=np.clip((normal*.5+.5)*255,0,255).astype('uint8')
    rgba[:,:,3]=np.clip(75+cloudy*.2+ribbon*17,15,255).astype('uint8')
    Image.fromarray(rgba,'RGBA').save(out/'balls'/(name+'_normalrough.png'),optimize=True)

# Clear, expressly labeled 2D SWATCH SHEET for QA; not a screenshot of the game.
canvas=Image.new('RGB',(1100,1440),(18,27,38))
d=ImageDraw.Draw(canvas)
d.text((35,28),'MARBLE ATELIER — ORIGINAL MATERIAL STUDIES',fill=(242,235,217))
d.text((35,56),'2D source swatches — NOT an Android gameplay screenshot',fill=(160,172,182))
for i,(name,(flo,wall,_)) in enumerate(materials.items()):
    row=i//3;col=i%3;x=35+col*350;y=108+row*325
    im=Image.open(out/(name+'_floor_albedo.png')).resize((318,198),Image.Resampling.LANCZOS)
    canvas.paste(im,(x,y));im=Image.open(out/(name+'_wall_albedo.png')).resize((318,60))
    canvas.paste(im,(x,y+200))
    d.text((x,y+265),name.upper()+'  /  FLOOR + WALL',fill=(231,223,208))
for i,name in enumerate(balls):
    row=i//4;col=i%4;x=42+col*270;y=780+row*270
    im=Image.open(out/'balls'/(name+'_albedo.png')).resize((225,225))
    mask=Image.new('L',(225,225),0);ImageDraw.Draw(mask).ellipse((8,8,217,217),fill=255)
    canvas.paste(im,(x,y),mask)
    d.text((x,y+233),name.upper(),fill=(233,223,207))
canvas.save(root/'qa/VNEXT_MATERIAL_STUDIES.png',optimize=True)
print('Generated',6*2*2+8*2,'deterministic original PBR maps, 512x512; swatch sheet')
