# V0.4.3 visual quality report

Release type: native Android / Filament 1.75.1 focused rendering and small UX fix.

### Delivered source changes
- Dark charcoal stage below the maze and much darker skybox input to address exposed white background.
- Reduced direct highlights, softened key/fill/rim point lights, tuned overall ambient.
- True chamfered wall meshes batched within safe index limits; wall collisions unchanged.
- Revised following camera distance and vertical FOV.
- Transient wall-reset message, rather than an indefinite reset label.
- Original 512px physical material albedo and tangent normal+roughness maps in six distinct environments; differentiated marble skins.
- Ten level files, best time storage, controls, overhead lockout, wall visibility and moving hazards retained.

### Test scope
Headless pure Java tests + source/PNG/ZIP integrity + visual contract checks. Passing headless tests do NOT prove real-time render correctness.

### Outstanding
- Actual GitHub APK compilation and Samsung launch.
- Theme-by-theme real-device screen recording and sustained frame/GPU measurements.
- Prefiltered HDR IBL for convincing chrome/glass reflections.
- Non-tile curved walls remain future level-system work; this pass intentionally does NOT change layouts.
