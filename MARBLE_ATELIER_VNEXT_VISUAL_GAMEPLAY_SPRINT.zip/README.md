# Marble Atelier V0.5.0 — Luxury Product Studio source

Native Java + Google Filament/Filamat Android maze game. Exactly TEN authored levels. Offline, no account or network permission. Retains existing saves, records, controls and eight marble finishes / six themes.

## New visual / input pass

- More pronounced actual maze presentation: separate fine-grain ceramic floor/wall materials, inset wall crown, recessed foot-line detailing and greater luminance/material separation.
- Manufactured stepped chassis cut to authored cell silhouette, with exposed edge trims, smaller inset supporting stem, neutral dark product-studio background.
- New original 512x512 diffuse and normal/roughness maps for all existing material paths and marble variants, high-contrast smoked-quartz default on ivory for new installs.
- Overhead camera is now PLAYABLE, with normal drag/flick steering; 10 authored mazes, wall physics and stored progress retained.
- Four profiles keep core geometry/material invariants; lightweight FXAA consistent in all tiers. Quality glitch root cause not yet reproduced.

## Android build from a phone

This ZIP itself contains full native Java source, **not an APK**. A ready-to-paste workflow is separately supplied as `MARBLE_ATELIER_VNEXT_GITHUB_BUILD.yml`; also present in `.github/workflows/build-apk.yml` in this ZIP. Paste the YAML into GitHub repository's real workflow file; upload **`MARBLE_ATELIER_VNEXT_VISUAL_GAMEPLAY_SPRINT.zip`** to repo root. See `handover/GITHUB_BUILD.md` for step-by-step instructions.

The downloaded source does not contain Gradle wrapper JAR or a verified compiled APK. GitHub setup-gradle action installs Gradle and Android SDK at build time. Linux current runner lacked both tools and no connected S25 Ultra was available. **Compilation and visual look on a real Android screen are not yet verified**.

## Quality commands (headless only)

```
python3 tools/check_project.py
bash tools/test_physics.sh
bash tools/test_graphics.sh
python3 tools/test_visual_upgrade.py
python3 tools/test_vnext_contracts.py
```

No external art packs are bundled. All new material maps are original generated assets. `tools/generate_atelier_materials.py` is an optional developer-side reproducibility tool requiring numpy, scipy and Pillow; **the APK build does not run it**.

See `handover/` for complete research, 110-item worklist, QA evidence, preset-glitch hypotheses and licensing inventory. Prior V0.4.3 QA reports remain in the ZIP for audit context.
