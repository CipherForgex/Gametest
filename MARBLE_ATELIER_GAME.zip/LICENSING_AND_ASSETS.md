# MARBLE ATELIER V0.4 — Third-party licensing and assets

## Engine dependencies

Google Filament 1.75.1 and Filamat 1.75.1 are released under the Apache License 2.0.
They are usable without royalties or a paid engine licence, including commercially,
subject to the Apache licence and applicable notice/redistribution conditions.
Source: https://github.com/google/filament

A copy of the Apache 2.0 licence and a dependency notice are bundled into
`app/src/main/assets/` for future packaged distributions. Review the final dependency
list and notices before commercial distribution.

## Art and audio

- 24 original board textures: six environment families with floor and wall albedo,
  and matching normal+roughness maps.
- 16 original marble textures: eight finishes, each with albedo and normal+roughness.
- Three procedurally generated short effects (tap, impact, completion).
- Procedural 3D meshes and custom UI graphics, no asset-store models or stock images.
- The icon is derived from the earlier Marble Atelier project; inspect trademark
  suitability before wider release.

The source package does NOT include or claim redistribution rights for concept
art previously generated in the chat. Texture and audio assets were locally
generated for this prototype rather than downloaded from external stock sites.

## Practical restriction

'Free to use commercially' does not mean 'no licences exist'. Android/Gradle
and bundled dependency rights also apply. This is not a legal clearance opinion.
Before public Play Store publication: audit final embedded notices, release signing,
Google Play policies, store content, privacy disclosures and asset provenance.
