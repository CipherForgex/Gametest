# Redistributable assets and licensing — Marble Atelier 0.2

The source code, maze layouts, generated 3D meshes, colours, lighting setup and UI design
in this archive were authored for this prototype. The icon image comes from the prior
prototype's original project package. No paid textures, third-party models, fonts,
audio packs or external asset-store content have been added in this update.

## Third-party dependencies

- Google Filament and Filamat Android 1.75.1: Apache License 2.0.
  https://github.com/google/filament/blob/main/LICENSE
  These libraries are royalty-free and permit commercial distribution, **but they do
  have an open-source license**: retain required notices and provide a copy of the
  applicable Apache 2.0 license and any distributed NOTICE materials, as applicable.
- Android Gradle Plugin, Gradle, Android platform/runtime: their respective licenses
  apply to tools or bundled components. Review Play Store policy and Android dependency
  licence notices before a commercial release.

Nothing is represented as public domain merely because it can be downloaded for free.
There is no licence purchase or engine royalties required from Filament. This is **not**
a legal review or publication clearance. Verify all bundled third-party notices in
`gradle dependencies` for the final release build.

## Visual implementation

All new effects use procedural Filament geometry, PBR materials, native ambient occlusion,
anti-aliasing, bloom and Filament's directional/point lighting. These are graphics features
of the dependency above, **not downloaded assets**. They can run fully offline.

Concept art previously generated in chat is NOT bundled in this application and is NOT
an accurate screenshot of this code. Benchmark the real APK on a phone first.

Copies of the Apache 2.0 licence and a Filament notice are also embedded in
`app/src/main/assets/` so they remain included in the Android app package.
