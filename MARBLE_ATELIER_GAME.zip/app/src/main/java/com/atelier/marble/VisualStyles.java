package com.atelier.marble;

/** All visual palettes are original, defined in source, require no downloaded models or textures. */
public final class VisualStyles {
    public static final String[] THEMES={"OBSIDIAN","INDUSTRIAL","IVORY & GOLD","FROST","EMBER","CELESTIAL"};
    public static final String[] TEXTURE_KEYS={"obsidian","industrial","ivory","frost","ember","celestial"};
    public static final String[] MARBLES={"CHROME","GLACIER","GOLD","OBSIDIAN","PEARL","COPPER","NEON CORE","NEBULA"};
    // floor, podium, wall, wall cap, accent, surround, goal
    public static final int[][] PALETTES={
        {0x1E2935,0x111923,0x435360,0xAFC0C6,0xD8AE72,0x080F19,0x75D6DA},
        {0x11152E,0x080B1D,0x1E3D55,0x44D6E2,0xEF4AAE,0x08051D,0x42DFF6},
        {0xC9C3B4,0x5E514A,0xE5DCD0,0xB89A5C,0xE7B65F,0x1B171B,0xDAB46F},
        {0x6691AE,0x19394F,0x9CCCDD,0xE8F7FF,0x7ADBFF,0x0A263A,0xD7F8FF},
        {0x382C31,0x1B1418,0x60413F,0x9D6F59,0xFF884F,0x140A10,0xFFCC87},
        {0x21213C,0x0F0F26,0x36335C,0x9F92E2,0x91C8FF,0x070715,0xD9B8F8}
    };
    public static final String[] BALL_TEXTURE_KEYS={"chrome","glacier","gold","obsidian","pearl","copper","neon","nebula"};
    public static final int[] BALL_COLORS={0xDBEAF2,0x87D7F7,0xE6B451,0x161B27,0xF5EDE0,0xA75C3D,0x39D8E8,0x9376DE};
    public static final float[] METAL={.92f,.50f,.82f,.63f,.16f,.80f,.47f,.56f};
    public static final float[] ROUGH={.12f,.13f,.16f,.14f,.20f,.25f,.15f,.20f};
    private VisualStyles(){}
    public static int accent(int theme){return 0xff000000|PALETTES[Math.floorMod(theme,THEMES.length)][4];}
}
