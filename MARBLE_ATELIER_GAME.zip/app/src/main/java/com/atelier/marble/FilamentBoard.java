package com.atelier.marble;

import android.app.Activity;
import android.opengl.Matrix;
import android.view.Choreographer;
import android.view.Surface;
import android.view.SurfaceView;

import com.google.android.filament.Box;
import com.google.android.filament.Camera;
import com.google.android.filament.Colors;
import com.google.android.filament.Engine;
import com.google.android.filament.EntityManager;
import com.google.android.filament.Filament;
import com.google.android.filament.IndexBuffer;
import com.google.android.filament.IndirectLight;
import com.google.android.filament.LightManager;
import com.google.android.filament.Material;
import com.google.android.filament.MaterialInstance;
import com.google.android.filament.MathUtils;
import com.google.android.filament.RenderableManager;
import com.google.android.filament.Renderer;
import com.google.android.filament.Scene;
import com.google.android.filament.Skybox;
import com.google.android.filament.SwapChain;
import com.google.android.filament.VertexBuffer;
import com.google.android.filament.View;
import com.google.android.filament.Viewport;
import com.google.android.filament.android.DisplayHelper;
import com.google.android.filament.android.FilamentHelper;
import com.google.android.filament.android.UiHelper;
import com.google.android.filament.filamat.MaterialBuilder;
import com.google.android.filament.filamat.MaterialPackage;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Native Filament PBR preview/game board. All engine operations run on the Activity UI thread.
 * Self-contained: generated geometry, runtime-generated Filamat shaders, no external 3D models.
 */
public final class FilamentBoard implements UiHelper.RendererCallback, Choreographer.FrameCallback {
    private final SurfaceView surface;
    private final UiHelper uiHelper;
    private final DisplayHelper displayHelper;
    private final Engine engine;
    private final Renderer renderer;
    private final Scene scene;
    private final View view;
    private final Camera camera;
    private final Material material;
    private final IndirectLight ambient;
    private final Skybox skybox;
    private final List<MaterialInstance> materialInstances = new ArrayList<>();
    private final List<Mesh> meshes = new ArrayList<>();
    private final List<Integer> entities = new ArrayList<>();
    private final List<Integer> lights = new ArrayList<>();
    private final Mesh cube, sphere, torus, cylinder;
    private SwapChain swapChain;
    private int ballEntity,ballRingEntity;
    private final List<Integer> movingPieces = new ArrayList<>();
    private final List<float[]> movingPiecesTransforms = new ArrayList<>();
    private int level = 1;
    private int themeIndex=0, ballSkin=0;
    private boolean useOcclusion=true,overview=false,followBall=true;
    private float yaw=0,zoom=1.0f,focusX=0,focusZ=0;
    private final List<WallVisual> visibleWalls = new ArrayList<>();
    private static final class WallVisual {
        final int entity; final float x,z,halfX,halfZ;
        boolean shown=true;
        WallVisual(int entity,MarblePhysics.Obstacle o){
            this.entity=entity;x=o.x;z=o.z;halfX=o.halfX;halfZ=o.halfZ;
        }
    }
    private MarblePhysics currentLevel;

    private boolean running;
    private boolean disposed;
    private float ballX, ballZ, rollX, rollZ, lastBallX, lastBallZ, sink;

    private static final class Mesh {
        final VertexBuffer vertices;
        final IndexBuffer indices;
        final int indexCount;
        Mesh(VertexBuffer vertices, IndexBuffer indices, int indexCount) {
            this.vertices=vertices; this.indices=indices; this.indexCount=indexCount;
        }
    }

    public FilamentBoard(Activity activity) {
        Filament.init();
        surface = new SurfaceView(activity);
        surface.setKeepScreenOn(true);
        displayHelper = new DisplayHelper(activity);
        engine = Engine.create(Engine.Backend.OPENGL);
        renderer = engine.createRenderer();
        scene = engine.createScene();
        view = engine.createView();
        camera = engine.createCamera(EntityManager.get().create());
        view.setScene(scene);
        view.setCamera(camera);
        // Filament built-in free rendering: contact occlusion, antialiasing, and restrained bloom.
        view.setAntiAliasing(View.AntiAliasing.FXAA);
        View.AmbientOcclusionOptions occlusion = new View.AmbientOcclusionOptions();
        occlusion.enabled = true;
        occlusion.radius = .42f;
        occlusion.intensity = 1.20f;
        view.setAmbientOcclusionOptions(occlusion);
        View.BloomOptions bloom = new View.BloomOptions();
        bloom.enabled = true;
        bloom.strength = .09f;
        view.setBloomOptions(bloom);
        // A restrained charcoal environment; the stage carries the highlights.
        skybox = new Skybox.Builder().color(0.012f, 0.018f, 0.033f, 1f).build(engine);
        scene.setSkybox(skybox);
        ambient = new IndirectLight.Builder().irradiance(1, new float[]{0.46f, 0.53f, 0.64f})
                .intensity(18000f).build(engine);
        scene.setIndirectLight(ambient);
        refreshCamera();
        camera.setExposure(8.0f, 1.0f/60.0f, 100f);
        // Generating a single PBR material on-device avoids a desktop-only matc step.
        MaterialBuilder.init();
        String shader = "void material(inout MaterialInputs material) {\n"
                + "  prepareMaterial(material);\n"
                + "  material.baseColor.rgb = materialParams.baseColor;\n"
                + "  material.metallic = materialParams.metallic;\n"
                + "  material.roughness = materialParams.roughness;\n"
                + "  material.reflectance = 0.65;\n"
                + "}\n";
        MaterialPackage pkg = new MaterialBuilder()
                .name("AtelierPBR")
                .platform(MaterialBuilder.Platform.MOBILE)
                .targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3, "baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "roughness")
                .material(shader)
                .build(engine);
        if (!pkg.isValid()) throw new IllegalStateException("Filamat shader compilation failed");
        ByteBuffer data = pkg.getBuffer();
        material = new Material.Builder().payload(data, data.remaining()).build(engine);
        MaterialBuilder.shutdown();
        cube=makeCube(); sphere=makeSphere(30, 20); torus=makeTorus(48, 12); cylinder=makeCylinder(40);
        createLights();
        setLevel(1);
        uiHelper = new UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK);
        uiHelper.setRenderCallback(this);
        uiHelper.attachTo(surface);
    }

    /** Camera is a pure view change: it never rotates or moves the physics world. */
    public float getYaw(){return yaw;}
    public void rotateCamera(float degrees){
        yaw+=(float)Math.toRadians(degrees);
        if(yaw>Math.PI*2 || yaw< -Math.PI*2) yaw=(float)Math.IEEEremainder(yaw,Math.PI*2);
        refreshCamera();
    }
    public void changeZoom(float multiplier){
        zoom=Math.max(.64f,Math.min(2.0f,zoom*multiplier));refreshCamera();
    }
    public void toggleOverview(){overview=!overview;refreshCamera();}
    public boolean isOverview(){return overview;}
    public void setFollowBall(boolean on){followBall=on;refreshCamera();}
    public void setVisibilityAssist(boolean on){useOcclusion=on;updateOcclusion();}
    public void applyStyle(int theme,int skin){
        themeIndex=Math.floorMod(theme,VisualStyles.THEMES.length);
        ballSkin=Math.floorMod(skin,VisualStyles.MARBLES.length);
        setLevel(level);
    }
    private void refreshCamera(){
        if(camera==null)return;
        double distance=(overview?25.0:11.7)*zoom;
        double height=(overview?distance:distance*.85);
        double horizontal=overview?distance*.25:distance*.83;
        double targetX=overview?0:focusX,targetZ=overview?0:focusZ;
        camera.lookAt(targetX+Math.sin(yaw)*horizontal,height,targetZ+Math.cos(yaw)*horizontal,
            targetX,0,targetZ,0,1,0);
    }
    private void updateOcclusion(){
        // Occluding nearby walls become invisible, never non-collidable.
        // Geometry hides only when the player's view ray intersects a nearby wall.
        if(currentLevel==null)return;
        double px=ballX,pz=ballZ,fromX=px+Math.sin(yaw)*4.5,fromZ=pz+Math.cos(yaw)*4.5;
        for(WallVisual w:visibleWalls){
            float dx=(float)(fromX-px),dz=(float)(fromZ-pz);
            float denom=dx*dx+dz*dz;
            float t=denom==0?0:Math.max(0,Math.min(1,(float)(((w.x-px)*dx+(w.z-pz)*dz)/denom)));
            float projectionX=(float)(px+dx*t),projectionZ=(float)(pz+dz*t);
            boolean obstructing=t>.01f&&t<.36f&&
                Math.abs(projectionX-w.x)<w.halfX+.23f&&Math.abs(projectionZ-w.z)<w.halfZ+.23f;
            boolean show=!useOcclusion||overview||!obstructing;
            if(show!=w.shown){if(show)scene.addEntity(w.entity);else scene.removeEntity(w.entity);w.shown=show;}
        }
    }
    public SurfaceView getSurface() { return surface; }
    public void setRunning(boolean isRunning) {
        if (disposed || running == isRunning) return;
        running = isRunning;
        if (running) Choreographer.getInstance().postFrameCallback(this);
        else Choreographer.getInstance().removeFrameCallback(this);
    }
    public void setLevel(int nextLevel) {
        level = nextLevel;
        movingPieces.clear(); movingPiecesTransforms.clear();visibleWalls.clear();ballRingEntity=0;
        for (int entity : entities) {
            scene.removeEntity(entity);
            engine.destroyEntity(entity);
            EntityManager.get().destroy(entity);
        }
        entities.clear();
        for (MaterialInstance mi : materialInstances) engine.destroyMaterialInstance(mi);
        materialInstances.clear();
        MarblePhysics game = new MarblePhysics(level);currentLevel=game;
        // The outer silhouette is cut from exactly the playable maze cells.
        // No decorative rectangle underneath lets players bypass the true maze.
        int[] colors=VisualStyles.PALETTES[themeIndex];
        MaterialInstance podium=paint(colors[1],.48f,.33f);
        MaterialInstance floor=paint(colors[0],.33f,.37f);
        MaterialInstance brass=paint(colors[4],.80f,.23f);
        MaterialInstance rim=paint(colors[3],.77f,.18f);
        MaterialInstance wall=paint(colors[2],.58f,.27f);
        MaterialInstance railLine=paint(colors[5],.26f,.31f);
        MaterialInstance goalGlow=paint(colors[6],.21f,.19f);
        MaterialInstance launch=paint(colors[4],.48f,.30f);
        float c=game.cellSize;
        for(int x=0;x<game.cols;x++)for(int z=0;z<game.rows;z++)if(game.isCell(x,z)){
            float px=game.centerX(x),pz=game.centerZ(z);
            addBox(px,-.64f,pz,c*.496f,.22f,c*.496f,podium);
            addBox(px,-.425f,pz,c*.495f,.015f,c*.495f,brass);
            addBox(px,-.385f,pz,c*.495f,.038f,c*.495f,railLine);
            float slope=game.rampDirection(x,z)*.115f;
            if(slope!=0) {
                addTiltedBox(px,-.181f,pz,c*.495f,.18f,c*.495f,floor,
                    (float)-Math.toDegrees(Math.atan(slope)));
                addBox(px,-.005f,pz,c*.43f,.008f,.018f,goalGlow);
            } else {
                addBox(px,-.181f,pz,c*.495f,.18f,c*.495f,floor);
            }
        }
        // Physical rails are generated from the *same list* as fatal collision shapes.
        for(MarblePhysics.Obstacle o:game.obstacles){
            int block=addBox(o.x,.17f,o.z,o.halfX,.17f,o.halfZ,wall);
            int cap=addBox(o.x,.349f,o.z,o.halfX,.011f,o.halfZ,rim);
            if(!o.moving){visibleWalls.add(new WallVisual(block,o));visibleWalls.add(new WallVisual(cap,o));}
            else {
                trackMoving(block,.17f,o.halfX,.17f,o.halfZ);
                trackMoving(cap,.349f,o.halfX,.011f,o.halfZ);
            }
        }
        addShape(cylinder,game.startX,.006f,game.startZ,.27f,.014f,.27f,launch);
        addShape(torus,game.startX,.017f,game.startZ,.29f,.040f,.29f,goalGlow);
        addShape(cylinder,game.goalX,.018f,game.goalZ,.27f,.012f,.27f,railLine);
        addShape(torus,game.goalX,.031f,game.goalZ,.38f,.044f,.38f,brass);
        addShape(torus,game.goalX,.046f,game.goalZ,.26f,.041f,.26f,goalGlow);
        MaterialInstance ball=paint(VisualStyles.BALL_COLORS[ballSkin],
            VisualStyles.METAL[ballSkin],VisualStyles.ROUGH[ballSkin]);
        ballEntity=addShape(sphere,game.x,.17f,game.z,MarblePhysics.BALL_RADIUS,
            MarblePhysics.BALL_RADIUS,MarblePhysics.BALL_RADIUS,ball);
        if(ballSkin==2||ballSkin==5||ballSkin>=6){
            MaterialInstance trim=paint(ballSkin==6?0x2CF6FF:ballSkin==7?0xF4B8FF:colors[4],.71f,.17f);
            ballRingEntity=addShape(torus,game.x,.17f,game.z,.16f,.16f,.16f,trim);
        }
        ballX=lastBallX=game.x;ballZ=lastBallZ=game.z;
        rollX=rollZ=sink=0;
        focusX=game.x;focusZ=game.z;
        refreshCamera();
        updateMovingWalls(game);
        updateOcclusion();
    }

    private MaterialInstance paint(int rgb,float metal,float rough){
        return m(((rgb>>16)&255)/255f,((rgb>>8)&255)/255f,(rgb&255)/255f,metal,rough);
    }
    private int addTiltedBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat,float angle){
        int entity=addBox(x,y,z,sx,sy,sz,mat);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.rotateM(matrix,0,angle,1,0,0);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        return entity;
    }

    private void trackMoving(int entity, float y,float halfX,float halfY,float halfZ){
        movingPieces.add(entity);
        movingPiecesTransforms.add(new float[]{y,halfX,halfY,halfZ});
    }
    public void updateMovingWalls(MarblePhysics game){
        if(disposed || game==null)return;
        MarblePhysics.Obstacle moving=null;
        for(MarblePhysics.Obstacle o:game.obstacles)if(o.moving){moving=o;break;}
        if(moving==null)return;
        float x=moving.atX(game.animationTime);
        for(int i=0;i<movingPieces.size();i++){
            float[] dim=movingPiecesTransforms.get(i);
            float[] matrix=identity();
            Matrix.translateM(matrix,0,x,dim[0],moving.z);
            Matrix.scaleM(matrix,0,dim[1],dim[2],dim[3]);
            int inst=engine.getTransformManager().getInstance(movingPieces.get(i));
            engine.getTransformManager().setTransform(inst,matrix);
        }
    }

    public void updateBall(float x, float z, boolean scored, float dt) {
        if (disposed || ballEntity == 0) return;
        rollX += (z-lastBallZ)*115f;
        rollZ -= (x-lastBallX)*115f;
        lastBallX=x; lastBallZ=z;
        if (scored) sink = Math.min(1f,sink+dt*1.3f);
        float shrink = 1f - .70f*sink;
        float altitude = MarblePhysics.BALL_RADIUS + (currentLevel==null?0:currentLevel.getHeightAt(x,z)) - sink*.46f;
        float[] matrix = identity();
        Matrix.translateM(matrix,0,x,altitude,z);
        Matrix.rotateM(matrix,0,rollZ,0,0,1);
        Matrix.rotateM(matrix,0,rollX,1,0,0);
        Matrix.scaleM(matrix,0,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink);
        int instance=engine.getTransformManager().getInstance(ballEntity);
        engine.getTransformManager().setTransform(instance,matrix);
        if(ballRingEntity!=0){
            float[] ring=identity();Matrix.translateM(ring,0,x,altitude,z);
            Matrix.rotateM(ring,0,rollX*.6f,1,0,0);
            Matrix.rotateM(ring,0,rollZ*.6f,0,0,1);
            Matrix.scaleM(ring,0,.16f*shrink,.16f*shrink,.16f*shrink);
            engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(ballRingEntity),ring);
        }
        if(followBall && !overview){
            float damping=Math.min(1f,dt*5.0f);
            focusX+=(x-focusX)*damping;
            focusZ+=(z-focusZ)*damping;
            refreshCamera();
        }
        ballX=x;ballZ=z;
        updateOcclusion();
    }

    private MaterialInstance m(float r,float g,float b,float metallic,float roughness) {
        MaterialInstance mi=material.createInstance();
        mi.setParameter("baseColor", Colors.RgbType.SRGB,r,g,b);
        mi.setParameter("metallic",metallic);
        mi.setParameter("roughness",roughness);
        materialInstances.add(mi);
        return mi;
    }
    private int addBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        return addShape(cube,x,y,z,sx,sy,sz,mat);
    }
    private int addShape(Mesh mesh,float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        int entity=EntityManager.get().create();
        new RenderableManager.Builder(1)
                .boundingBox(new Box(0f,0f,0f,1.25f,1.25f,1.25f))
                .geometry(0,RenderableManager.PrimitiveType.TRIANGLES,mesh.vertices,mesh.indices,0,mesh.indexCount)
                .material(0,mat)
                .castShadows(true)
                .receiveShadows(true)
                .culling(false)
                .build(engine,entity);
        scene.addEntity(entity);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        entities.add(entity);
        return entity;
    }
    private static float[] identity() { float[] m=new float[16]; Matrix.setIdentityM(m,0);return m; }
    private void createLights() {
        directional(-.42f,-1f,-.56f,85000f,1f,.94f,.83f);
        int fill=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(4f,7f,5f)
                .color(.60f,.74f,1f).intensity(40000f).falloff(21f).build(engine,fill);
        scene.addEntity(fill);lights.add(fill);
    }
    private void directional(float x,float y,float z,float lux,float r,float g,float b) {
        int light=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.DIRECTIONAL)
                .direction(x,y,z).color(r,g,b).intensity(lux).castShadows(true).build(engine,light);
        scene.addEntity(light);lights.add(light);
    }

    // Geometry packing: positions + tangent-frame quaternion, matching Filament lit materials.
    private Mesh upload(float[] vertex,float[] normals,int[] indices) {
        int n=vertex.length/3;
        ByteBuffer verts=ByteBuffer.allocateDirect(n*28).order(ByteOrder.nativeOrder());
        for (int i=0;i<n;i++) {
            float nx=normals[3*i],ny=normals[3*i+1],nz=normals[3*i+2];
            float tx,tz,ty;
            if (Math.abs(ny) > .92f) { tx=1f;ty=0f;tz=0f; }
            else { float len=(float)Math.hypot(nz,nx);tx=nz/len;ty=0f;tz=-nx/len; }
            float bx=ny*tz-nz*ty, by=nz*tx-nx*tz, bz=nx*ty-ny*tx;
            float[] q=new float[4];
            MathUtils.packTangentFrame(tx,ty,tz,bx,by,bz,nx,ny,nz,q);
            verts.putFloat(vertex[i*3]).putFloat(vertex[i*3+1]).putFloat(vertex[i*3+2]);
            for (float v:q) verts.putFloat(v);
        }
        verts.flip();
        ByteBuffer faces=ByteBuffer.allocateDirect(indices.length*2).order(ByteOrder.nativeOrder());
        for (int idx:indices) faces.putShort((short)idx);
        faces.flip();
        VertexBuffer vb=new VertexBuffer.Builder().bufferCount(1).vertexCount(n)
                .attribute(VertexBuffer.VertexAttribute.POSITION,0,VertexBuffer.AttributeType.FLOAT3,0,28)
                .attribute(VertexBuffer.VertexAttribute.TANGENTS,0,VertexBuffer.AttributeType.FLOAT4,12,28)
                .build(engine);
        vb.setBufferAt(engine,0,verts);
        IndexBuffer ib=new IndexBuffer.Builder().indexCount(indices.length)
                .bufferType(IndexBuffer.Builder.IndexType.USHORT).build(engine);
        ib.setBuffer(engine,faces);
        Mesh mesh=new Mesh(vb,ib,indices.length);meshes.add(mesh);return mesh;
    }
    private Mesh makeCube() {
        float[][] vertices = {
                {-1,-1,1, 1,-1,1, 1,1,1, -1,1,1},
                {1,-1,-1, -1,-1,-1, -1,1,-1, 1,1,-1},
                {1,-1,1, 1,-1,-1, 1,1,-1, 1,1,1},
                {-1,-1,-1, -1,-1,1, -1,1,1, -1,1,-1},
                {-1,1,1, 1,1,1, 1,1,-1, -1,1,-1},
                {-1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,1}
        };
        float[][] normals={{0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}};
        float[] p=new float[72],n=new float[72];int[] idx=new int[36];
        for(int f=0;f<6;f++) {
            for(int j=0;j<4;j++) for(int c=0;c<3;c++) {p[f*12+j*3+c]=vertices[f][j*3+c];n[f*12+j*3+c]=normals[f][c];}
            int t=f*6,v=f*4; idx[t]=v;idx[t+1]=v+1;idx[t+2]=v+2;idx[t+3]=v;idx[t+4]=v+2;idx[t+5]=v+3;
        }
        return upload(p,n,idx);
    }
    private Mesh makeSphere(int slices,int stacks) {
        int count=(slices+1)*(stacks+1);
        float[] p=new float[count*3],n=new float[count*3];
        int[] indices=new int[slices*stacks*6];
        int t=0;
        for(int j=0;j<=stacks;j++) {
            double a=Math.PI*j/stacks;
            for(int i=0;i<=slices;i++) {
                double b=2*Math.PI*i/slices;
                int o=(j*(slices+1)+i)*3;
                float nx=(float)(Math.sin(a)*Math.cos(b)),ny=(float)Math.cos(a),nz=(float)(Math.sin(a)*Math.sin(b));
                p[o]=n[o]=nx;p[o+1]=n[o+1]=ny;p[o+2]=n[o+2]=nz;
            }
        }
        for(int j=0;j<stacks;j++) for(int i=0;i<slices;i++) {
            int a=j*(slices+1)+i,b=a+slices+1;
            indices[t++]=a;indices[t++]=a+1;indices[t++]=b;
            indices[t++]=a+1;indices[t++]=b+1;indices[t++]=b;
        }
        return upload(p,n,indices);
    }
    private Mesh makeTorus(int slices,int sides) {
        int count=(slices+1)*(sides+1);
        float[] p=new float[count*3],n=new float[count*3];int[] idx=new int[slices*sides*6];int t=0;
        for(int a=0;a<=slices;a++) for(int b=0;b<=sides;b++) {
            double angle=a*Math.PI*2/slices,v=b*Math.PI*2/sides;
            float cs=(float)Math.cos(angle),sn=(float)Math.sin(angle),cv=(float)Math.cos(v),sv=(float)Math.sin(v);
            int o=(a*(sides+1)+b)*3;
            p[o]=(1f+.075f*cv)*cs;p[o+1]=.075f*sv;p[o+2]=(1f+.075f*cv)*sn;
            n[o]=cv*cs;n[o+1]=sv;n[o+2]=cv*sn;
        }
        for(int a=0;a<slices;a++) for(int b=0;b<sides;b++) {
            int v=a*(sides+1)+b,w=v+sides+1;
            idx[t++]=v;idx[t++]=v+1;idx[t++]=w;
            idx[t++]=w;idx[t++]=v+1;idx[t++]=w+1;
        }
        return upload(p,n,idx);
    }
    private Mesh makeCylinder(int segments) {
        float[] p=new float[(segments+1)*2*3],n=new float[p.length];
        int[] idx=new int[segments*6];int t=0;
        for(int j=0;j<2;j++) for(int i=0;i<=segments;i++) {
            int k=(j*(segments+1)+i)*3;double angle=2*Math.PI*i/segments;
            p[k]=(float)Math.cos(angle);p[k+1]=j==0?1:-1;p[k+2]=(float)Math.sin(angle);
            n[k]=0;n[k+1]=j==0?1:-1;n[k+2]=0;
        }
        // A pair of planar discs formed as triangle fans around first rim vertex.
        for(int j=0;j<2;j++) for(int i=1;i<segments-1;i++) {
            int k=j*(segments+1); idx[t++]=k;idx[t++]=j==0?k+i+1:k+i;idx[t++]=j==0?k+i:k+i+1;
        }
        // Allocate a new index array sized for only real triangles.
        int[] used=new int[t];System.arraycopy(idx,0,used,0,t);
        return upload(p,n,used);
    }

    @Override public void onNativeWindowChanged(Surface surface) {
        if (swapChain != null) engine.destroySwapChain(swapChain);
        swapChain=engine.createSwapChain(surface);
        if (this.surface.getDisplay()!=null) displayHelper.attach(renderer,this.surface.getDisplay());
    }
    @Override public void onDetachedFromSurface() {
        displayHelper.detach();
        if(swapChain!=null) {engine.destroySwapChain(swapChain);engine.flushAndWait();swapChain=null;}
    }
    @Override public void onResized(int width,int height) {
        if (height<=0) return;
        double aspect=(double)width/height;
        camera.setProjection(49.0,aspect,0.1,50.0,Camera.Fov.VERTICAL);
        view.setViewport(new Viewport(0,0,width,height));
        FilamentHelper.synchronizePendingFrames(engine);
    }
    @Override public void doFrame(long timeNanos) {
        if (!running || disposed) return;
        if (uiHelper.isReadyToRender() && swapChain != null && renderer.beginFrame(swapChain,timeNanos)) {
            renderer.render(view);renderer.endFrame();
        }
        Choreographer.getInstance().postFrameCallback(this);
    }
    public void dispose() {
        if(disposed)return;
        setRunning(false);
        uiHelper.detach();
        for(int id:entities) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(int id:lights) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(Mesh mesh:meshes) {engine.destroyVertexBuffer(mesh.vertices);engine.destroyIndexBuffer(mesh.indices);}
        for(MaterialInstance mi:materialInstances) engine.destroyMaterialInstance(mi);
        engine.destroyMaterial(material);
        engine.destroyIndirectLight(ambient);
        engine.destroySkybox(skybox);
        engine.destroyRenderer(renderer);
        engine.destroyView(view);
        engine.destroyScene(scene);
        engine.destroyCameraComponent(camera.getEntity());
        EntityManager.get().destroy(camera.getEntity());
        engine.destroy();
        disposed=true;
    }
}
