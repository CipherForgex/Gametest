package com.atelier.marble;

import android.app.Activity;
import android.opengl.Matrix;
import android.view.Choreographer;
import android.view.Surface;
import android.view.SurfaceView;

import com.google.android.filament.Box;
import com.google.android.filament.Camera;
import com.google.android.filament.Colors;
import com.google.android.filament.Engine;
import com.google.android.filament.EntityManager;
import com.google.android.filament.Filament;
import com.google.android.filament.IndexBuffer;
import com.google.android.filament.IndirectLight;
import com.google.android.filament.LightManager;
import com.google.android.filament.Material;
import com.google.android.filament.MaterialInstance;
import com.google.android.filament.MathUtils;
import com.google.android.filament.RenderableManager;
import com.google.android.filament.Renderer;
import com.google.android.filament.Scene;
import com.google.android.filament.Skybox;
import com.google.android.filament.SwapChain;
import com.google.android.filament.VertexBuffer;
import com.google.android.filament.View;
import com.google.android.filament.Viewport;
import com.google.android.filament.android.DisplayHelper;
import com.google.android.filament.android.FilamentHelper;
import com.google.android.filament.android.UiHelper;
import com.google.android.filament.filamat.MaterialBuilder;
import com.google.android.filament.filamat.MaterialPackage;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Native Filament PBR preview/game board. All engine operations run on the Activity UI thread.
 * Self-contained: generated geometry, runtime-generated Filamat shaders, no external 3D models.
 */
public final class FilamentBoard implements UiHelper.RendererCallback, Choreographer.FrameCallback {
    private final SurfaceView surface;
    private final UiHelper uiHelper;
    private final DisplayHelper displayHelper;
    private final Engine engine;
    private final Renderer renderer;
    private final Scene scene;
    private final View view;
    private final Camera camera;
    private final Material material;
    private final IndirectLight ambient;
    private final Skybox skybox;
    private final List<MaterialInstance> materialInstances = new ArrayList<>();
    private final List<Mesh> meshes = new ArrayList<>();
    private final List<Integer> entities = new ArrayList<>();
    private final List<Integer> lights = new ArrayList<>();
    private final Mesh cube, sphere, torus, cylinder;
    private SwapChain swapChain;
    private int ballEntity;
    private final List<Integer> movingPieces = new ArrayList<>();
    private final List<float[]> movingPiecesTransforms = new ArrayList<>();
    private int level = 1;
    private boolean running;
    private boolean disposed;
    private float ballX, ballZ, rollX, rollZ, lastBallX, lastBallZ, sink;

    private static final class Mesh {
        final VertexBuffer vertices;
        final IndexBuffer indices;
        final int indexCount;
        Mesh(VertexBuffer vertices, IndexBuffer indices, int indexCount) {
            this.vertices=vertices; this.indices=indices; this.indexCount=indexCount;
        }
    }

    public FilamentBoard(Activity activity) {
        Filament.init();
        surface = new SurfaceView(activity);
        surface.setKeepScreenOn(true);
        displayHelper = new DisplayHelper(activity);
        engine = Engine.create(Engine.Backend.OPENGL);
        renderer = engine.createRenderer();
        scene = engine.createScene();
        view = engine.createView();
        camera = engine.createCamera(EntityManager.get().create());
        view.setScene(scene);
        view.setCamera(camera);
        // Filament built-in free rendering: contact occlusion, antialiasing, and restrained bloom.
        view.setAntiAliasing(View.AntiAliasing.FXAA);
        View.AmbientOcclusionOptions occlusion = new View.AmbientOcclusionOptions();
        occlusion.enabled = true;
        occlusion.radius = .42f;
        occlusion.intensity = 1.20f;
        view.setAmbientOcclusionOptions(occlusion);
        View.BloomOptions bloom = new View.BloomOptions();
        bloom.enabled = true;
        bloom.strength = .09f;
        view.setBloomOptions(bloom);
        // A restrained charcoal environment; the stage carries the highlights.
        skybox = new Skybox.Builder().color(0.012f, 0.018f, 0.033f, 1f).build(engine);
        scene.setSkybox(skybox);
        ambient = new IndirectLight.Builder().irradiance(1, new float[]{0.46f, 0.53f, 0.64f})
                .intensity(18000f).build(engine);
        scene.setIndirectLight(ambient);
        camera.lookAt(0.0, 13.1, 10.7, 0.0, 0.0, -.1, 0.0, 1.0, 0.0);
        camera.setExposure(8.0f, 1.0f/60.0f, 100f);
        // Generating a single PBR material on-device avoids a desktop-only matc step.
        MaterialBuilder.init();
        String shader = "void material(inout MaterialInputs material) {\n"
                + "  prepareMaterial(material);\n"
                + "  material.baseColor.rgb = materialParams.baseColor;\n"
                + "  material.metallic = materialParams.metallic;\n"
                + "  material.roughness = materialParams.roughness;\n"
                + "  material.reflectance = 0.65;\n"
                + "}\n";
        MaterialPackage pkg = new MaterialBuilder()
                .name("AtelierPBR")
                .platform(MaterialBuilder.Platform.MOBILE)
                .targetApi(MaterialBuilder.TargetApi.OPENGL)
                .shading(MaterialBuilder.Shading.LIT)
                .uniformParameter(MaterialBuilder.UniformType.FLOAT3, "baseColor")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "metallic")
                .uniformParameter(MaterialBuilder.UniformType.FLOAT, "roughness")
                .material(shader)
                .build(engine);
        if (!pkg.isValid()) throw new IllegalStateException("Filamat shader compilation failed");
        ByteBuffer data = pkg.getBuffer();
        material = new Material.Builder().payload(data, data.remaining()).build(engine);
        MaterialBuilder.shutdown();
        cube=makeCube(); sphere=makeSphere(30, 20); torus=makeTorus(48, 12); cylinder=makeCylinder(40);
        createLights();
        setLevel(1);
        uiHelper = new UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK);
        uiHelper.setRenderCallback(this);
        uiHelper.attachTo(surface);
    }

    public SurfaceView getSurface() { return surface; }
    public void setRunning(boolean isRunning) {
        if (disposed || running == isRunning) return;
        running = isRunning;
        if (running) Choreographer.getInstance().postFrameCallback(this);
        else Choreographer.getInstance().removeFrameCallback(this);
    }
    public void setLevel(int nextLevel) {
        level = nextLevel;
        movingPieces.clear(); movingPiecesTransforms.clear();
        for (int entity : entities) {
            scene.removeEntity(entity);
            engine.destroyEntity(entity);
            EntityManager.get().destroy(entity);
        }
        entities.clear();
        for (MaterialInstance mi : materialInstances) engine.destroyMaterialInstance(mi);
        materialInstances.clear();
        MarblePhysics game = new MarblePhysics(level);
        // Layered graphite/aluminium podium: entirely original procedural mesh geometry.
        MaterialInstance graphite = m(.050f,.072f,.096f,.22f,.33f);
        MaterialInstance darkChrome = m(.19f,.27f,.33f,.79f,.18f);
        MaterialInstance floor = m(.090f,.129f,.165f,.24f,.44f);
        MaterialInstance brass = m(.88f,.57f,.29f,.82f,.20f);
        MaterialInstance line = m(.32f,.44f,.48f,.46f,.33f);
        float hue = .13f*level;
        MaterialInstance neon = m(.14f+.10f*(level%2),.72f-.06f*hue,.79f-.07f*(level%3),.10f,.19f);
        addBox(0,-.67f,0,3.84f,.22f,4.62f,graphite);
        addBox(0,-.425f,0,3.83f,.036f,4.60f,brass);
        addBox(0,-.39f,0,3.77f,.035f,4.55f,darkChrome);
        addBox(0,-.19f,0,3.58f,.18f,4.37f,floor);
        // Edge illumination is achieved with PBR paint/inlay, no downloaded textures.
        addBox(0,-.92f,0,3.92f,.035f,4.68f,m(.021f,.034f,.056f,.31f,.33f));
        MaterialInstance railTop=m(.45f,.55f,.60f,.86f,.16f);
        for (float side:new float[]{-1,1}) {
            addBox(side*3.47f,.175f,0,.073f,.27f,4.22f,darkChrome);
            addBox(side*3.47f,.460f,0,.077f,.016f,4.22f,railTop);
            addBox(side*3.48f,.478f,0,.018f,.008f,4.19f,brass);
        }
        for (float side:new float[]{-1,1}) {
            addBox(0,.175f,side*4.255f,3.48f,.27f,.073f,darkChrome);
            addBox(0,.460f,side*4.255f,3.48f,.016f,.077f,railTop);
            addBox(0,.478f,side*4.26f,3.42f,.008f,.018f,brass);
        }
        // Laser-cut longitudinal tick marks and fine mechanical detailing.
        for(int i=0;i<9;i++) {
            float z=3.45f-i*.85f;
            for(float side:new float[]{-1f,1f}){
                addBox(side*3.24f,.004f,z,.10f,.006f,.013f,line);
            }
        }
        // Precision start chamber plate and boundary markers. Collidable chamber edge
        // is rendered below from the SAME physics obstacle list.
        MaterialInstance launch=m(.16f,.32f,.37f,.42f,.29f);
        addBox(MarblePhysics.START_X,-.006f,MarblePhysics.START_Z,.50f,.007f,.43f,launch);
        addBox(MarblePhysics.START_X, .004f,3.09f,.46f,.008f,.010f,neon);
        addBox(-3.16f,.005f,MarblePhysics.START_Z,.013f,.008f,.42f,neon);
        addBox(MarblePhysics.START_X,.011f,3.90f,.45f,.009f,.011f,neon);
        MaterialInstance wall=m(.20f,.29f,.36f,.65f,.24f);
        MaterialInstance rim=m(.49f,.59f,.64f,.75f,.16f);
        MaterialInstance accent=m(.21f,.68f,.77f,.38f,.21f);
        for(MarblePhysics.Obstacle o:game.obstacles) {
            int block=addBox(o.x,.195f,o.z,o.halfX,.195f,o.halfZ,wall);
            int cap=addBox(o.x,.400f,o.z,o.halfX,.012f,o.halfZ,rim);
            int led=addBox(o.x,.421f,o.z,Math.max(.025f,o.halfX-.05f),.007f,Math.max(.025f,o.halfZ-.025f),o.moving?neon:line);
            if(o.moving){
                trackMoving(block,.195f,o.halfX,.195f,o.halfZ);
                trackMoving(cap,.400f,o.halfX,.012f,o.halfZ);
                trackMoving(led,.421f,Math.max(.025f,o.halfX-.05f),.007f,Math.max(.025f,o.halfZ-.025f));
            }
        }
        // A dark recessed target with layered concentric rings and burnished metal.
        addShape(cylinder,game.goalX,.025f,game.goalZ,.56f,.010f,.56f,m(.008f,.015f,.028f,.12f,.78f));
        addShape(torus,game.goalX,.041f,game.goalZ,.57f,.54f,.57f,brass);
        addShape(torus,game.goalX,.048f,game.goalZ,.41f,.44f,.41f,neon);
        addShape(cylinder,game.goalX,.035f,game.goalZ,.27f,.012f,.27f,m(.012f,.039f,.050f,.11f,.38f));
        for(float side:new float[]{-1,1}){
            addBox(game.goalX+side*.70f,.008f,game.goalZ,.15f,.008f,.014f,accent);
        }
        // Decorative marble highlight: PBR reflective surface, with subtle floor shadow.
        MaterialInstance ball=m(.87f,.93f,.98f,.78f,.11f);
        ballEntity=addShape(sphere,game.x,.22f,game.z,MarblePhysics.BALL_RADIUS,MarblePhysics.BALL_RADIUS,MarblePhysics.BALL_RADIUS,ball);
        ballX=lastBallX=game.x; ballZ=lastBallZ=game.z;
        rollX=rollZ=sink=0;
        updateMovingWalls(game);
    }

    private void trackMoving(int entity, float y,float halfX,float halfY,float halfZ){
        movingPieces.add(entity);
        movingPiecesTransforms.add(new float[]{y,halfX,halfY,halfZ});
    }
    public void updateMovingWalls(MarblePhysics game){
        if(disposed || game==null)return;
        MarblePhysics.Obstacle moving=null;
        for(MarblePhysics.Obstacle o:game.obstacles)if(o.moving){moving=o;break;}
        if(moving==null)return;
        float x=moving.atX(game.animationTime);
        for(int i=0;i<movingPieces.size();i++){
            float[] dim=movingPiecesTransforms.get(i);
            float[] matrix=identity();
            Matrix.translateM(matrix,0,x,dim[0],moving.z);
            Matrix.scaleM(matrix,0,dim[1],dim[2],dim[3]);
            int inst=engine.getTransformManager().getInstance(movingPieces.get(i));
            engine.getTransformManager().setTransform(inst,matrix);
        }
    }

    public void updateBall(float x, float z, boolean scored, float dt) {
        if (disposed || ballEntity == 0) return;
        rollX += (z-lastBallZ)*115f;
        rollZ -= (x-lastBallX)*115f;
        lastBallX=x; lastBallZ=z;
        if (scored) sink = Math.min(1f,sink+dt*1.3f);
        float shrink = 1f - .70f*sink;
        float altitude = .22f - sink*.46f;
        float[] matrix = identity();
        Matrix.translateM(matrix,0,x,altitude,z);
        Matrix.rotateM(matrix,0,rollZ,0,0,1);
        Matrix.rotateM(matrix,0,rollX,1,0,0);
        Matrix.scaleM(matrix,0,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink,MarblePhysics.BALL_RADIUS*shrink);
        int instance=engine.getTransformManager().getInstance(ballEntity);
        engine.getTransformManager().setTransform(instance,matrix);
    }

    private MaterialInstance m(float r,float g,float b,float metallic,float roughness) {
        MaterialInstance mi=material.createInstance();
        mi.setParameter("baseColor", Colors.RgbType.SRGB,r,g,b);
        mi.setParameter("metallic",metallic);
        mi.setParameter("roughness",roughness);
        materialInstances.add(mi);
        return mi;
    }
    private int addBox(float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        return addShape(cube,x,y,z,sx,sy,sz,mat);
    }
    private int addShape(Mesh mesh,float x,float y,float z,float sx,float sy,float sz,MaterialInstance mat) {
        int entity=EntityManager.get().create();
        new RenderableManager.Builder(1)
                .boundingBox(new Box(0f,0f,0f,1.25f,1.25f,1.25f))
                .geometry(0,RenderableManager.PrimitiveType.TRIANGLES,mesh.vertices,mesh.indices,0,mesh.indexCount)
                .material(0,mat)
                .castShadows(true)
                .receiveShadows(true)
                .culling(false)
                .build(engine,entity);
        scene.addEntity(entity);
        float[] matrix=identity();
        Matrix.translateM(matrix,0,x,y,z);
        Matrix.scaleM(matrix,0,sx,sy,sz);
        engine.getTransformManager().setTransform(engine.getTransformManager().getInstance(entity),matrix);
        entities.add(entity);
        return entity;
    }
    private static float[] identity() { float[] m=new float[16]; Matrix.setIdentityM(m,0);return m; }
    private void createLights() {
        directional(-.42f,-1f,-.56f,85000f,1f,.94f,.83f);
        int fill=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.POINT).position(4f,7f,5f)
                .color(.60f,.74f,1f).intensity(40000f).falloff(21f).build(engine,fill);
        scene.addEntity(fill);lights.add(fill);
    }
    private void directional(float x,float y,float z,float lux,float r,float g,float b) {
        int light=EntityManager.get().create();
        new LightManager.Builder(LightManager.Type.DIRECTIONAL)
                .direction(x,y,z).color(r,g,b).intensity(lux).castShadows(true).build(engine,light);
        scene.addEntity(light);lights.add(light);
    }

    // Geometry packing: positions + tangent-frame quaternion, matching Filament lit materials.
    private Mesh upload(float[] vertex,float[] normals,int[] indices) {
        int n=vertex.length/3;
        ByteBuffer verts=ByteBuffer.allocateDirect(n*28).order(ByteOrder.nativeOrder());
        for (int i=0;i<n;i++) {
            float nx=normals[3*i],ny=normals[3*i+1],nz=normals[3*i+2];
            float tx,tz,ty;
            if (Math.abs(ny) > .92f) { tx=1f;ty=0f;tz=0f; }
            else { float len=(float)Math.hypot(nz,nx);tx=nz/len;ty=0f;tz=-nx/len; }
            float bx=ny*tz-nz*ty, by=nz*tx-nx*tz, bz=nx*ty-ny*tx;
            float[] q=new float[4];
            MathUtils.packTangentFrame(tx,ty,tz,bx,by,bz,nx,ny,nz,q);
            verts.putFloat(vertex[i*3]).putFloat(vertex[i*3+1]).putFloat(vertex[i*3+2]);
            for (float v:q) verts.putFloat(v);
        }
        verts.flip();
        ByteBuffer faces=ByteBuffer.allocateDirect(indices.length*2).order(ByteOrder.nativeOrder());
        for (int idx:indices) faces.putShort((short)idx);
        faces.flip();
        VertexBuffer vb=new VertexBuffer.Builder().bufferCount(1).vertexCount(n)
                .attribute(VertexBuffer.VertexAttribute.POSITION,0,VertexBuffer.AttributeType.FLOAT3,0,28)
                .attribute(VertexBuffer.VertexAttribute.TANGENTS,0,VertexBuffer.AttributeType.FLOAT4,12,28)
                .build(engine);
        vb.setBufferAt(engine,0,verts);
        IndexBuffer ib=new IndexBuffer.Builder().indexCount(indices.length)
                .bufferType(IndexBuffer.Builder.IndexType.USHORT).build(engine);
        ib.setBuffer(engine,faces);
        Mesh mesh=new Mesh(vb,ib,indices.length);meshes.add(mesh);return mesh;
    }
    private Mesh makeCube() {
        float[][] vertices = {
                {-1,-1,1, 1,-1,1, 1,1,1, -1,1,1},
                {1,-1,-1, -1,-1,-1, -1,1,-1, 1,1,-1},
                {1,-1,1, 1,-1,-1, 1,1,-1, 1,1,1},
                {-1,-1,-1, -1,-1,1, -1,1,1, -1,1,-1},
                {-1,1,1, 1,1,1, 1,1,-1, -1,1,-1},
                {-1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,1}
        };
        float[][] normals={{0,0,1},{0,0,-1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}};
        float[] p=new float[72],n=new float[72];int[] idx=new int[36];
        for(int f=0;f<6;f++) {
            for(int j=0;j<4;j++) for(int c=0;c<3;c++) {p[f*12+j*3+c]=vertices[f][j*3+c];n[f*12+j*3+c]=normals[f][c];}
            int t=f*6,v=f*4; idx[t]=v;idx[t+1]=v+1;idx[t+2]=v+2;idx[t+3]=v;idx[t+4]=v+2;idx[t+5]=v+3;
        }
        return upload(p,n,idx);
    }
    private Mesh makeSphere(int slices,int stacks) {
        int count=(slices+1)*(stacks+1);
        float[] p=new float[count*3],n=new float[count*3];
        int[] indices=new int[slices*stacks*6];
        int t=0;
        for(int j=0;j<=stacks;j++) {
            double a=Math.PI*j/stacks;
            for(int i=0;i<=slices;i++) {
                double b=2*Math.PI*i/slices;
                int o=(j*(slices+1)+i)*3;
                float nx=(float)(Math.sin(a)*Math.cos(b)),ny=(float)Math.cos(a),nz=(float)(Math.sin(a)*Math.sin(b));
                p[o]=n[o]=nx;p[o+1]=n[o+1]=ny;p[o+2]=n[o+2]=nz;
            }
        }
        for(int j=0;j<stacks;j++) for(int i=0;i<slices;i++) {
            int a=j*(slices+1)+i,b=a+slices+1;
            indices[t++]=a;indices[t++]=a+1;indices[t++]=b;
            indices[t++]=a+1;indices[t++]=b+1;indices[t++]=b;
        }
        return upload(p,n,indices);
    }
    private Mesh makeTorus(int slices,int sides) {
        int count=(slices+1)*(sides+1);
        float[] p=new float[count*3],n=new float[count*3];int[] idx=new int[slices*sides*6];int t=0;
        for(int a=0;a<=slices;a++) for(int b=0;b<=sides;b++) {
            double angle=a*Math.PI*2/slices,v=b*Math.PI*2/sides;
            float cs=(float)Math.cos(angle),sn=(float)Math.sin(angle),cv=(float)Math.cos(v),sv=(float)Math.sin(v);
            int o=(a*(sides+1)+b)*3;
            p[o]=(1f+.075f*cv)*cs;p[o+1]=.075f*sv;p[o+2]=(1f+.075f*cv)*sn;
            n[o]=cv*cs;n[o+1]=sv;n[o+2]=cv*sn;
        }
        for(int a=0;a<slices;a++) for(int b=0;b<sides;b++) {
            int v=a*(sides+1)+b,w=v+sides+1;
            idx[t++]=v;idx[t++]=v+1;idx[t++]=w;
            idx[t++]=w;idx[t++]=v+1;idx[t++]=w+1;
        }
        return upload(p,n,idx);
    }
    private Mesh makeCylinder(int segments) {
        float[] p=new float[(segments+1)*2*3],n=new float[p.length];
        int[] idx=new int[segments*6];int t=0;
        for(int j=0;j<2;j++) for(int i=0;i<=segments;i++) {
            int k=(j*(segments+1)+i)*3;double angle=2*Math.PI*i/segments;
            p[k]=(float)Math.cos(angle);p[k+1]=j==0?1:-1;p[k+2]=(float)Math.sin(angle);
            n[k]=0;n[k+1]=j==0?1:-1;n[k+2]=0;
        }
        // A pair of planar discs formed as triangle fans around first rim vertex.
        for(int j=0;j<2;j++) for(int i=1;i<segments-1;i++) {
            int k=j*(segments+1); idx[t++]=k;idx[t++]=j==0?k+i+1:k+i;idx[t++]=j==0?k+i:k+i+1;
        }
        // Allocate a new index array sized for only real triangles.
        int[] used=new int[t];System.arraycopy(idx,0,used,0,t);
        return upload(p,n,used);
    }

    @Override public void onNativeWindowChanged(Surface surface) {
        if (swapChain != null) engine.destroySwapChain(swapChain);
        swapChain=engine.createSwapChain(surface);
        if (this.surface.getDisplay()!=null) displayHelper.attach(renderer,this.surface.getDisplay());
    }
    @Override public void onDetachedFromSurface() {
        displayHelper.detach();
        if(swapChain!=null) {engine.destroySwapChain(swapChain);engine.flushAndWait();swapChain=null;}
    }
    @Override public void onResized(int width,int height) {
        if (height<=0) return;
        double aspect=(double)width/height;
        camera.setProjection(49.0,aspect,0.1,50.0,Camera.Fov.VERTICAL);
        view.setViewport(new Viewport(0,0,width,height));
        FilamentHelper.synchronizePendingFrames(engine);
    }
    @Override public void doFrame(long timeNanos) {
        if (!running || disposed) return;
        if (uiHelper.isReadyToRender() && swapChain != null && renderer.beginFrame(swapChain,timeNanos)) {
            renderer.render(view);renderer.endFrame();
        }
        Choreographer.getInstance().postFrameCallback(this);
    }
    public void dispose() {
        if(disposed)return;
        setRunning(false);
        uiHelper.detach();
        for(int id:entities) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(int id:lights) {scene.removeEntity(id);engine.destroyEntity(id);EntityManager.get().destroy(id);}
        for(Mesh mesh:meshes) {engine.destroyVertexBuffer(mesh.vertices);engine.destroyIndexBuffer(mesh.indices);}
        for(MaterialInstance mi:materialInstances) engine.destroyMaterialInstance(mi);
        engine.destroyMaterial(material);
        engine.destroyIndirectLight(ambient);
        engine.destroySkybox(skybox);
        engine.destroyRenderer(renderer);
        engine.destroyView(view);
        engine.destroyScene(scene);
        engine.destroyCameraComponent(camera.getEntity());
        EntityManager.get().destroy(camera.getEntity());
        engine.destroy();
        disposed=true;
    }
}
