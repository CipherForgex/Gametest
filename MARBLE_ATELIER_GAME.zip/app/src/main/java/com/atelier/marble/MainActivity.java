package com.atelier.marble;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/** Native, fully offline Android HUD over real Filament geometry. No account or server. */
public final class MainActivity extends Activity implements Choreographer.FrameCallback {
    private FrameLayout root,overlay;
    private FilamentBoard board;
    private MarblePhysics physics;
    private TextView timerText,crashText,hintText;
    // 0 menu, 1 play, 2 pause, 3 win, 4 settings, 5 levels, 6 best times, 7 wardrobe
    private int mode=0,level=1,themeChoice=0,skinChoice=0;
    private boolean globalTheme=false,assist=true,follow=true;
    private float sensitivity=.72f,inputX,inputZ,anchorX,anchorY,lastX,lastY,gestureVX,gestureVY;
    private long lastTouchMillis;
    private int fingerMode=0; // 1 steering, 2 camera, 3 suspended until fully released
    private double lastAngle,lastDistance;
    private long previousFrame;
    private float accumulator;
    private boolean active;
    private static final int WHITE=0xfff0f5fa,MUTED=0xff9badc2;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        SharedPreferences prefs=getPreferences(0);
        themeChoice=prefs.getInt("theme",0);skinChoice=prefs.getInt("skin",0);
        globalTheme=prefs.getBoolean("global_theme",false);
        assist=prefs.getBoolean("visibility_assist",true);
        follow=prefs.getBoolean("follow",true);
        sensitivity=prefs.getFloat("sensitivity",.72f);
        root=new FrameLayout(this);root.setBackgroundColor(0xff090d18);setContentView(root);
        try{
            board=new FilamentBoard(this);
            root.addView(board.getSurface(),new FrameLayout.LayoutParams(-1,-1));
            board.getSurface().setOnTouchListener((v,e)->onGameTouch(e));
            overlay=new FrameLayout(this);root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
            board.setVisibilityAssist(assist);board.setFollowBall(follow);
            applyTheme(1);showMenu();
        }catch(Throwable failure){
            root.removeAllViews();
            TextView text=label("GRAPHICS FAILED TO START\n\n"+failure.getClass().getSimpleName()+": "+failure.getMessage(),15,WHITE,true);
            text.setPadding(dp(24),dp(80),dp(24),dp(40));root.addView(text);
            android.util.Log.e("MarbleAtelier","Filament startup failed",failure);
        }
    }
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private int accent(){return VisualStyles.accent(globalTheme?themeChoice:(level-1)%VisualStyles.THEMES.length);}
    private GradientDrawable bg(int fill,int r,int stroke){
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(r));
        if(stroke!=0)d.setStroke(dp(1),stroke);return d;
    }
    private GradientDrawable gradient(int start,int end,int r){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{start,end});
        d.setCornerRadius(dp(r));return d;
    }
    private TextView label(String title,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(title);v.setTextColor(color);v.setTextSize(size);
        v.setGravity(Gravity.CENTER);v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return v;
    }
    private TextView button(String text,boolean primary,Runnable action){
        TextView b=label(text,14,primary?0xff101826:WHITE,true);
        int col=accent();
        b.setBackground(primary?gradient(lighten(col),col,15):bg(0xeb1e2a3a,15,0x657c91ab));
        b.setElevation(dp(4));b.setLetterSpacing(.04f);
        b.setOnClickListener(v->{v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);action.run();});
        return b;
    }
    private static int lighten(int argb){
        int r=Math.min(255,((argb>>16)&255)+29),g=Math.min(255,((argb>>8)&255)+29),b=Math.min(255,(argb&255)+29);
        return 0xff000000|(r<<16)|(g<<8)|b;
    }
    private FrameLayout.LayoutParams at(int w,int h,int gravity,int left,int top,int right,int bottom){
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),gravity);
        p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;
    }
    private void clear(){overlay.removeAllViews();timerText=crashText=hintText=null;}
    private View scrim(boolean solid){
        View v=new View(this);v.setBackground(gradient(solid?0xf307101c:0xd80b1421,solid?0xf00a1221:0x83090e1a,0));return v;
    }
    private void applyTheme(int n){
        if(board!=null)board.applyStyle(globalTheme?themeChoice:(n-1)%VisualStyles.THEMES.length,skinChoice);
    }
    private String levelName(int n){return new MarblePhysics(n).shapeName();}
    private SharedPreferences prefs(){return getPreferences(0);}
    private long bestMs(int n){
        if(prefs().contains("best_ms_"+n))return prefs().getLong("best_ms_"+n,Long.MAX_VALUE);
        if(prefs().contains("best"+n))return Math.round(prefs().getFloat("best"+n,9999999f)*1000);
        return Long.MAX_VALUE;
    }
    private String bestLabel(int n){long v=bestMs(n);return v==Long.MAX_VALUE?"—":time(v);}
    private String time(long millis){long cs=millis/10;return String.format(Locale.US,"%02d:%02d.%02d",cs/6000,(cs/100)%60,cs%100);}
    private void addButton(LinearLayout box,String name,boolean main,Runnable run,int height){
        TextView b=button(name,main,run);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(height));p.topMargin=dp(9);box.addView(b,p);
    }
    private LinearLayout panel(){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(19),dp(19),dp(19),dp(19));p.setBackground(bg(0xf0121b2c,24,0x6b839ab0));return p;
    }
    private void heading(LinearLayout p,String title,String subtitle){
        TextView h=label(title,27,WHITE,true);h.setLetterSpacing(.065f);p.addView(h);
        TextView s=label(subtitle,12,MUTED,false);LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,dp(45));p.addView(s,params);
    }
    private void showMenu(){
        mode=0;inputX=inputZ=0;fingerMode=0;level=1;applyTheme(1);clear();
        overlay.addView(scrim(false),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow=label("P R E C I S I O N    M A Z E",11,accent(),true);hero.addView(eyebrow);
        TextView name=label("MARBLE\nATELIER",40,WHITE,true);name.setLetterSpacing(.07f);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(9);hero.addView(name,np);
        TextView sub=label("One touch. One mistake. Start again.",13,MUTED,false);
        hero.addView(sub,new LinearLayout.LayoutParams(-1,dp(42)));
        overlay.addView(hero,at(-1,-2,Gravity.TOP,18,46,18,0));
        LinearLayout options=panel();
        addButton(options,"▶   PLAY  •  CONTINUE",true,()->startLevel(Math.min(100,Math.max(1,prefs().getInt("progress",1)))),51);
        addButton(options,"▦   100 LEVELS",false,this::showLevels,47);
        addButton(options,"◈   THEMES & MARBLES",false,this::showWardrobe,47);
        addButton(options,"★   BEST TIMES",false,this::showBestTimes,47);
        addButton(options,"⚙   CAMERA & CONTROLS",false,this::showSettings,47);
        TextView note=label("OFFLINE  ·  NO ACCOUNTS  ·  ALL LEVELS INCLUDED",10,MUTED,false);
        options.addView(note,new LinearLayout.LayoutParams(-1,dp(34)));
        overlay.addView(options,at(-1,-2,Gravity.BOTTOM,20,0,20,20));
    }
    private LinearLayout scrollPage(String title,String subtitle){
        clear();overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
        LinearLayout container=panel();heading(container,title,subtitle);
        scroll.addView(container,new ScrollView.LayoutParams(-1,-2));
        overlay.addView(scroll,at(-1,-1,Gravity.CENTER,16,37,16,25));
        return container;
    }
    private void showLevels(){
        mode=5;LinearLayout box=scrollPage("100 MAZES","Ten silhouette families, five chapters, rising difficulty.");
        addButton(box,"←  MAIN MENU",false,this::showMenu,46);
        for(int n=1;n<=MarblePhysics.LEVEL_COUNT;n++){
            final int number=n;
            String name=String.format(Locale.US,"%03d   %s     %s",n,levelName(n),bestLabel(n));
            addButton(box,name,n==prefs().getInt("progress",1),()->startLevel(number),43);
        }
    }
    private void showBestTimes(){
        mode=6;LinearLayout box=scrollPage("BEST TIMES","Personal records saved locally on your phone.");
        addButton(box,"←  MAIN MENU",true,this::showMenu,47);
        for(int n=1;n<=100;n++){
            final int number=n;
            addButton(box,String.format(Locale.US,"%03d   %s     %s",n,levelName(n),bestLabel(n)),false,()->startLevel(number),40);
        }
    }
    private void addSwatch(LinearLayout parent,String text,int colour,boolean picked,Runnable action){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowParams=new LinearLayout.LayoutParams(-1,dp(48));
        rowParams.topMargin=dp(8);
        View chip=new View(this);chip.setBackground(bg(0xff000000|colour,9,0x447e95af));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(30),dp(30));
        cp.rightMargin=dp(9);row.addView(chip,cp);
        TextView choice=button((picked?"✓  ":"◯  ")+text,picked,action);
        row.addView(choice,new LinearLayout.LayoutParams(0,-1,1));
        chip.setOnClickListener(v->action.run());
        parent.addView(row,rowParams);
    }
    private void showWardrobe(){
        mode=7;LinearLayout box=scrollPage("ATELIER STUDIO","Choose the materials and finish that suit your style.");
        addButton(box,"←  MAIN MENU",false,this::showMenu,45);
        addButton(box,"LEVEL THEME: "+(globalTheme?"CUSTOM OVERRIDE":"AUTOMATIC"),true,()->{
            globalTheme=!globalTheme;prefs().edit().putBoolean("global_theme",globalTheme).apply();
            applyTheme(1);showWardrobe();
        },48);
        TextView title=label("BOARD THEMES",16,WHITE,true);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(38));tp.topMargin=dp(14);box.addView(title,tp);
        for(int i=0;i<VisualStyles.THEMES.length;i++){
            final int selected=i;
            addSwatch(box,VisualStyles.THEMES[i],VisualStyles.PALETTES[i][4],i==themeChoice,()->{
                themeChoice=selected;globalTheme=true;
                prefs().edit().putInt("theme",themeChoice).putBoolean("global_theme",true).apply();
                applyTheme(1);showWardrobe();
            });
        }
        TextView balls=label("MARBLE FINISHES",16,WHITE,true);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(45));bp.topMargin=dp(16);box.addView(balls,bp);
        for(int i=0;i<VisualStyles.MARBLES.length;i++){
            final int selected=i;
            addSwatch(box,VisualStyles.MARBLES[i],VisualStyles.BALL_COLORS[i],skinChoice==i,()->{
                skinChoice=selected;prefs().edit().putInt("skin",selected).apply();
                applyTheme(1);showWardrobe();
            });
        }
    }
    private void showSettings(){
        mode=4;LinearLayout box=scrollPage("CONTROLS & CAMERA","Adjust the touch feel and how much you can see.");
        addButton(box,"←  MAIN MENU",false,this::showMenu,47);
        addButton(box,"BALL FOLLOW  "+(follow?"ON":"OFF"),true,()->{
            follow=!follow;prefs().edit().putBoolean("follow",follow).apply();board.setFollowBall(follow);showSettings();
        },49);
        addButton(box,"VISIBILITY ASSIST  "+(assist?"ON":"OFF"),false,()->{
            assist=!assist;prefs().edit().putBoolean("visibility_assist",assist).apply();board.setVisibilityAssist(assist);showSettings();
        },49);
        addButton(box,"DRAG FEEL: "+(sensitivity<.7?"PRECISE":sensitivity<1?"BALANCED":"QUICK"),false,()->{
            sensitivity=sensitivity<.7f?.82f:sensitivity<1f?1.15f:.55f;
            prefs().edit().putFloat("sensitivity",sensitivity).apply();showSettings();
        },49);
        TextView guide=label("ONE FINGER  —  drag to roll / flick to burst\nTWO FINGERS  —  rotate 360° / pinch to zoom\nROTATE BUTTON  —  turn exactly 90°\nOVERVIEW  —  bird's-eye view\n\nThe timer keeps running while using the camera.",13,MUTED,false);
        guide.setGravity(Gravity.LEFT);guide.setLineSpacing(dp(8),1f);
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);gp.topMargin=dp(22);box.addView(guide,gp);
    }
    private void startLevel(int n){
        level=Math.max(1,Math.min(100,n));physics=new MarblePhysics(level);
        inputX=inputZ=accumulator=0;fingerMode=0;previousFrame=0;mode=1;
        applyTheme(level);board.setFollowBall(follow);board.setVisibilityAssist(assist);
        showHud();
    }
    private void showHud(){
        clear();
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(13),dp(9),dp(12),dp(9));top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackground(bg(0xe50b1322,18,0x68849ab2));
        LinearLayout stats=new LinearLayout(this);stats.setOrientation(LinearLayout.VERTICAL);
        TextView header=label(String.format(Locale.US,"LEVEL %03d / 100   •   %s",level,physics.shapeName()),11,accent(),true);
        header.setGravity(Gravity.LEFT);stats.addView(header);
        timerText=label("00:00.00",25,WHITE,true);timerText.setGravity(Gravity.LEFT);stats.addView(timerText);
        crashText=label("BEST "+bestLabel(level)+"   ·   RESETS 0",10,MUTED,false);
        crashText.setGravity(Gravity.LEFT);stats.addView(crashText);
        top.addView(stats,new LinearLayout.LayoutParams(0,-2,1));
        TextView pause=button("Ⅱ",false,()->{mode=2;inputX=inputZ=0;showPause();});
        top.addView(pause,new LinearLayout.LayoutParams(dp(47),dp(47)));
        overlay.addView(top,at(-1,-2,Gravity.TOP,16,34,16,0));
        LinearLayout bottom=panel();bottom.setPadding(dp(12),dp(9),dp(12),dp(11));
        hintText=label("DRAG PRECISELY  ·  FLICK FOR SPEED",10,WHITE,true);
        bottom.addView(hintText,new LinearLayout.LayoutParams(-1,dp(29)));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        addTool(row,"↻ 90°",()->board.rotateCamera(90));
        addTool(row,"＋",()->board.changeZoom(.82f));
        addTool(row,"－",()->board.changeZoom(1.22f));
        addTool(row,"◎ VIEW",()->board.toggleOverview());
        bottom.addView(row,new LinearLayout.LayoutParams(-1,dp(43)));
        LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);
        addTool(row2,"RESTART",()->startLevel(level));
        addTool(row2,"MENU",this::showMenu);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(43));rp.topMargin=dp(7);bottom.addView(row2,rp);
        overlay.addView(bottom,at(-1,-2,Gravity.BOTTOM,15,0,15,22));
    }
    private void addTool(LinearLayout row,String text,Runnable action){
        TextView b=button(text,false,action);b.setTextSize(11);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.leftMargin=dp(3);p.rightMargin=dp(3);
        row.addView(b,p);
        if(row.getLayoutParams()==null)row.setMinimumHeight(dp(42));
    }
    private void showPause(){
        clear();overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=panel();heading(box,"PAUSED","Your marble stays exactly where it is.");
        addButton(box,"▶  RESUME",true,()->{mode=1;showHud();},54);
        addButton(box,"↻  RESTART LEVEL",false,()->startLevel(level),52);
        addButton(box,"◈  CUSTOMISE",false,this::showWardrobe,52);
        addButton(box,"⌂  MAIN MENU",false,this::showMenu,52);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,24,0,24,0));
    }
    private void showWin(){
        mode=3;
        long elapsed=Math.round(physics.seconds*1000);
        boolean record=elapsed<bestMs(level);
        if(record)prefs().edit().putLong("best_ms_"+level,elapsed).apply();
        prefs().edit().putInt("progress",Math.max(prefs().getInt("progress",1),Math.min(100,level+1))).apply();
        clear();overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=panel();heading(box,"MAZE CLEARED",String.format(Locale.US,"%s   ·   %d RESETS",time(elapsed),physics.crashes));
        TextView medal=label(record?"✦  NEW PERSONAL BEST":"BEST  "+bestLabel(level),16,accent(),true);
        box.addView(medal,new LinearLayout.LayoutParams(-1,dp(51)));
        addButton(box,level<100?"NEXT MAZE  →":"REPLAY FINAL MAZE",true,()->startLevel(Math.min(level+1,100)),56);
        addButton(box,"REPLAY THIS MAZE",false,()->startLevel(level),52);
        addButton(box,"MAIN MENU",false,this::showMenu,52);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,22,0,22,0));
    }
    private double pointerAngle(MotionEvent e){return Math.atan2(e.getY(1)-e.getY(0),e.getX(1)-e.getX(0));}
    private double pointerDistance(MotionEvent e){return Math.hypot(e.getX(1)-e.getX(0),e.getY(1)-e.getY(0));}
    private float worldX(float dx,float dy){return ControlMath.worldX(dx,dy,board==null?0:board.getYaw());}
    private float worldZ(float dx,float dy){return ControlMath.worldZ(dx,dy,board==null?0:board.getYaw());}
    private boolean onGameTouch(MotionEvent e){
        if(mode!=1 || physics==null)return false;
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                fingerMode=1;anchorX=lastX=e.getX();anchorY=lastY=e.getY();
                gestureVX=gestureVY=inputX=inputZ=0;lastTouchMillis=e.getEventTime();return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if(e.getPointerCount()>=2){
                    fingerMode=2;inputX=inputZ=0;
                    lastAngle=pointerAngle(e);lastDistance=pointerDistance(e);
                }return true;
            case MotionEvent.ACTION_MOVE:
                if(fingerMode==2&&e.getPointerCount()>=2){
                    double angle=pointerAngle(e),distance=pointerDistance(e);
                    double turn=Math.atan2(Math.sin(angle-lastAngle),Math.cos(angle-lastAngle));
                    board.rotateCamera((float)-Math.toDegrees(turn));
                    if(lastDistance>20 && distance>20)board.changeZoom((float)(lastDistance/distance));
                    lastAngle=angle;lastDistance=distance;
                }else if(fingerMode==1){
                    float screenX=(e.getX()-anchorX)/dp(185)*sensitivity;
                    float screenY=(e.getY()-anchorY)/dp(185)*sensitivity;
                    inputX=worldX(screenX,screenY);inputZ=worldZ(screenX,screenY);
                    long delta=e.getEventTime()-lastTouchMillis;
                    if(delta>0){
                        float vx=(e.getX()-lastX)/Math.max(1,delta);
                        float vy=(e.getY()-lastY)/Math.max(1,delta);
                        gestureVX=gestureVX*.38f+vx*.62f;
                        gestureVY=gestureVY*.38f+vy*.62f;
                    }
                    lastX=e.getX();lastY=e.getY();lastTouchMillis=e.getEventTime();
                }return true;
            case MotionEvent.ACTION_POINTER_UP:
                fingerMode=3;inputX=inputZ=0;return true;
            case MotionEvent.ACTION_UP:
                if(fingerMode==1){
                    float speed=(float)Math.hypot(gestureVX,gestureVY);
                    // Milliseconds-based velocity. Flick should be intentional, not every finger release.
                    if(speed>.75f){
                        float sx=gestureVX/speed,sy=gestureVY/speed;
                        physics.flick(worldX(sx,sy),worldZ(sx,sy));
                    }
                }
                fingerMode=0;inputX=inputZ=0;return true;
            case MotionEvent.ACTION_CANCEL:
                fingerMode=0;inputX=inputZ=0;return true;
        }
        return true;
    }
    @Override public void doFrame(long now){
        if(!active)return;
        float dt=previousFrame==0?1f/60f:Math.min(.05f,(now-previousFrame)/1e9f);previousFrame=now;
        if(mode==1&&physics!=null){
            accumulator=Math.min(accumulator+dt,.08f);
            while(accumulator>=1f/60f){physics.step(1f/60f,inputX,inputZ);accumulator-=1f/60f;}
            board.updateBall(physics.x,physics.z,physics.finished,dt);
            board.updateMovingWalls(physics);
            if(timerText!=null)timerText.setText(time(Math.round(physics.seconds*1000)));
            if(crashText!=null)crashText.setText("BEST "+bestLabel(level)+"   ·   RESETS "+physics.crashes);
            if(physics.justCrashed){
                inputX=inputZ=0;
                if(hintText!=null)hintText.setText("WALL TOUCHED — RESET!");
                root.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                physics.justCrashed=false;
            }
            if(physics.finished)showWin();
        }else if(mode==3&&physics!=null){board.updateBall(physics.x,physics.z,true,dt);}
        Choreographer.getInstance().postFrameCallback(this);
    }
    @Override protected void onResume(){super.onResume();active=true;previousFrame=0;
        if(board!=null)board.setRunning(true);Choreographer.getInstance().postFrameCallback(this);}
    @Override protected void onPause(){active=false;Choreographer.getInstance().removeFrameCallback(this);
        if(board!=null)board.setRunning(false);super.onPause();}
    @Override protected void onDestroy(){if(board!=null)board.dispose();super.onDestroy();}
    @Override public void onBackPressed(){if(mode==1){mode=2;showPause();}else if(mode==2){mode=1;showHud();}else showMenu();}
}
