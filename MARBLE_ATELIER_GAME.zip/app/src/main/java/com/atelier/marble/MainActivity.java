package com.atelier.marble;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Two playable levels, native Filament rendered board and fully native touch-friendly HUD. */
public class MainActivity extends Activity implements Choreographer.FrameCallback {
    private FrameLayout root, overlay;
    private FilamentBoard board;
    private MarblePhysics physics;
    private TextView timerText, hintText;
    private int level=1, mode=0; // 0 menu, 1 playing, 2 paused, 3 won
    private float impulseX, impulseZ, lastX, lastY;
    private long previousFrame;
    private float accumulator;
    private boolean active=false;
    private static final int WHITE=0xfff1f5f9, MUTED=0xff9daebf, GOLD=0xfff4bb78;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        root=new FrameLayout(this);
        root.setBackgroundColor(0xff050b13);
        setContentView(root);
        try {
            board=new FilamentBoard(this);
            root.addView(board.getSurface(), new FrameLayout.LayoutParams(-1,-1));
            board.getSurface().setOnTouchListener((v,event)->onGameTouch(event));
            overlay=new FrameLayout(this);
            root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
            showMenu();
        } catch(Throwable failure) {
            root.removeAllViews();
            TextView error=text("GRAPHICS INITIALISATION FAILED\n\n" + failure.getClass().getSimpleName() + ": " + failure.getMessage()
                + "\n\nPlease capture this screen and the GitHub build logs.",16,WHITE,true);
            error.setPadding(dp(24),dp(100),dp(24),0);
            root.addView(error);
            android.util.Log.e("MarbleAtelier","Unable to start Filament",failure);
        }
    }
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private GradientDrawable bg(int fill,int radius,int stroke){
        GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private GradientDrawable gradient(int top,int bottom,int rad){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom});
        g.setCornerRadius(dp(rad));return g;
    }
    private TextView text(String s,int sp,int c,boolean bold){
        TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);
        v.setGravity(Gravity.CENTER);v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create("sans-serif" ,bold?Typeface.BOLD:Typeface.NORMAL));
        return v;
    }
    private FrameLayout.LayoutParams at(int w,int h,int gravity,int left,int top,int right,int bottom) {
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),gravity);
        p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;
    }
    private TextView action(String label,boolean primary,Runnable callback){
        TextView v=text(label,15,primary?0xff11161e:WHITE,true);
        v.setLetterSpacing(.07f);
        v.setBackground(primary?gradient(0xfff8d09d,0xffe8a765,18):bg(0xe5223041,18,0x557b8da4));
        v.setElevation(dp(6));
        v.setOnClickListener(x->{v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);callback.run();});
        return v;
    }
    private View scrim(boolean strong){
        View v=new View(this);
        v.setBackground(gradient(strong?0xf2050b13:0xd9050b13,strong?0xdb070f18:0x12060a13,0));
        return v;
    }
    private void clearUi(){if(overlay!=null)overlay.removeAllViews();timerText=null;hintText=null;}

    private void showMenu() {
        mode=0;impulseX=impulseZ=0;
        if(board!=null)board.setLevel(1);
        clearUi();
        overlay.addView(scrim(false),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView edition=text("A   T A C T I L E   P U Z Z L E",10,GOLD,true);
        edition.setLetterSpacing(.25f);head.addView(edition);
        TextView title=text("MARBLE\nATELIER",43,WHITE,true);title.setLineSpacing(dp(-6),1f);
        title.setLetterSpacing(.08f);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(14);head.addView(title,tp);
        TextView sub=text("A little world of motion.",15,MUTED,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(42));head.addView(sub,sp);
        overlay.addView(head,at(-1,-2,Gravity.TOP,16,89,16,0));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(23),dp(22),dp(23),dp(25));
        bottom.setBackground(gradient(0xb5192939,0xf10a121d,25));
        TextView label=text("CHOOSE AN EXPERIMENT",11,GOLD,true);label.setLetterSpacing(.15f);
        bottom.addView(label,new LinearLayout.LayoutParams(-1,dp(32)));
        TextView one=action("01     THE FIRST ROLL     →",true,()->startLevel(1));
        LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(-1,dp(60));p1.topMargin=dp(9);bottom.addView(one,p1);
        TextView two=action("02     THE LONG WAY     →",false,()->startLevel(2));
        LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(-1,dp(60));p2.topMargin=dp(12);bottom.addView(two,p2);
        TextView footer=text("2 TEST LEVELS   •   OFFLINE   •   NO ADS",10,0xff7990a5,false);
        footer.setLetterSpacing(.12f);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(40));fp.topMargin=dp(8);bottom.addView(footer,fp);
        overlay.addView(bottom,at(-1,-2,Gravity.BOTTOM,20,0,20,34));
    }

    private void startLevel(int n){
        if(board==null)return;
        level=n;physics=new MarblePhysics(level);board.setLevel(level);
        impulseX=impulseZ=0;accumulator=0;previousFrame=0;mode=1;
        showGameHud();
    }
    private void showGameHud() {
        clearUi();
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(17),dp(13),dp(12),dp(13));head.setBackground(bg(0xda0c1725,19,0x335e7083));
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);
        TextView lb=text(String.format(Locale.US,"EXPERIMENT  %02d",level),10,GOLD,true);lb.setGravity(Gravity.LEFT);
        lb.setLetterSpacing(.17f);labels.addView(lb);
        timerText=text("00:00",24,WHITE,true);timerText.setGravity(Gravity.LEFT);
        labels.addView(timerText);
        head.addView(labels,new LinearLayout.LayoutParams(0,-2,1f));
        TextView pause=action("Ⅱ",false,()->{mode=2;showPaused();});
        head.addView(pause,new LinearLayout.LayoutParams(dp(53),dp(48)));
        overlay.addView(head,at(-1,-2,Gravity.TOP,20,45,20,0));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackground(bg(0xd60d1724,19,0x3e718196));bottom.setPadding(dp(18),dp(12),dp(18),dp(14));
        hintText=text("SWIPE THE BOARD TO ROLL",12,WHITE,true);hintText.setLetterSpacing(.13f);
        bottom.addView(hintText,new LinearLayout.LayoutParams(-1,dp(37)));
        TextView help=text("Guide the marble into the glowing hole.\nAvoid the raised blocks.",12,MUTED,false);
        help.setLineSpacing(dp(3),1f);bottom.addView(help,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
        TextView restart=action("↻   RESTART",false,()->startLevel(level));
        tools.addView(restart,new LinearLayout.LayoutParams(0,dp(49),1f));
        TextView menu=action("⌂   MENU",false,this::showMenu);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(49),1f);mp.leftMargin=dp(10);tools.addView(menu,mp);
        bottom.addView(tools);
        overlay.addView(bottom,at(-1,-2,Gravity.BOTTOM,22,0,22,36));
    }
    private void showPaused() {
        overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=modal("PAUSED","Take your time. Your progress is safe.");
        TextView resume=action("RESUME GAME",true,()->{mode=1;showGameHud();});
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(57));rp.topMargin=dp(22);box.addView(resume,rp);
        TextView retry=action("START AGAIN",false,()->startLevel(level));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(55));ep.topMargin=dp(12);box.addView(retry,ep);
        TextView menu=action("MAIN MENU",false,this::showMenu);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(55));mp.topMargin=dp(12);box.addView(menu,mp);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,30,0,30,0));
    }
    private LinearLayout modal(String title,String subtitle) {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(25),dp(30),dp(25),dp(30));box.setBackground(bg(0xf0142030,26,0x667c8fa6));box.setElevation(dp(12));
        TextView t=text(title,32,WHITE,true);t.setLetterSpacing(.08f);box.addView(t);
        TextView sub=text(subtitle,13,MUTED,false);sub.setLineSpacing(dp(3),1f);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);box.addView(sub,p);
        return box;
    }
    private void showWin() {
        mode=3;
        float best=getPreferences(0).getFloat("best"+level,Float.POSITIVE_INFINITY);
        boolean record=physics.seconds < best;
        if(record)getPreferences(0).edit().putFloat("best"+level,physics.seconds).apply();
        if(overlay==null)return;
        overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=modal("BEAUTIFULLY DONE.",String.format(Locale.US,"Completed experiment %02d in %s",level,format(physics.seconds)));
        TextView trophy=text(record?"✦   NEW PERSONAL BEST":"✦   EXPERIMENT COMPLETE",12,GOLD,true);
        trophy.setLetterSpacing(.10f);
        LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(-1,dp(48));xp.topMargin=dp(8);box.addView(trophy,xp);
        TextView go=action(level==1?"NEXT EXPERIMENT  →":"PLAY AGAIN  ↻",true,()->startLevel(level==1?2:2));
        box.addView(go,new LinearLayout.LayoutParams(-1,dp(60)));
        TextView menu=action("BACK TO MENU",false,this::showMenu);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(55));mp.topMargin=dp(12);box.addView(menu,mp);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,22,0,22,0));
    }
    private static String format(float secs) {
        int whole=(int)secs;return String.format(Locale.US,"%02d:%02d",whole/60,whole%60);
    }
    private boolean onGameTouch(MotionEvent e) {
        if(mode!=1 || physics==null)return false;
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX=e.getX();lastY=e.getY();return true;
            case MotionEvent.ACTION_MOVE:
                float x=e.getX(),y=e.getY();
                impulseX=Math.max(-1.0f,Math.min(1.0f,impulseX+(x-lastX)/25f));
                impulseZ=Math.max(-1.0f,Math.min(1.0f,impulseZ+(y-lastY)/25f));
                lastX=x;lastY=y;return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:return true;
        }
        return true;
    }
    @Override public void doFrame(long now) {
        if(!active)return;
        float dt=previousFrame==0?1f/60f:Math.min(.05f,(now-previousFrame)/1e9f);
        previousFrame=now;
        if(mode==1 && physics!=null) {
            accumulator=Math.min(accumulator+dt,.08f);
            while(accumulator>=1f/60f) {
                physics.step(1f/60f,impulseX,impulseZ);
                impulseX*=.92f;impulseZ*=.92f;
                accumulator-=1f/60f;
            }
            board.updateBall(physics.x,physics.z,physics.finished,dt);
            if(timerText!=null) timerText.setText(format(physics.seconds));
            if(physics.finished)showWin();
        } else if(mode==3 && physics!=null && board!=null) {
            board.updateBall(physics.x,physics.z,true,dt);
        }
        Choreographer.getInstance().postFrameCallback(this);
    }
    @Override protected void onResume(){super.onResume();active=true;previousFrame=0;
        if(board!=null)board.setRunning(true);Choreographer.getInstance().postFrameCallback(this);}
    @Override protected void onPause(){active=false;Choreographer.getInstance().removeFrameCallback(this);
        if(board!=null)board.setRunning(false);super.onPause();}
    @Override protected void onDestroy(){if(board!=null)board.dispose();super.onDestroy();}
    @Override public void onBackPressed(){if(mode==1){mode=2;showPaused();}else if(mode==2){mode=1;showGameHud();}else if(mode==3)showMenu();else super.onBackPressed();}
}
