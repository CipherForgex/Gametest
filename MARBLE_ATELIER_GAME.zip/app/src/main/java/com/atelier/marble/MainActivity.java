package com.atelier.marble;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.util.Locale;

/** Two playable levels, native Filament rendered board and fully native touch-friendly HUD. */
public class MainActivity extends Activity implements Choreographer.FrameCallback {
    private FrameLayout root, overlay;
    private FilamentBoard board;
    private MarblePhysics physics;
    private TextView timerText, hintText, crashText;
    private int level=1, mode=0; // 0 menu, 1 playing, 2 paused, 3 won
    private float impulseX, impulseZ, touchX, touchY;
    private long previousFrame;
    private float accumulator;
    private boolean active=false;
    private static final int WHITE=0xfff1f5f9, MUTED=0xff9daebf, GOLD=0xfff4bb78;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        root=new FrameLayout(this);
        root.setBackgroundColor(0xff050b13);
        setContentView(root);
        try {
            board=new FilamentBoard(this);
            root.addView(board.getSurface(), new FrameLayout.LayoutParams(-1,-1));
            board.getSurface().setOnTouchListener((v,event)->onGameTouch(event));
            overlay=new FrameLayout(this);
            root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
            showMenu();
        } catch(Throwable failure) {
            root.removeAllViews();
            TextView error=text("GRAPHICS INITIALISATION FAILED\n\n" + failure.getClass().getSimpleName() + ": " + failure.getMessage()
                + "\n\nPlease capture this screen and the GitHub build logs.",16,WHITE,true);
            error.setPadding(dp(24),dp(100),dp(24),0);
            root.addView(error);
            android.util.Log.e("MarbleAtelier","Unable to start Filament",failure);
        }
    }
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private GradientDrawable bg(int fill,int radius,int stroke){
        GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private GradientDrawable gradient(int top,int bottom,int rad){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom});
        g.setCornerRadius(dp(rad));return g;
    }
    private TextView text(String s,int sp,int c,boolean bold){
        TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);
        v.setGravity(Gravity.CENTER);v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create("sans-serif" ,bold?Typeface.BOLD:Typeface.NORMAL));
        return v;
    }
    private FrameLayout.LayoutParams at(int w,int h,int gravity,int left,int top,int right,int bottom) {
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),gravity);
        p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;
    }
    private TextView action(String label,boolean primary,Runnable callback){
        TextView v=text(label,15,primary?0xff11161e:WHITE,true);
        v.setLetterSpacing(.07f);
        v.setBackground(primary?gradient(0xfff8d09d,0xffe8a765,18):bg(0xe5223041,18,0x557b8da4));
        v.setElevation(dp(6));
        v.setOnClickListener(x->{v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);callback.run();});
        return v;
    }
    private View scrim(boolean strong){
        View v=new View(this);
        v.setBackground(gradient(strong?0xf2050b13:0xd9050b13,strong?0xdb070f18:0x12060a13,0));
        return v;
    }
    private void clearUi(){if(overlay!=null)overlay.removeAllViews();timerText=null;hintText=null;crashText=null;}

    private static final String[] LEVEL_NAMES={"FIRST STEPS","THE CROSSING","THIN LINE","THE GAUNTLET","MOVING TARGET"};
    private long bestMs(int n) {
        SharedPreferences prefs=getPreferences(0);
        if(prefs.contains("best_ms_"+n))return prefs.getLong("best_ms_"+n,Long.MAX_VALUE);
        if(prefs.contains("best"+n))return Math.round(prefs.getFloat("best"+n,9999999f)*1000f);
        return Long.MAX_VALUE;
    }
    private String bestLabel(int n){long v=bestMs(n);return v==Long.MAX_VALUE?"—":formatMillis(v);}
    private static String formatMillis(long millis){
        long cs=millis/10;
        return String.format(Locale.US,"%02d:%02d.%02d",cs/6000,(cs/100)%60,cs%100);
    }
    private void showMenu() {
        mode=0;impulseX=impulseZ=0;
        if(board!=null)board.setLevel(1);
        clearUi();
        overlay.addView(scrim(false),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView edition=text("P R E C I S I O N    M A Z E",11,GOLD,true);
        edition.setLetterSpacing(.19f);head.addView(edition);
        TextView title=text("MARBLE\nATELIER",42,WHITE,true);title.setLineSpacing(dp(-6),1f);
        title.setLetterSpacing(.07f);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(11);head.addView(title,tp);
        TextView sub=text("Every touch matters.",15,MUTED,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(38));head.addView(sub,sp);
        overlay.addView(head,at(-1,-2,Gravity.TOP,15,51,15,0));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(18),dp(16),dp(18),dp(17));
        bottom.setBackground(gradient(0xe0132030,0xf30a111b,23));
        TextView label=text("FIVE TRIALS   •   ONE PERFECT RUN",10,GOLD,true);label.setLetterSpacing(.12f);
        bottom.addView(label,new LinearLayout.LayoutParams(-1,dp(27)));
        for(int n=1;n<=MarblePhysics.LEVEL_COUNT;n++) {
            final int index=n;
            String caption=String.format(Locale.US,"%02d  %s       %s",n,LEVEL_NAMES[n-1],bestLabel(n));
            TextView entry=action(caption,n==1,()->startLevel(index));entry.setTextSize(12);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(51));lp.topMargin=dp(6);bottom.addView(entry,lp);
        }
        TextView records=action("★   BEST TIMES",false,this::showBestTimes);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(43));rp.topMargin=dp(11);bottom.addView(records,rp);
        TextView footer=text("OFFLINE  •  NO ADS  •  TOUCH A WALL = RESTART",9,0xff8094a6,false);
        footer.setLetterSpacing(.04f);bottom.addView(footer,new LinearLayout.LayoutParams(-1,dp(31)));
        overlay.addView(bottom,at(-1,-2,Gravity.BOTTOM,17,0,17,19));
    }
    private void showBestTimes(){
        clearUi();mode=0;
        overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=modal("BEST TIMES","Fastest clean runs saved on this phone.");
        for(int n=1;n<=MarblePhysics.LEVEL_COUNT;n++){
            TextView line=text(String.format(Locale.US,"%02d    %-18s    %s",n,LEVEL_NAMES[n-1],bestLabel(n)),13,WHITE,false);
            line.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44));lp.topMargin=dp(4);box.addView(line,lp);
        }
        TextView back=action("BACK TO MENU",true,this::showMenu);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(55));bp.topMargin=dp(14);box.addView(back,bp);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,18,0,18,0));
    }

    private void startLevel(int n){
        if(board==null)return;
        level=n;physics=new MarblePhysics(level);board.setLevel(level);
        impulseX=impulseZ=0;accumulator=0;previousFrame=0;mode=1;
        showGameHud();
    }
    private void showGameHud() {
        clearUi();
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(16),dp(11),dp(12),dp(10));head.setBackground(bg(0xe10c1725,18,0x435e7083));
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);
        TextView lb=text(String.format(Locale.US,"%02d / 05   %s",level,LEVEL_NAMES[level-1]),10,GOLD,true);
        lb.setGravity(Gravity.LEFT);lb.setLetterSpacing(.09f);labels.addView(lb);
        timerText=text("00:00.00",26,WHITE,true);timerText.setGravity(Gravity.LEFT);labels.addView(timerText);
        crashText=text("BEST "+bestLabel(level)+"   •   RESETS 0",10,MUTED,false);
        crashText.setGravity(Gravity.LEFT);labels.addView(crashText);
        head.addView(labels,new LinearLayout.LayoutParams(0,-2,1f));
        TextView pause=action("Ⅱ",false,()->{mode=2;showPaused();});
        head.addView(pause,new LinearLayout.LayoutParams(dp(48),dp(46)));
        overlay.addView(head,at(-1,-2,Gravity.TOP,17,40,17,0));
        LinearLayout bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackground(bg(0xe00d1724,19,0x3e718196));bottom.setPadding(dp(15),dp(10),dp(15),dp(13));
        hintText=text("DRAG TO STEER  •  WALL TOUCH RESETS",11,WHITE,true);
        hintText.setLetterSpacing(.06f);bottom.addView(hintText,new LinearLayout.LayoutParams(-1,dp(37)));
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
        TextView restart=action("↻   RESTART",false,()->startLevel(level));
        tools.addView(restart,new LinearLayout.LayoutParams(0,dp(47),1f));
        TextView menu=action("⌂   MENU",false,this::showMenu);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(47),1f);mp.leftMargin=dp(9);tools.addView(menu,mp);
        bottom.addView(tools);
        overlay.addView(bottom,at(-1,-2,Gravity.BOTTOM,19,0,19,28));
    }
    private void showPaused() {
        overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=modal("PAUSED","Take your time. Your progress is safe.");
        TextView resume=action("RESUME GAME",true,()->{mode=1;showGameHud();});
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(57));rp.topMargin=dp(22);box.addView(resume,rp);
        TextView retry=action("START AGAIN",false,()->startLevel(level));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(55));ep.topMargin=dp(12);box.addView(retry,ep);
        TextView menu=action("MAIN MENU",false,this::showMenu);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(55));mp.topMargin=dp(12);box.addView(menu,mp);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,30,0,30,0));
    }
    private LinearLayout modal(String title,String subtitle) {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(25),dp(30),dp(25),dp(30));box.setBackground(bg(0xf0142030,26,0x667c8fa6));box.setElevation(dp(12));
        TextView t=text(title,32,WHITE,true);t.setLetterSpacing(.08f);box.addView(t);
        TextView sub=text(subtitle,13,MUTED,false);sub.setLineSpacing(dp(3),1f);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);box.addView(sub,p);
        return box;
    }
    private void showWin() {
        mode=3;
        long completed=Math.round(physics.seconds*1000);
        long best=bestMs(level);
        boolean record=completed<best;
        if(record)getPreferences(0).edit().putLong("best_ms_"+level,completed).apply();
        if(overlay==null)return;
        overlay.addView(scrim(true),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout box=modal("MAZE COMPLETE",String.format(Locale.US,"LEVEL %02d  •  %s  •  %d RESETS",
              level,formatMillis(completed),physics.crashes));
        TextView trophy=text(record?"✦   NEW BEST TIME":"✦   BEST: "+formatMillis(bestMs(level)),13,GOLD,true);
        LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(-1,dp(54));xp.topMargin=dp(8);box.addView(trophy,xp);
        TextView go=action(level<MarblePhysics.LEVEL_COUNT?"NEXT LEVEL  →":"REPLAY FINAL LEVEL  ↻",true,
              ()->startLevel(Math.min(MarblePhysics.LEVEL_COUNT,level+1)));
        box.addView(go,new LinearLayout.LayoutParams(-1,dp(57)));
        TextView menu=action("MAIN MENU",false,this::showMenu);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(53));mp.topMargin=dp(11);box.addView(menu,mp);
        overlay.addView(box,at(-1,-2,Gravity.CENTER,22,0,22,0));
    }
    private boolean onGameTouch(MotionEvent e) {
        if(mode!=1 || physics==null)return false;
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touchX=e.getX();touchY=e.getY();impulseX=impulseZ=0;
                return true;
            case MotionEvent.ACTION_MOVE:
                impulseX=Math.max(-1f,Math.min(1f,(e.getX()-touchX)/dp(80)));
                impulseZ=Math.max(-1f,Math.min(1f,(e.getY()-touchY)/dp(80)));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                impulseX=impulseZ=0;return true;
        }
        return true;
    }
    @Override public void doFrame(long now) {
        if(!active)return;
        float dt=previousFrame==0?1f/60f:Math.min(.05f,(now-previousFrame)/1e9f);
        previousFrame=now;
        if(mode==1 && physics!=null) {
            accumulator=Math.min(accumulator+dt,.08f);
            while(accumulator>=1f/60f) {
                physics.step(1f/60f,impulseX,impulseZ);
                accumulator-=1f/60f;
            }
            board.updateBall(physics.x,physics.z,physics.finished,dt);
            board.updateMovingWalls(physics);
            if(timerText!=null) timerText.setText(formatMillis(Math.round(physics.seconds*1000)));
            if(crashText!=null)crashText.setText("BEST "+bestLabel(level)+"   •   RESETS "+physics.crashes);
            if(physics.justCrashed) {
                impulseX=impulseZ=0;
                if(hintText!=null)hintText.setText("WALL HIT — BACK TO START");
                root.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                physics.justCrashed=false;
            }
            if(physics.finished)showWin();
        } else if(mode==3 && physics!=null && board!=null) {
            board.updateBall(physics.x,physics.z,true,dt);
        }
        Choreographer.getInstance().postFrameCallback(this);
    }
    @Override protected void onResume(){super.onResume();active=true;previousFrame=0;
        if(board!=null)board.setRunning(true);Choreographer.getInstance().postFrameCallback(this);}
    @Override protected void onPause(){active=false;Choreographer.getInstance().removeFrameCallback(this);
        if(board!=null)board.setRunning(false);super.onPause();}
    @Override protected void onDestroy(){if(board!=null)board.dispose();super.onDestroy();}
    @Override public void onBackPressed(){if(mode==1){mode=2;showPaused();}else if(mode==2){mode=1;showGameHud();}else if(mode==3)showMenu();else super.onBackPressed();}
}
