package com.atelier.marble;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pure Java, deterministic fixed-step precision maze. X/Z units are also Filament world units.
 * Every contact with a wall or moving hazard is fatal, including contact between two frames.
 * Physics never trusts the renderer for collision boundaries.
 */
public final class MarblePhysics {
    public static final int LEVEL_COUNT = 5;
    public static final float BALL_RADIUS = 0.20f;
    public static final float HALF_WIDTH = 3.40f, HALF_LENGTH = 4.18f;
    public static final float START_X = -2.67f, START_Z = 3.53f;
    private static final float ACCEL = 7.5f, DRAG = 2.45f, MAX_SPEED = 3.25f;
    public final int level;
    public final List<Obstacle> obstacles;
    public final float goalX, goalZ;
    public float x, z, vx, vz, seconds, animationTime;
    public boolean finished, justCrashed;
    public int crashes;

    public static final class Obstacle {
        public final float x, z, halfX, halfZ;
        public final float sweep, speed, phase;
        public final boolean moving;
        public Obstacle(float x, float z, float halfX, float halfZ) {
            this(x,z,halfX,halfZ,0,0,0);
        }
        public Obstacle(float x, float z, float halfX, float halfZ,
                        float sweep, float speed, float phase) {
            this.x=x; this.z=z; this.halfX=halfX; this.halfZ=halfZ;
            this.sweep=sweep; this.speed=speed; this.phase=phase;
            this.moving=sweep != 0;
        }
        public float atX(float clock) {
            return x + sweep * (float)Math.sin(clock * speed + phase);
        }
    }

    public MarblePhysics(int level) {
        if (level < 1 || level > LEVEL_COUNT) throw new IllegalArgumentException("Level: " + level);
        this.level=level;
        ArrayList<Obstacle> walls=new ArrayList<>();
        // Start is a small safe, 3-sided launch chamber; exit is ONLY toward the maze.
        walls.add(new Obstacle(-2.00f, 3.44f, .085f, .53f));
        float[] rows;
        float gap;
        switch (level) {
            case 1: rows=new float[]{1.23f,-1.53f}; gap=1.78f; break;
            case 2: rows=new float[]{2.00f,-.40f,-2.75f}; gap=1.52f; break;
            case 3: rows=new float[]{2.32f,.75f,-.82f,-2.41f}; gap=1.35f; break;
            case 4: rows=new float[]{2.55f,1.19f,-.17f,-1.55f,-2.92f}; gap=1.20f; break;
            default: rows=new float[]{2.55f,1.19f,-.17f,-1.55f,-2.92f};gap=1.08f;break;
        }
        for (int i=0;i<rows.length;i++) {
            boolean openLeft=(i%2==0);
            float openingCenter=openLeft?-2.60f:2.60f;
            float openingMin=openingCenter-gap*.5f;
            float openingMax=openingCenter+gap*.5f;
            float left=openLeft?openingMax:-HALF_WIDTH;
            float right=openLeft?HALF_WIDTH:openingMin;
            walls.add(new Obstacle((left+right)*.5f,rows[i],(right-left)*.5f,.115f));
        }
        // Level 5: moving crossbar sweeps the middle, between the last two maze rows.
        // Its 0.45-wide body has a real collision shape in exactly the rendered position.
        if (level==5) walls.add(new Obstacle(0f,-2.23f,.48f,.105f,1.55f,1.18f,.38f));
        this.goalX=(rows.length%2==0)?2.62f:-2.62f;
        this.goalZ=-3.69f;
        obstacles=Collections.unmodifiableList(walls);
        resetAll();
    }

    public void resetAll() { crashes=0; animationTime=0f; resetRun(); }
    public void resetRun() {
        x=START_X; z=START_Z;vx=0;vz=0;seconds=0;finished=false;justCrashed=false;
    }
    public void step(float dt,float inputX,float inputZ) {
        if(finished || !(dt>0))return;
        dt=Math.min(dt,1f/30f);
        float priorClock=animationTime;
        animationTime+=dt;
        seconds+=dt;
        float mag=(float)Math.hypot(inputX,inputZ);
        if(mag>1f) {inputX/=mag;inputZ/=mag;}
        vx+=inputX*ACCEL*dt;vz+=inputZ*ACCEL*dt;
        float attenuation=(float)Math.exp(-DRAG*dt);
        vx*=attenuation;vz*=attenuation;
        float speed=(float)Math.hypot(vx,vz);
        if(speed>MAX_SPEED){vx*=MAX_SPEED/speed;vz*=MAX_SPEED/speed;}
        float oldX=x,oldZ=z;
        float travel=(float)Math.hypot(vx*dt,vz*dt);
        // Sample <= 0.05 units per substep: no skip-through even at terminal velocity.
        // Moving walls are swept at the same substep clock, avoiding contact tunnelling.
        int count=Math.max(1,(int)Math.ceil(travel/.045f));
        for(int n=1;n<=count;n++){
            float t=(float)n/count;
            x=oldX+vx*dt*t;
            z=oldZ+vz*dt*t;
            float clock=priorClock+dt*t;
            if(hitsAnything(clock)){
                crashes++;
                resetRun();
                justCrashed=true;
                return;
            }
        }
        if(Math.hypot(x-goalX,z-goalZ)<.33f) {
            finished=true;vx=vz=0;
        }
    }
    public boolean hitsAnything(float clock) {
        if(x-BALL_RADIUS <= -HALF_WIDTH || x+BALL_RADIUS >= HALF_WIDTH
                || z-BALL_RADIUS <= -HALF_LENGTH || z+BALL_RADIUS >= HALF_LENGTH) return true;
        for(Obstacle o: obstacles) if(touches(o,clock))return true;
        return false;
    }
    public boolean touches(Obstacle o,float clock) {
        float nearestX=Math.max(o.atX(clock)-o.halfX,Math.min(x,o.atX(clock)+o.halfX));
        float nearestZ=Math.max(o.z-o.halfZ,Math.min(z,o.z+o.halfZ));
        float dx=x-nearestX,dz=z-nearestZ;
        return dx*dx+dz*dz <= BALL_RADIUS*BALL_RADIUS;
    }
}
