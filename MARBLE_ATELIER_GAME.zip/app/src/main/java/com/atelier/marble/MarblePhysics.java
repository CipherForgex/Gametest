package com.atelier.marble;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Deterministic offline maze generator. Geometry and collision share the exact same walls.
 * A randomized depth-first spanning tree produces one connected, guaranteed-solvable maze.
 * Each generated level has a different deterministic seed; changing a skin does not change gameplay.
 */
public final class MarblePhysics {
    public static final int LEVEL_COUNT = 100;
    public static final float BALL_RADIUS = .155f;
    public static final String[] SHAPES = {"ORBIT", "DIAMOND", "HEXAGON", "OCTAGON", "ROUNDED", "CLOVER", "STAR", "TRAPEZOID", "CAPSULE", "TEARDROP"};
    private static final int[] DX = {1,0,-1,0};
    private static final int[] DY = {0,1,0,-1};
    private static final int[] OPP = {2,3,0,1};
    public final int level, cols, rows, shapeType;
    public final float cellSize, halfWidth, halfLength, startX, startZ, goalX, goalZ;
    public final List<Obstacle> obstacles;
    private final boolean[][] occupied;
    private final int[][] paths;
    private final int[][] rampDirections;
    public float x, z, vx, vz, seconds, animationTime;
    public boolean finished, justCrashed;
    public int crashes;
    private static final float ACCEL = 5.8f, FRICTION = 3.25f, MAX_SPEED = 3.0f;

    public static final class Obstacle {
        public final float x,z,halfX,halfZ,sweep,speed,phase;
        public final boolean moving;
        public Obstacle(float x,float z,float halfX,float halfZ) { this(x,z,halfX,halfZ,0,0,0); }
        public Obstacle(float x,float z,float halfX,float halfZ,float sweep,float speed,float phase) {
            this.x=x;this.z=z;this.halfX=halfX;this.halfZ=halfZ;
            this.sweep=sweep;this.speed=speed;this.phase=phase;moving=sweep!=0;
        }
        public float atX(float t) { return x+sweep*(float)Math.sin(t*speed+phase); }
    }

    private static final class Cell {
        final int x,y;
        Cell(int x,int y){this.x=x;this.y=y;}
    }
    public MarblePhysics(int level) {
        if(level<1 || level>LEVEL_COUNT)throw new IllegalArgumentException("level "+level);
        this.level=level;
        int stage=(level-1)/20;
        cols=5+stage;
        rows=6+stage;
        cellSize=Math.min(7.2f/cols,8.0f/rows);
        halfWidth=cols*cellSize*.5f;
        halfLength=rows*cellSize*.5f;
        shapeType=(level-1)%SHAPES.length;
        occupied=new boolean[cols][rows];
        paths=new int[cols][rows];
        rampDirections=new int[cols][rows];
        float shapeVariation=((level/10)%3-1)*.055f;
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++){
            float nx=((i+.5f)/cols-.5f)*2f;
            float ny=((j+.5f)/rows-.5f)*2f;
            occupied[i][j]=inShape(nx,ny,shapeType,shapeVariation);
        }
        // Retain the largest four-neighbour component so all playable cells are connected.
        retainLargestComponent();
        int count=0;
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)if(occupied[i][j])count++;
        if(count<5)throw new IllegalStateException("shape too small on level "+level);
        Random rand=new Random(0x5CA1A71L+level*91873L);
        Cell initial=null;
        for(int j=rows-1;j>=0 && initial==null;j--)for(int i=0;i<cols;i++)if(occupied[i][j]){initial=new Cell(i,j);break;}
        boolean[][] seen=new boolean[cols][rows];
        ArrayDeque<Cell> stack=new ArrayDeque<>();stack.push(initial);seen[initial.x][initial.y]=true;
        while(!stack.isEmpty()) {
            Cell at=stack.peek();int[] directions={0,1,2,3};
            for(int k=3;k>0;k--){int t=rand.nextInt(k+1),v=directions[t];directions[t]=directions[k];directions[k]=v;}
            boolean walked=false;
            for(int d:directions){int nx=at.x+DX[d],ny=at.y+DY[d];
                if(valid(nx,ny) && !seen[nx][ny]) {
                    paths[at.x][at.y]|=1<<d;
                    paths[nx][ny]|=1<<OPP[d];
                    seen[nx][ny]=true;stack.push(new Cell(nx,ny));walked=true;break;
                }
            }
            if(!walked)stack.pop();
        }
        // Starting in a leaf guarantees a three-sided safe chamber with only one exit.
        Cell origin=null;
        float bestStart=Float.NEGATIVE_INFINITY;
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)if(occupied[i][j]&&Integer.bitCount(paths[i][j])==1){
            float s=(j/(float)rows)*3-i/(float)cols;
            if(s>bestStart){bestStart=s;origin=new Cell(i,j);}
        }
        if(origin==null)origin=initial;
        Cell end=farthest(origin);
        startX=centerX(origin.x);startZ=centerZ(origin.y);
        goalX=centerX(end.x);goalZ=centerZ(end.y);
        List<Obstacle> generated=new ArrayList<>();
        final float t=.064f;
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)if(occupied[i][j]){
            float cx=centerX(i),cz=centerZ(j),edge=cellSize*.5f;
            // Interior walls: draw only east and south; boundary walls also west and north.
            for(int d=0;d<4;d++) {
                if(d==2&&valid(i-1,j))continue;
                if(d==3&&valid(i,j-1))continue;
                if((paths[i][j]&(1<<d))!=0)continue;
                if(d==0)generated.add(new Obstacle(cx+edge,cz,t,edge+t));
                if(d==2)generated.add(new Obstacle(cx-edge,cz,t,edge+t));
                if(d==1)generated.add(new Obstacle(cx,cz+edge,edge+t,t));
                if(d==3)generated.add(new Obstacle(cx,cz-edge,edge+t,t));
            }
        }
        // Animated, dodgeable test barriers appear gradually, never inside the launch or goal cell.
        if(level>=20 && level%10==0) {
            Cell obstacleCell=farthest(end);
            Cell mid=midPath(origin,end);
            if(mid!=null && !(mid.x==origin.x&&mid.y==origin.y) && !(mid.x==end.x&&mid.y==end.y))
                generated.add(new Obstacle(centerX(mid.x),centerZ(mid.y),.10f,.115f,
                    cellSize*.22f,1.0f+level*.008f,.35f));
        }
        // Low-gradient ramps, with real projected downhill acceleration and corresponding visual tilt.
        if(level>=46){
            for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)if(occupied[i][j] && ((i*7+j*11+level)%13==0))
                rampDirections[i][j]=((i+j+level)&1)==0?1:-1;
        }
        obstacles=Collections.unmodifiableList(generated);
        resetAll();
    }
    public String shapeName(){return SHAPES[shapeType];}
    public boolean isCell(int i,int j){return valid(i,j);}
    public int openingBits(int i,int j){return paths[i][j];}
    public int rampDirection(int i,int j){return rampDirections[i][j];}
    public float centerX(int i){return (i+.5f-cols*.5f)*cellSize;}
    public float centerZ(int j){return (j+.5f-rows*.5f)*cellSize;}
    public float getHeightAt(float px,float pz){
        int i=cellCol(px),j=cellRow(pz);
        if(!valid(i,j))return 0;
        return rampDirections[i][j]*(pz-centerZ(j))*.115f;
    }
    public int cellCol(float px){return (int)Math.floor(px/cellSize+cols*.5f);}
    public int cellRow(float pz){return (int)Math.floor(pz/cellSize+rows*.5f);}
    private boolean valid(int i,int j){return i>=0&&j>=0&&i<cols&&j<rows&&occupied[i][j];}
    private boolean inShape(float x,float z,int type,float var){
        float ax=Math.abs(x),az=Math.abs(z),r=(float)Math.hypot(x,z);
        float a=(float)Math.atan2(z,x);
        switch(type){
            case 0: return r<=.99f+var;
            case 1: return ax+az<=1.38f+var;
            case 2: return ax<=.93f && az+.45f*ax<=1.16f+var;
            case 3: return Math.max(ax,az)+.35f*Math.min(ax,az)<=1.26f+var;
            case 4: return ax<=.98f&&az<=.98f&&(ax*ax*ax*ax+az*az*az*az)<=1.68f+var;
            case 5: return r<=.80f+.21f*(float)Math.cos(4*a)+var;
            case 6: return r<=.81f+.22f*(float)Math.cos(5*a)+var;
            case 7: return ax<=.72f+.24f*z && az<=.98f;
            case 8: return (x*x)/(.88f*.88f)+(z*z)/(1.08f*1.08f)<=1.1f+var;
            default: return r<=.84f+.17f*(float)Math.sin(a)+.06f*(float)Math.cos(3*a)+var;
        }
    }
    private void retainLargestComponent(){
        boolean[][] seen=new boolean[cols][rows];List<Cell> best=new ArrayList<>();
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)if(occupied[i][j]&&!seen[i][j]){
            List<Cell> component=new ArrayList<>();ArrayDeque<Cell> q=new ArrayDeque<>();
            q.add(new Cell(i,j));seen[i][j]=true;
            while(!q.isEmpty()){Cell c=q.removeFirst();component.add(c);
                for(int d=0;d<4;d++){int xx=c.x+DX[d],yy=c.y+DY[d];
                    if(xx>=0&&yy>=0&&xx<cols&&yy<rows&&occupied[xx][yy]&&!seen[xx][yy]){
                        seen[xx][yy]=true;q.add(new Cell(xx,yy));
                    }
                }
            }
            if(component.size()>best.size())best=component;
        }
        for(int i=0;i<cols;i++)for(int j=0;j<rows;j++)occupied[i][j]=false;
        for(Cell c:best)occupied[c.x][c.y]=true;
    }
    private Cell farthest(Cell start){
        ArrayDeque<Cell> q=new ArrayDeque<>();boolean[][] seen=new boolean[cols][rows];
        q.add(start);seen[start.x][start.y]=true;Cell end=start;
        while(!q.isEmpty()){Cell c=q.removeFirst();end=c;
            for(int d=0;d<4;d++)if((paths[c.x][c.y]&(1<<d))!=0){int x=c.x+DX[d],y=c.y+DY[d];
                if(!seen[x][y]){seen[x][y]=true;q.add(new Cell(x,y));}
            }
        }
        return end;
    }
    private Cell midPath(Cell from,Cell goal){
        ArrayDeque<Cell> q=new ArrayDeque<>();Cell[][] parent=new Cell[cols][rows];
        boolean[][] seen=new boolean[cols][rows];q.add(from);seen[from.x][from.y]=true;
        while(!q.isEmpty()){Cell c=q.removeFirst();if(c.x==goal.x&&c.y==goal.y)break;
            for(int d=0;d<4;d++)if((paths[c.x][c.y]&(1<<d))!=0){int x=c.x+DX[d],y=c.y+DY[d];
                if(!seen[x][y]){seen[x][y]=true;parent[x][y]=c;q.add(new Cell(x,y));}
            }
        }
        List<Cell> route=new ArrayList<>();Cell c=goal;
        while(c!=null){route.add(c);c=parent[c.x][c.y];}
        return route.size()>3?route.get(route.size()/2):null;
    }
    public void resetAll(){crashes=0;animationTime=0;resetRun();}
    public void resetRun(){x=startX;z=startZ;vx=vz=seconds=0;finished=justCrashed=false;}
    public void flick(float dx,float dz){
        float magnitude=(float)Math.hypot(dx,dz);
        if(magnitude>0){float scale=1.8f;vx+=dx/magnitude*scale;vz+=dz/magnitude*scale;}
    }
    public void step(float dt,float dx,float dz){
        if(finished || dt<=0)return;
        dt=Math.min(dt,1f/30f);
        float prior=animationTime;animationTime+=dt;seconds+=dt;
        float m=(float)Math.hypot(dx,dz);if(m>1){dx/=m;dz/=m;}
        int col=cellCol(x),row=cellRow(z);
        float ramp=valid(col,row)?rampDirections[col][row]*.80f:0;
        vx+=(dx*ACCEL)*dt;
        vz+=(dz*ACCEL-ramp)*dt;
        float f=(float)Math.exp(-FRICTION*dt);vx*=f;vz*=f;
        float speed=(float)Math.hypot(vx,vz);
        if(speed>MAX_SPEED){vx*=MAX_SPEED/speed;vz*=MAX_SPEED/speed;}
        float oldX=x,oldZ=z;
        int checks=Math.max(1,(int)Math.ceil(Math.hypot(vx*dt,vz*dt)/.030f));
        for(int k=1;k<=checks;k++){
            float fraction=k/(float)checks;
            x=oldX+vx*dt*fraction;z=oldZ+vz*dt*fraction;
            if(hitsAnything(prior+dt*fraction)){
                crashes++;resetRun();justCrashed=true;return;
            }
        }
        if(Math.hypot(x-goalX,z-goalZ)<.28f){finished=true;vx=vz=0;}
    }
    public boolean hitsAnything(float clock){
        int cx=cellCol(x),cz=cellRow(z);
        if(!valid(cx,cz))return true;
        for(Obstacle o:obstacles)if(touches(o,clock))return true;
        return false;
    }
    public boolean touches(Obstacle o,float clock){
        float bx=o.atX(clock);
        float nearestX=Math.max(bx-o.halfX,Math.min(x,bx+o.halfX));
        float nearestZ=Math.max(o.z-o.halfZ,Math.min(z,o.z+o.halfZ));
        float dx=x-nearestX,dz=z-nearestZ;
        return dx*dx+dz*dz<=BALL_RADIUS*BALL_RADIUS;
    }
}
