package com.atelier.marble;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Renderer-independent deterministic-ish fixed-step 2D marble dynamics. Coordinates X,Z. */
public final class MarblePhysics {
    public static final float BALL_RADIUS = 0.31f;
    public static final float HALF_WIDTH = 3.40f;
    public static final float HALF_LENGTH = 4.18f;
    private static final float ACCELERATION = 10.5f;
    private static final float DAMPING = 1.8f;
    private static final float SPEED_CAP = 4.9f;
    public final int level;
    public final List<Obstacle> obstacles;
    public final float goalX, goalZ;
    public float x, z, vx, vz, seconds;
    public boolean finished;

    public static final class Obstacle {
        public final float x, z, halfX, halfZ;
        public Obstacle(float x, float z, float halfX, float halfZ) {
            this.x = x; this.z = z; this.halfX = halfX; this.halfZ = halfZ;
        }
    }

    public MarblePhysics(int level) {
        if (level != 1 && level != 2) throw new IllegalArgumentException("Unknown level " + level);
        this.level = level;
        List<Obstacle> a = new ArrayList<>();
        if (level == 1) {
            goalX = 2.18f; goalZ = -3.34f;
            a.add(new Obstacle(-1.08f, 1.53f, 0.34f, 0.82f));
            a.add(new Obstacle(1.24f, -0.42f, 0.91f, 0.31f));
            a.add(new Obstacle(-1.20f, -2.14f, 0.43f, 0.80f));
        } else {
            goalX = -2.12f; goalZ = -3.28f;
            a.add(new Obstacle(0.68f, 2.05f, 1.06f, 0.25f));
            a.add(new Obstacle(-1.32f, 0.70f, 0.36f, 0.95f));
            a.add(new Obstacle(1.20f, -0.98f, 0.40f, 0.93f));
            a.add(new Obstacle(-0.66f, -2.40f, 0.79f, 0.28f));
            a.add(new Obstacle(1.57f, -3.15f, 0.23f, 0.55f));
        }
        obstacles = Collections.unmodifiableList(a);
        reset();
    }

    public void reset() {
        x = level == 1 ? -2.20f : 2.28f;
        z = 3.36f;
        vx = vz = seconds = 0;
        finished = false;
    }

    public void step(float dt, float directionX, float directionZ) {
        if (finished || !(dt > 0f)) return;
        // Fixed time step from the Activity; clamp to prevent giant leaps after pause.
        dt = Math.min(dt, 1f/30f);
        seconds += dt;
        float length = (float) Math.hypot(directionX, directionZ);
        if (length > 1f) { directionX /= length; directionZ /= length; }
        vx += directionX * ACCELERATION * dt;
        vz += directionZ * ACCELERATION * dt;
        float drag = (float) Math.exp(-DAMPING * dt);
        vx *= drag; vz *= drag;
        float speed = (float) Math.hypot(vx, vz);
        if (speed > SPEED_CAP) { vx *= SPEED_CAP/speed; vz *= SPEED_CAP/speed; }

        // Solve each axis separately to keep reliable sliding along rectangular obstacles.
        x += vx * dt;
        if (x < -HALF_WIDTH + BALL_RADIUS) { x = -HALF_WIDTH + BALL_RADIUS; vx = Math.abs(vx) * 0.25f; }
        if (x > HALF_WIDTH - BALL_RADIUS) { x = HALF_WIDTH - BALL_RADIUS; vx = -Math.abs(vx) * 0.25f; }
        for (Obstacle o : obstacles) {
            if (overlap(o)) {
                if (vx > 0) x = o.x - o.halfX - BALL_RADIUS;
                else if (vx < 0) x = o.x + o.halfX + BALL_RADIUS;
                else x += x < o.x ? -0.02f : 0.02f;
                vx *= -0.18f;
            }
        }
        z += vz * dt;
        if (z < -HALF_LENGTH + BALL_RADIUS) { z = -HALF_LENGTH + BALL_RADIUS; vz = Math.abs(vz) * 0.25f; }
        if (z > HALF_LENGTH - BALL_RADIUS) { z = HALF_LENGTH - BALL_RADIUS; vz = -Math.abs(vz) * 0.25f; }
        for (Obstacle o : obstacles) {
            if (overlap(o)) {
                if (vz > 0) z = o.z - o.halfZ - BALL_RADIUS;
                else if (vz < 0) z = o.z + o.halfZ + BALL_RADIUS;
                else z += z < o.z ? -0.02f : 0.02f;
                vz *= -0.18f;
            }
        }
        // Goal is a generously sized recessed target; no invisible requirement.
        if (Math.hypot(x-goalX, z-goalZ) < 0.43f) {
            finished = true;
            vx = vz = 0;
        }
    }

    private boolean overlap(Obstacle o) {
        float nearestX = Math.max(o.x-o.halfX, Math.min(x, o.x+o.halfX));
        float nearestZ = Math.max(o.z-o.halfZ, Math.min(z, o.z+o.halfZ));
        float dx = x-nearestX, dz = z-nearestZ;
        return dx*dx + dz*dz < BALL_RADIUS*BALL_RADIUS;
    }
}
