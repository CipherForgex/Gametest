import com.atelier.marble.MarblePhysics;
import java.util.ArrayDeque;

public class SmokeCheck {
    private static void require(boolean b, String message) { if (!b) throw new AssertionError(message); }
    private static boolean reachable(MarblePhysics m) {
        float step = .16f;
        int cols=(int)(2*MarblePhysics.HALF_WIDTH/step)+1;
        int rows=(int)(2*MarblePhysics.HALF_LENGTH/step)+1;
        boolean[][] blocked=new boolean[cols][rows];
        for(int x=0;x<cols;x++) for(int z=0;z<rows;z++) {
            float px=-MarblePhysics.HALF_WIDTH+x*step;
            float pz=-MarblePhysics.HALF_LENGTH+z*step;
            blocked[x][z]=Math.abs(px)>MarblePhysics.HALF_WIDTH-MarblePhysics.BALL_RADIUS
                || Math.abs(pz)>MarblePhysics.HALF_LENGTH-MarblePhysics.BALL_RADIUS;
            for(MarblePhysics.Obstacle o:m.obstacles) {
                float dx=Math.max(0,Math.abs(px-o.x)-o.halfX);
                float dz=Math.max(0,Math.abs(pz-o.z)-o.halfZ);
                if(dx*dx+dz*dz <= MarblePhysics.BALL_RADIUS*MarblePhysics.BALL_RADIUS) blocked[x][z]=true;
            }
        }
        int sx=Math.round((m.x+MarblePhysics.HALF_WIDTH)/step);
        int sz=Math.round((m.z+MarblePhysics.HALF_LENGTH)/step);
        ArrayDeque<int[]> queue=new ArrayDeque<>();
        boolean[][] seen=new boolean[cols][rows];
        queue.add(new int[]{sx,sz});seen[sx][sz]=true;
        int[][] dirs={{0,1},{0,-1},{1,0},{-1,0}};
        while(!queue.isEmpty()) {
            int[] a=queue.removeFirst();
            float px=-MarblePhysics.HALF_WIDTH+a[0]*step;
            float pz=-MarblePhysics.HALF_LENGTH+a[1]*step;
            if(Math.hypot(px-m.goalX,pz-m.goalZ)<.38f)return true;
            for(int[] d:dirs){int nx=a[0]+d[0],nz=a[1]+d[1];
                if(nx>=0 && nz>=0 && nx<cols && nz<rows && !blocked[nx][nz] && !seen[nx][nz]) {
                    seen[nx][nz]=true;queue.addLast(new int[]{nx,nz});
                }
            }
        }
        return false;
    }
    public static void main(String[] args) {
        for (int level=1; level<=2; level++) {
            MarblePhysics m = new MarblePhysics(level);
            require(!m.finished && m.obstacles.size() >= 3, "initial level");
            require(m.x >= -MarblePhysics.HALF_WIDTH && m.z < MarblePhysics.HALF_LENGTH, "spawn");
            float startX=m.x, startZ=m.z;
            for (int i=0; i<100; i++) m.step(1f/60f, 0.5f, -0.7f);
            require(m.seconds > 1.6f, "timer");
            require(startX != m.x || startZ != m.z, "ball moves");
            for (int i=0; i<5000; i++) {
                m.step(1f/60f, (float)Math.sin(i*0.09), (float)Math.cos(i*0.02));
                require(m.x >= -MarblePhysics.HALF_WIDTH + MarblePhysics.BALL_RADIUS - .0001f, "left wall");
                require(m.x <= MarblePhysics.HALF_WIDTH - MarblePhysics.BALL_RADIUS + .0001f, "right wall");
                require(m.z >= -MarblePhysics.HALF_LENGTH + MarblePhysics.BALL_RADIUS - .0001f, "bottom wall");
                require(m.z <= MarblePhysics.HALF_LENGTH - MarblePhysics.BALL_RADIUS + .0001f, "top wall");
                require(Float.isFinite(m.x) && Float.isFinite(m.vx), "finite physics");
            }
            require(reachable(m), "level has navigable path around obstacles");
            m.reset();
            require(m.seconds == 0f && !m.finished && m.vx == 0f, "reset");
            m.x = m.goalX; m.z = m.goalZ;
            m.step(1f/60f, 0, 0);
            require(m.finished, "goal completion");
            float stopped = m.seconds;
            m.step(1f/60f, 1, 1);
            require(m.seconds == stopped, "no time after finish");
            System.out.println("PASS level " + level + ": input, collisions, bounds, timer, goal, reset");
        }
        boolean caught = false;
        try { new MarblePhysics(99); } catch(IllegalArgumentException ok) { caught=true; }
        require(caught, "invalid level rejected");
        System.out.println("PASS all deterministic smoke checks");
    }
}
