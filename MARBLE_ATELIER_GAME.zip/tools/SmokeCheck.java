import com.atelier.marble.MarblePhysics;
import java.util.ArrayDeque;

/** Headless pure-Java collision, goal and reachability regression tests for CI. */
public final class SmokeCheck {
    private static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);}
    private static boolean passable(MarblePhysics p,int ix,int iz) {
        float x=-MarblePhysics.HALF_WIDTH+ix*.08f,z=-MarblePhysics.HALF_LENGTH+iz*.08f;
        if(x-MarblePhysics.BALL_RADIUS <= -MarblePhysics.HALF_WIDTH || x+MarblePhysics.BALL_RADIUS >= MarblePhysics.HALF_WIDTH || z-MarblePhysics.BALL_RADIUS <= -MarblePhysics.HALF_LENGTH || z+MarblePhysics.BALL_RADIUS >= MarblePhysics.HALF_LENGTH)return false;
        // Ignore the level-5 moving obstacle when testing static topology; dynamic tests cover it separately.
        for(MarblePhysics.Obstacle o:p.obstacles){if(o.moving)continue;
            float nx=Math.max(o.x-o.halfX,Math.min(x,o.x+o.halfX));
            float nz=Math.max(o.z-o.halfZ,Math.min(z,o.z+o.halfZ));
            float dx=x-nx,dz=z-nz;
            if(dx*dx+dz*dz<=MarblePhysics.BALL_RADIUS*MarblePhysics.BALL_RADIUS)return false;
        }
        return true;
    }
    private static boolean reachable(MarblePhysics p) {
        int nx=(int)Math.ceil(MarblePhysics.HALF_WIDTH*2/.08f)+1;
        int nz=(int)Math.ceil(MarblePhysics.HALF_LENGTH*2/.08f)+1;
        boolean[][] seen=new boolean[nx][nz];
        ArrayDeque<int[]> q=new ArrayDeque<>();
        int sx=Math.round((p.x+MarblePhysics.HALF_WIDTH)/.08f),sz=Math.round((p.z+MarblePhysics.HALF_LENGTH)/.08f);
        q.add(new int[]{sx,sz});seen[sx][sz]=true;
        int[][] neighbours={{0,1},{0,-1},{1,0},{-1,0}};
        while(!q.isEmpty()) {
            int[] here=q.removeFirst();
            float x=-MarblePhysics.HALF_WIDTH+here[0]*.08f,z=-MarblePhysics.HALF_LENGTH+here[1]*.08f;
            if(Math.hypot(x-p.goalX,z-p.goalZ)<.25f)return true;
            for(int[] d:neighbours){int xx=here[0]+d[0],zz=here[1]+d[1];
                if(xx>=0 && zz>=0 && xx<nx && zz<nz && !seen[xx][zz] && passable(p,xx,zz)){
                    seen[xx][zz]=true;q.addLast(new int[]{xx,zz});
                }
            }
        }
        return false;
    }
    public static void main(String[] args) {
        check(MarblePhysics.LEVEL_COUNT==5,"5 levels");
        int total=0;
        for(int n=1;n<=MarblePhysics.LEVEL_COUNT;n++){
            MarblePhysics p=new MarblePhysics(n);
            check(!p.hitsAnything(0),"spawn free "+n);
            check(reachable(p),"static maze has full continuous route "+n);
            check(n!=5 || p.obstacles.stream().anyMatch(o->o.moving),"level 5 moving wall");
            check(n==5 || p.obstacles.stream().noneMatch(o->o.moving),"other levels static");
            // High-speed approach to first wall from its unobstructed side must fail rather than tunnel through.
            MarblePhysics.Obstacle target=p.obstacles.get(1);
            p.x=target.x; p.z=target.z+target.halfZ+MarblePhysics.BALL_RADIUS+.07f;
            // If horizontal wall centre is outside accessible play area, clamp X to a safe point.
            p.x=Math.min(3.1f,Math.max(-3.1f,p.x));
            p.vz=-3.25f;
            for(int j=0;j<20 && p.crashes==0;j++)p.step(1f/60f,0,-1);
            check(p.crashes==1,"wall must trigger one fatal reset "+n);
            check(Math.abs(p.x-MarblePhysics.START_X)<.0001f && p.seconds<.05f,"immediate reset "+n);
            check(p.justCrashed,"collision feedback "+n);
            p.resetAll();
            check(p.crashes==0,"manual restart zeroes attempts "+n);
            p.x=p.goalX;p.z=p.goalZ;p.step(1f/60f,0,0);
            check(p.finished,"goal detected "+n);
            float time=p.seconds;p.step(1f/60f,1,0);
            check(p.seconds==time,"finished timer frozen "+n);
            total++;
            System.out.println("PASS LEVEL "+n+": reachable, precise fatal collisions, resets, goal");
        }
        MarblePhysics m=new MarblePhysics(5);
        MarblePhysics.Obstacle moving=m.obstacles.stream().filter(o->o.moving).findFirst().orElseThrow();
        check(Math.abs(moving.atX(0)-moving.atX(1))>.2f,"moving wall actually moves");
        m.x=moving.atX(0);m.z=moving.z;m.vx=m.vz=0;
        m.step(1f/60f,0,0);
        check(m.justCrashed,"moving wall collision resets player");
        System.out.println("PASS moving collision and animation timeline; levels="+total);
    }
}
