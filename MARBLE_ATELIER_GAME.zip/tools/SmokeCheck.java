import com.atelier.marble.MarblePhysics;
import com.atelier.marble.ControlMath;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
public class SmokeCheck {
  static void yes(boolean b,String msg){if(!b)throw new AssertionError(msg);}
  static int reachable(MarblePhysics m){
    int[][] dirs={{1,0},{0,1},{-1,0},{0,-1}};
    int sx=m.cellCol(m.startX),sy=m.cellRow(m.startZ);
    boolean[][] seen=new boolean[m.cols][m.rows];seen[sx][sy]=true;
    ArrayDeque<int[]> q=new ArrayDeque<>();q.add(new int[]{sx,sy});int n=0;
    while(!q.isEmpty()){int[] c=q.removeFirst();n++;
      for(int d=0;d<4;d++)if((m.openingBits(c[0],c[1])&(1<<d))!=0){
        int x=c[0]+dirs[d][0],y=c[1]+dirs[d][1];
        yes(m.isCell(x,y),"passage outside shape");
        yes((m.openingBits(x,y)&(1<<((d+2)%4)))!=0,"passage nonreciprocal");
        if(!seen[x][y]){seen[x][y]=true;q.add(new int[]{x,y});}
      }
    }
    yes(seen[m.cellCol(m.goalX)][m.cellRow(m.goalZ)],"goal unreachable");
    int total=0;for(int x=0;x<m.cols;x++)for(int y=0;y<m.rows;y++)if(m.isCell(x,y))total++;
    yes(n==total,"all cells connected, "+n+"/"+total);
    return n;
  }
  static String sig(MarblePhysics m){
    StringBuilder b=new StringBuilder();b.append(m.cols).append(m.rows).append(m.shapeName());
    for(int y=0;y<m.rows;y++)for(int x=0;x<m.cols;x++)b.append(m.isCell(x,y)?m.openingBits(x,y):'x').append(',');
    return b.toString();
  }
  public static void main(String[] args){
    yes(MarblePhysics.LEVEL_COUNT==100,"one hundred fixed levels");
    for(int i=-12;i<=12;i++){
      float yaw=(float)(i*Math.PI/6);
      float x=ControlMath.worldX(.7f,-.3f,yaw),z=ControlMath.worldZ(.7f,-.3f,yaw);
      yes(Math.abs(Math.hypot(x,z)-Math.hypot(.7,-.3))<1e-5,"camera-relative controls preserve speed at angle "+i);
      yes(Math.abs(ControlMath.worldX(.7f,-.3f,yaw+(float)(2*Math.PI))-x)<1e-5,"camera complete orbit");
    }
    yes(Math.abs(ControlMath.worldX(0,1,(float)(Math.PI/2))-1)<1e-5,"camera 90 degree steering");
    Set<String> signatures=new HashSet<>();int moving=0,ramps=0,cells=0;
    for(int i=1;i<=100;i++){
      MarblePhysics p=new MarblePhysics(i);yes(!p.hitsAnything(0),"safe spawn "+i);
      yes(Integer.bitCount(p.openingBits(p.cellCol(p.startX),p.cellRow(p.startZ)))==1,"safe chamber has one exit "+i);
      cells+=reachable(p);yes(signatures.add(sig(p)),"unique layout "+i);
      for(MarblePhysics.Obstacle o:p.obstacles){if(o.moving){moving++;
          p.x=o.atX(0);p.z=o.z;p.step(1f/60f,0,0);yes(p.justCrashed,"moving hazard hit resets "+i);p.resetAll();
      }}
      for(int x=0;x<p.cols;x++)for(int z=0;z<p.rows;z++)if(p.rampDirection(x,z)!=0)ramps++;
      MarblePhysics.Obstacle wall=p.obstacles.get(0);
      p.x=wall.x;p.z=wall.z;p.step(1f/60f,0,0);
      yes(p.justCrashed,"wall collision triggers instant reset "+i);
      yes(p.crashes==1&&Math.abs(p.x-p.startX)<.001&&p.seconds<.01f,"reset timer and position "+i);
      p.resetAll();p.x=p.goalX;p.z=p.goalZ;p.step(1f/60f,0,0);
      yes(p.finished,"finish registers "+i);
      float frozen=p.seconds;p.step(1f/60f,1,1);yes(p.seconds==frozen,"frozen timer "+i);
      if(i%20==0)System.out.println("PASS " + i + "/100 unique connected mazes");
    }
    yes(moving>=5,"moving hazards present");yes(ramps>=5,"gradient ramps present");
    System.out.printf("PASS: 100 distinct connected layouts, %d cells, %d moving hazards, %d ramp tiles; all reset, timer, wall and goal tests%n",cells,moving,ramps);
  }
}
