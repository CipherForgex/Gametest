#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
javac -d "$tmp" app/src/main/java/com/atelier/marble/MarblePhysics.java tools/SmokeCheck.java
java -cp "$tmp" SmokeCheck
