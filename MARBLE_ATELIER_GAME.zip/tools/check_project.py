#!/usr/bin/env python3
"""Marble Atelier V0.4.1 static, asset and build-preflight regression checks.

These checks do NOT substitute for Android compilation or hardware rendering.
"""
from pathlib import Path
import re
import wave
import struct
import zlib

p = Path(__file__).resolve().parents[1]
java = p / 'app/src/main/java/com/atelier/marble'
required = [
    'settings.gradle', 'build.gradle', 'gradle.properties', 'app/build.gradle',
    'app/src/main/AndroidManifest.xml', 'tools/SmokeCheck.java',
    'tools/test_physics.sh', 'README.md', 'LICENSING_AND_ASSETS.md',
    'app/src/main/res/drawable/app_icon.png',
] + [str((java / f).relative_to(p)) for f in (
    'MarblePhysics.java', 'LevelBlueprints.java', 'ControlMath.java',
    'FilamentBoard.java', 'MainActivity.java', 'VisualStyles.java')]
for name in required:
    file = p / name
    assert file.is_file() and file.stat().st_size > 10, 'Missing/empty ' + name

read = lambda f: (java / f).read_text(encoding='utf-8')
physics = read('MarblePhysics.java')
blueprints = read('LevelBlueprints.java')
render = read('FilamentBoard.java')
ui = read('MainActivity.java')
style = read('VisualStyles.java')
contract = {
    'Exactly ten fixed levels': 'LEVEL_COUNT = LevelBlueprints.COUNT' in physics
        and 'COUNT = 10' in blueprints and 'new Blueprint(' in blueprints,
    'No runtime 100-level generation': 'LEVEL_COUNT = 100' not in physics and
        'generateMaze' not in physics and 'generateLevel' not in blueprints,
    'Shared physics/render geometry': 'for(MarblePhysics.Obstacle o:game.obstacles)' in render
        and 'public boolean touches(Obstacle o,float time)' in physics,
    'No walls fade or disappear': 'public void setVisibilityAssist(boolean ignored)' in render
        and 'walls.remove(' not in render and 'entities.remove(' not in render,
    'Animated camera, not snap': 'targetYaw+=' in render and
        'yaw+=delta*a' in render and 'targetYaw=0' in render,
    'Overhead movement lockout': 'physics.inspect(1f/60f)' in ui
        and 'public void inspect(float dt)' in physics and 'vx=vz=0;' in physics,
    'Precision drag and velocity flick': 'physics.flick(' in ui and
        'int segments=Math.max(1,' in physics and 'capVelocity();' in physics,
    'Camera controls': all(x in ui for x in ('board.rotateCamera(90)',
        'board.toggleOverview()', 'board.resetCamera()', 'board.changeZoom(',
        'board.getYaw()')),
    'Menu pages': all(x in ui for x in ('showMenu()', 'showLevels()',
        'showBestTimes()', 'showStudio()', 'showThemes()', 'showMarbles()',
        'showSettings()', 'showPause()', 'showWin()')),
    'Progress and records': 'v04_best_' in ui and 'v04_progress' in ui,
    'Textured Filament shader': 'AtelierTexturedPBR' in render
        and 'normalRoughMap' in render and 'albedoMap' in render,
    'Normal map before prepareMaterial': render.find('material.normal=normalize')
        < render.find('"  prepareMaterial(material);\\n"+', render.find('String texturedShader')),
    'Six material worlds': re.search(r'TEXTURE_KEYS\s*=\s*\{[^}]+\}', style) is not None,
    'Eight marble skins': 'BALL_TEXTURE_KEYS' in style and 'NEBULA' in style,
    'No internet permission': '<uses-permission android:name="android.permission.INTERNET"' not in
        (p/'app/src/main/AndroidManifest.xml').read_text(),
}
for label, ok in contract.items():
    assert ok, 'FAILED CONTRACT: ' + label
    print('PASS', label)

gradle = (p / 'app/build.gradle').read_text()
assert re.search(r'compileSdk\s+36', gradle)
assert re.search(r'targetSdk\s+36', gradle)
assert "versionName '0.4.1'" in gradle and 'versionCode 6' in gradle
assert 'filament-android:1.75.1' in gradle and 'filamat-android:1.75.1' in gradle
# Catch the precise crash from the V0.4 Samsung playtest: Java runs instance field
# initializers before FilamentBoard's constructor calls Filament.init().
from subprocess import run
startup_check = run(['python3', str(p/'tools/test_filament_startup.py')], capture_output=True, text=True)
assert startup_check.returncode == 0, startup_check.stdout + startup_check.stderr
print(startup_check.stdout.strip())
assert "noCompress += ['wav']" in gradle, 'SoundPool sound files must remain uncompressed'
assert (p/'app/src/main/assets/APACHE_2_0_LICENSE.txt').stat().st_size > 1000
assert (p/'app/src/main/assets/THIRD_PARTY_NOTICES.txt').is_file()

assets = p / 'app/src/main/assets'
themes = ('obsidian','industrial','ivory','frost','ember','celestial')
balls = ('chrome','glacier','gold','obsidian','pearl','copper','neon','nebula')
images = []
for theme in themes:
    for part in ('floor', 'wall'):
        for layer in ('albedo', 'normalrough'):
            images.append(assets / f'materials/{theme}_{part}_{layer}.png')
for ball in balls:
    for layer in ('albedo','normalrough'):
        images.append(assets / f'materials/balls/{ball}_{layer}.png')
for path in images:
    assert path.is_file(), f'Missing material: {path}'
    data=path.read_bytes()
    assert data.startswith(b'\x89PNG\r\n\x1a\n'), f'Invalid PNG signature: {path}'
    offset=8; seen_header=False; seen_data=False; seen_end=False
    while offset+12<=len(data):
        length=struct.unpack_from('>I',data,offset)[0]
        kind=data[offset+4:offset+8]
        stop=offset+12+length
        assert stop<=len(data), f'Truncated PNG: {path}'
        payload=data[offset+8:offset+8+length]
        stored_crc=struct.unpack_from('>I',data,offset+8+length)[0]
        assert zlib.crc32(kind+payload)&0xffffffff==stored_crc, f'Corrupt PNG chunk: {path}'
        if kind==b'IHDR':
            width,height,depth,color_type=struct.unpack_from('>IIBB',payload,0)
            assert width>=64 and height>=64 and depth==8 and color_type in (2,6), f'Unsupported texture: {path}'
            seen_header=True
        elif kind==b'IDAT': seen_data=True
        elif kind==b'IEND': seen_end=True;break
        offset=stop
    assert seen_header and seen_data and seen_end, f'Incomplete PNG file: {path}'
for sound in ('tap','impact','complete'):
    path = assets / f'sfx/{sound}.wav'
    assert path.is_file()
    with wave.open(str(path)) as wf:
        assert wf.getnframes() > 100 and wf.getnchannels() in (1,2)
print(f'PASS {len(images)} valid theme and ball PNG texture maps, three valid WAV cues')
print('PASS SDK, dependency, manifest and licensing checks')
print('PASS V0.4 preflight (Android compilation/device rendering must still be run)')
