#!/usr/bin/env python3
"""Offline package preflight. Does not substitute for compilation/device testing."""
from pathlib import Path
import re, sys
base = Path(__file__).resolve().parent.parent
files = [
 'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
 'app/src/main/AndroidManifest.xml',
 'app/src/main/java/com/atelier/marble/MainActivity.java',
 'app/src/main/java/com/atelier/marble/FilamentBoard.java',
 'app/src/main/java/com/atelier/marble/MarblePhysics.java',
 'tools/test_physics.sh',
]
for f in files:
    p = base / f
    assert p.is_file() and p.stat().st_size>10, f'Absent or empty: {f}'
    print('FOUND',f)
r=(base/files[6]).read_text()
s=(base/files[7]).read_text()
a=(base/files[5]).read_text()
assert 'MaterialBuilder' in r and 'Engine.Backend.OPENGL' in r
assert 'setLevel(1)' in r and 'setLevel(2)' not in r  # menu selects via activity
assert 'new MarblePhysics(level)' in r and 'onGameTouch' in a
assert 'private void showMenu()' in a and 'private void showWin()' in a
assert 'new MarblePhysics(1)' not in s and 'level != 1 && level != 2' in s
gradle=(base/'app/build.gradle').read_text()
assert 'abiFilters' in gradle
# Regression guard for CI failure on 2026-10-10: Filament 1.77.1 required SDK 37.
# This project's AGP 8.13.2 and GitHub workflow intentionally use compileSdk 36.
assert re.search(r'\bcompileSdk\s+36\b', gradle), 'Expected compileSdk 36'
assert re.search(r'\btargetSdk\s+36\b', gradle), 'Expected targetSdk 36'
for artifact in ('filament-android', 'filamat-android'):
    assert f'com.google.android.filament:{artifact}:1.75.1' in gradle, \
        f'Incompatible or missing {artifact} pinned release'
assert ':1.77.1' not in gradle, 'SDK 37 Filament 1.77.1 would fail this build'
print('PASS manifest / source / main menu / level selection / Filament 1.75.1 pin and Android SDK 36 preflight')
