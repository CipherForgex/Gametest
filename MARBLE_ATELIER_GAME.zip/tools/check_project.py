#!/usr/bin/env python3
"""Structural and licence preflight; not an Android build substitute."""
from pathlib import Path
import re
p=Path(__file__).resolve().parent.parent
required=[
'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
'app/src/main/AndroidManifest.xml','app/src/main/java/com/atelier/marble/MainActivity.java',
'app/src/main/java/com/atelier/marble/FilamentBoard.java',
'app/src/main/java/com/atelier/marble/MarblePhysics.java',
'app/src/main/res/drawable/app_icon.png','tools/SmokeCheck.java','tools/test_physics.sh',
'LICENSING_AND_ASSETS.md',
]
for rel in required:
    f=p/rel
    assert f.exists() and f.stat().st_size>10,rel
    print('FOUND',rel)
physics=(p/required[7]).read_text()
ui=(p/required[5]).read_text()
visual=(p/required[6]).read_text()
gradle=(p/'app/build.gradle').read_text()
assert 'LEVEL_COUNT = 5' in physics and 'case 4:' in physics and 'case 3:' in physics
assert 'moving' in physics and 'justCrashed' in physics and 'hitsAnything' in physics
assert 'resetRun()' in physics and 'travel/.045f' in physics
assert 'best_ms_' in ui and 'showBestTimes' in ui and 'startLevel(index)' in ui
assert 'level<MarblePhysics.LEVEL_COUNT' in ui and 'physics.justCrashed' in ui
assert 'updateMovingWalls' in visual and 'o.moving' in visual
assert 'setAmbientOcclusionOptions' in visual and 'setBloomOptions' in visual
assert re.search(r'compileSdk\s+36',gradle) and re.search(r'targetSdk\s+36',gradle)
assert 'filament-android:1.75.1' in gradle and 'filamat-android:1.75.1' in gradle
assert 'versionName \'0.2.0\'' in gradle
assert 'INTERNET' not in (p/'app/src/main/AndroidManifest.xml').read_text()
print('PASS v0.2 preflight: five level model, timed record UI, moving render geometry, license notes, pinned SDK36')
