#!/usr/bin/env python3
"""Structural, UX/API-contract, source-tree and licensing checks for phone-only CI."""
from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]
files=[
'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
'app/src/main/AndroidManifest.xml','app/src/main/java/com/atelier/marble/MainActivity.java',
'app/src/main/java/com/atelier/marble/FilamentBoard.java',
'app/src/main/java/com/atelier/marble/MarblePhysics.java',
'app/src/main/java/com/atelier/marble/VisualStyles.java',
'app/src/main/java/com/atelier/marble/ControlMath.java',
'app/src/main/res/drawable/app_icon.png','tools/SmokeCheck.java','tools/test_physics.sh',
'LICENSING_AND_ASSETS.md','README.md',
]
for f in files:
    path=p/f
    assert path.is_file() and path.stat().st_size>10,f
    print('FOUND',f)
physics=(p/files[7]).read_text();ui=(p/files[5]).read_text();render=(p/files[6]).read_text();styles=(p/files[8]).read_text()
assert 'LEVEL_COUNT = 100' in physics
for s in ['SHAPES','retainLargestComponent','farthest(','openingBits','rampDirections','flick(','touches(']:assert s in physics,s
for s in ['showLevels','showBestTimes','showWardrobe','showSettings','globalTheme','skinChoice','best_ms_','MotionEvent.ACTION_POINTER_DOWN','gestureVX','worldX(','worldZ(','pointerAngle','pointerDistance','board.rotateCamera','board.changeZoom','board.toggleOverview']:
    assert s in ui,s
for s in ['VisualStyles.PALETTES','VisualStyles.BALL_COLORS','setVisibilityAssist','setFollowBall','rotateCamera','changeZoom','toggleOverview','getHeightAt','addTiltedBox','getYaw','setAmbientOcclusionOptions','setBloomOptions','game.isCell']:
    assert s in render,s
assert styles.count('0x')>=50,'Six color schemes + eight marble colours'
gradle=(p/'app/build.gradle').read_text()
assert re.search(r'compileSdk\s+36',gradle) and re.search(r'targetSdk\s+36',gradle)
assert 'filament-android:1.75.1' in gradle and 'filamat-android:1.75.1' in gradle
assert "versionName '0.3.0'" in gradle
assert 'INTERNET' not in (p/'app/src/main/AndroidManifest.xml').read_text()
print('PASS: V0.3 structural preflight; Android compilation/runtime still need GitHub/device verification')
