# MARBLE ATELIER V0.2 — Precision Maze Test (native Filament Android)

**Phone-only GitHub upload workflow.** No computer, root zip extraction or server required.

## Exactly two GitHub files

1. Upload `MARBLE_ATELIER_GAME.zip` directly to your GitHub repository's root.
2. In GitHub's browser, create `.github/workflows/build-apk.yml`, pasting the separately
   supplied `build-apk.yml` content. GitHub automatically extracts the project ZIP.

Do not unzip the game on your phone, upload the Android folders individually or nest an
extra directory inside the ZIP. The ZIP itself contains `app/build.gradle` at its top level.

## V0.2 — Features

- Main menu with five selectable levels: First Steps, The Crossing, Thin Line,
  The Gauntlet, Moving Target.
- Precision joystick-like finger drag controls. Drag direction controls acceleration;
  release to let friction slow the marble.
- Safe starting box, sealed arena, alternating narrow maze barriers. Touching any wall
  immediately resets the ball and timer and increments the reset counter.
- Level 5 includes one moving wall that collides at exactly its displayed X position.
- Reach the gold/teal goal ring to finish. Local best times saved per level with
  hundredths-of-a-second formatting; Best Times menu and win screen records.
- Pause, restart, menu, next level, vibration on collisions.
- Native Filament PBR materials: graphite podium, brass trims, improved lighting,
  ambient occlusion, FXAA and restrained bloom. Procedural art avoids 3rd party assets.
- Fully offline at runtime. No analytics, advertising SDK, accounts, subscriptions or backend.

## Testing

From extracted ZIP, run `python3 tools/check_project.py` then
`bash tools/test_physics.sh`. The pure-Java tests validate all five reachable
maze topologies, contacts/reset, moving wall collision, goal detection and timing.

**Android build and runtime are not verified in this environment.** GitHub must compile
`:app:assembleDebug` and the APK must be installed on your Samsung before declaring success.
Check Android 17 API compatibility, navigation/touch responsiveness, FPS, layout fit and
whether the bloom/occlusion performance is acceptable on the S25 Ultra.

## Build notes

- Gradle 8.13, AGP 8.13.2, Android compile/target SDK 36, JDK17.
- Filament and Filamat version 1.75.1 pinned to avoid prior SDK37 metadata failure.
- APK artifact from successful GitHub action: `MARBLE_ATELIER_INSTALL_APK`.
- Debug builds are signed automatically using Android debug signing. This is not a Play
  Store publishing build or release signing solution.

## Legal

Filament is free for commercial use under Apache 2.0 with licence/notice obligations.
Read LICENSING_AND_ASSETS.md. The project uses no downloaded models or paid asset packs.
