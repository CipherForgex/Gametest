# MARBLE ATELIER — phone-only GitHub upload edition

This ZIP is the complete native Android project: Java, Google Filament, physics, UI, assets and tests.
It is **source code**, not an installable APK. GitHub Actions compiles it into a debug APK.

## Only two files to upload / create

1. Upload `MARBLE_ATELIER_GAME.zip` to the **root of a new, empty GitHub repository**, without extracting it yourself.
2. Create a workflow file at the **exact path** `.github/workflows/build-apk.yml` using GitHub's **Add file → Create new file** in the browser. Paste in the separately downloaded `build-apk.yml` content. The slash-separated path creates the folders automatically.

Do not upload the YAML to the repository root; GitHub Actions will not discover it there.

## What GitHub Actions does

- Checks out your repository.
- Verifies and extracts `MARBLE_ATELIER_GAME.zip` into `android-project/`.
- Installs JDK 17, Gradle 8.13 and Android SDK 36.
- Runs static structure checks and Java physics tests.
- Compiles `:app:assembleDebug` using matching Filament and Filamat 1.75.1 dependencies (SDK 36 compatible candidate).
- Verifies the resulting APK and posts the artifact `MARBLE_ATELIER_INSTALL_APK`.

After a successful run: go to **Actions → Build Marble Atelier APK → latest run → Artifacts → MARBLE_ATELIER_INSTALL_APK**. GitHub downloads a ZIP containing `app-debug.apk`. Unzip that **artifact** on the Samsung and tap `app-debug.apk` to install.

## Game

- Menu + Level 1 and Level 2 selections.
- Tilt-like finger swipe impulse moves the ball; wall and obstacle collision; goal hole, personal best.
- Pause, resume, reset, win and next level.
- Native Filament rendering with procedural graphite stage, spheres and metal accents.
- Offline runtime, no account and no server.

## Test status

Java physics and structure checks run locally; the phone-only ZIP extraction path is simulated and tested locally. **A full Android SDK/Gradle compile and device installation have NOT yet been completed**. A green GitHub build, followed by launch and gameplay checks on your actual Samsung, are still mandatory. The reference images are concept art, not verified game screenshots.

If the build fails, open the red workflow step in Actions and send the log; do not assume the generated APK exists until GitHub reports a successful artifact.

## v0.1.1 compatibility correction (2026-10-10)

First GitHub Actions compilation failed in `:app:checkDebugAarMetadata`: Filament/Filamat
`1.77.1` require `compileSdk >= 37` while this project uses `compileSdk 36` and
Android Gradle Plugin `8.13.2`. The dependency pair is now pinned to `1.75.1`
to keep the existing stable SDK and unchanged standalone GitHub workflow.

This is a targeted fix to the *observed* failure. The replacement ZIP has been
extracted and its offline tests pass, but its complete Android compilation and
real-device rendering are not yet verified. Upload the **new ZIP using the exact
same filename** `MARBLE_ATELIER_GAME.zip`; do not keep both versions in GitHub.
If the next run fails later during Java compilation or packaging, share its new
logs and we can continue from the next failure, without guessing.
