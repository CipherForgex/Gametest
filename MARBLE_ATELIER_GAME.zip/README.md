# MARBLE ATELIER V0.4.2 — Precision Maze, Native Android + Filament

## Phone-only installation pipeline

This is a **complete Android source project**, not an APK. Use the separately delivered
`build-apk.yml` (copy/paste into `.github/workflows/build-apk.yml`) and upload the intact
`MARBLE_ATELIER_GAME.zip` into the GitHub repository root. GitHub extracts it, checks it,
builds the debug APK, and publishes the APK as a workflow artifact. Never manually upload
project directories on a phone.

## Gameplay contract

- Exactly **10 fixed levels**, not 100 runtime-generated levels. The level layouts are
  stored explicitly in `LevelBlueprints.java` and have been curated from an offline
  shape-constrained procedural design pass. They are **not individually hand-sculpted
  curved meshes**. Silhouettes are approximated by modular tiles.
- Each maze starts in a one-exit safe cell. Contact with solid boundary/wall or moving
  barrier immediately resets position and the timer; cumulative reset counter continues.
- Levels increase in minimum **route length** (10 to 145 corridor transitions), with
  smaller ball clearance and moving sliding barriers later on. This is an objective
  progression measure, not a guarantee of playtested difficulty.
- The renderer uses the same wall objects and temporal obstacle positions as the
  collision model. Every open corridor centreline is checked in headless tests.
- Drag direction provides continuous acceleration. Flick delivers a bounded velocity
  impulse with swept sampling; it does not teleport the marble.
- Overhead is for inspection only. Ball steering and residual velocity are disabled;
  the timer continues. Walls remain visible in every camera mode.
- Tap 90° rotate for eased rotation. Two-finger rotate and pinch, smooth ball follow,
  plus/minus zoom and default-camera reset are supported.
- Gentle height variation and gravity acceleration are supported on selected late
  levels, although this is a simplified 2.5D physics model, **not** full rigid-body
  simulation over 3D mesh surfaces.

## Presentation and menus

- Native Android separate screens: home, levels, best times, the atelier, themes,
  marble choices, settings, camera, movement settings, audio, pause and completion.
- HUD contains compact icon buttons with descriptive accessibility labels.
- Six original material worlds: OBSIDIAN, INDUSTRIAL, IVORY & GOLD, FROST, EMBER,
  CELESTIAL. Themes have separate **floor and wall albedo + normal/roughness textures**,
  instead of only colour swatches.
- Eight original ball finishes with their own texture maps. The marble menu has a
  touch-rotatable **2D textured ball preview**; this preview is not a second Filament
  3D viewport. Skins use the same ball size, collision radius, and physics.
- Gameplay uses Filament's lit materials, antialiasing, ambient occlusion, bloom,
  physically based metallic/roughness parameters and shadow-casting light.
- Tap, impact and completion sound effects are bundled. There is currently no
  continuously modulated rolling sound.
- Offline local best times, progress, sensitivity and cosmetic preferences.
  The new V0.4 levels use a new `v04_best_*` namespace, avoiding misleading V0.3
  records from different levels.

## Known limitations — important

1. **No real APK compilation or on-device rendering is confirmed in this handover.**
   This environment lacks the Android SDK, Gradle and Filament Android dependencies.
   A green GitHub Actions build and a physical Samsung playtest are required.
2. These are fixed, generated-and-reviewed **tile-based** level designs. They do not
   yet have genuine circular/curved polygon mesh walls matching photographic references.
3. The moving gates oscillate. Discrete lock/key timed doors and authored mechanical
   animations are not separate implemented systems.
4. Automated tests prove topology, corridor-centreline clearance, dynamics contracts,
   and accessible gate-open phases. They **cannot prove** all ten levels are pleasantly
   playable by a human at actual touch sensitivity.
5. Textures are original, procedurally produced files; realistic offline images are
   included, but actual on-device material fidelity/FPS remains unverified.
6. Cosmetic preview is textured and rotatable using Android Canvas, not a full 3D
   independently lit preview. No monetisation has been added.
7. No screenshot or video claiming to show the V0.4 APK has been created.

## Testing

Run:

```bash
python3 tools/check_project.py
bash tools/test_physics.sh
```

`check_project.py` uses **only standard Python libraries** and validates 40 PNG assets
(including CRCs), 3 WAV files, configuration, source contracts and licenses.
`test_physics.sh` compiles and tests pure Java source, including every level, open
corridors, collisions, moving-gate retraction, reset, flick, overhead lockout and
camera coordinate maths. Both are executed in the GitHub YAML before Android build.

## Publishing / licensing

Filament and Filamat 1.75.1 are Apache 2.0 (royalty-free, with licence/notice obligations).
Generated art assets are bundled inside this project; see LICENSING_AND_ASSETS.md.
The GitHub workflow makes a **debug-signed APK**, only for testing. A production Google
Play release needs a secure release key, an AAB, policy review and device validation.

## V0.4.2 Samsung graphics startup hotfix

- Fixed Android launch crash `UnsatisfiedLinkError` at
  `com.google.android.filament.TextureSampler.nCreateSampler`.
- Root cause: V0.4 constructed `TextureSampler` in a Java field initializer,
  before the constructor body executed `Filament.init()`.
- `TextureSampler` is now constructed immediately **after** `Filament.init()`
  and before creating the `Engine`. Graphics, levels, menus, preferences,
  textures, and mechanics otherwise remain intact.
- `tools/test_filament_startup.py` is run from `tools/check_project.py` to
  prevent accidental reintroduction of the bug.
- Android `versionCode` raised to 6 and `versionName` to 0.4.1 so it can
  replace V0.4 without uninstalling (assuming matching APK signing key).
- This test guards source construction order, not runtime rendering. A new
  GitHub APK build **and** Samsung launch test are still required.


## V0.4.2 — high-end graphics stress experiment

See `GRAPHICS_STRESS_TEST.md`. A new offline Graphics Lab screen has four profiles, individual switches for eleven optional Filament passes, effect activation reports, an approximate frame-delivery readout and report sharing. The graphics startup guard can recover in SAFE mode on the next launch after an incomplete boot. Clear coat / anisotropy / goal emission, three accent lights and experimental SSR, TAA, MSAA, fog, depth of field, vignette, dynamic resolution and soft shadow preferences were introduced. Experimental Filamat shaders have baseline fallback compilation. No levels or best-time namespaces were changed. **Full Android compilation and real mobile rendering are unverified at handover.**
