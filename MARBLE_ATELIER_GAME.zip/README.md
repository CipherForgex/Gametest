# MARBLE ATELIER V0.3 — Geometric Precision Maze (Android / Filament)

**Phone-only build:** Upload `MARBLE_ATELIER_GAME.zip` intact to your GitHub repository root. Create `.github/workflows/build-apk.yml` using the full workflow pasted in ChatGPT. GitHub Actions extracts the ZIP and builds the APK. DO NOT upload project folders individually.

## V0.3 implemented features

- 100 deterministic, distinct connected maze layouts generated offline, spread over ten board silhouette families: orbit/circle, diamond, hexagon, octagon, rounded, clover, star, trapezoid, capsule and teardrop. Shapes are approximated as clean modular tile silhouettes. They are **not** yet smoothly curved architectural walls like the photograph references.
- Five progressive size/difficulty chapters, a unique one-exit start chamber, always-accessible goal, fatal wall contact with immediate reset and local 100-level best times. Levels vary in exact route difficulty within each chapter; they are not mathematically guaranteed to become harder on every single consecutive level.
- Moving hazard in each tenth level starting at 20 (9 timed obstacles); slopes and projected gravity after level 45 (236 ramp tiles across all 100 layouts).
- One-finger pressure-free precision drag; fast flick adds a brief velocity impulse. Adjustable precise/balanced/quick drag feel in Settings. Two-finger rotate/zoom suspends steering. Camera relative controls preserve intuitive screen direction after yaw rotation.
- Smooth ball-follow orbit camera, 90-degree rotate control, full 360-degree two-finger rotation, +/- zoom buttons, two-finger pinch and overhead overview. Optional visibility assist hides nearby obstructing wall pieces **visually** without changing collisions. It does not blend transparent walls.
- Six selectable palettes with global override or automatically changing level themes. Eight selectable PBR ball finishes, some with additional metallic rings. Customization stored offline on device. All options unlocked in the V0.3 playtest build so they can all be tested.
- 100-level scrollable chooser, main menu, best-times library, wardrobe, settings, pause, retry, next level, resume progress and haptic reset.
- No network permission, no accounts, no ads, no external textures, music, models or app-store assets. Procedural visuals; included Filament/Filamat open-source notices.

## Testing and known limitations

- `python3 tools/check_project.py`: checks structure, Android SDK/Filament versions, menu and camera integration and license files.
- `bash tools/test_physics.sh`: compiles pure Java classes and checks all 100 unique connected maze topologies, closed boundaries, one-exit starts, collisions, timer resets, goals, moving obstacles, ramp presence and camera-relative movement symmetry.
- **NOT validated here:** actual Android compilation, Google Filament rendering and native API compatibility, ball feel on touch hardware, camera framing/occlusion, phone performance, smooth transitions and true APK installability. This environment has no Android SDK or Gradle. Run the GitHub workflow and test on your Samsung before calling V0.3 stable.
- V0.3 uses code-defined colors/geometry rather than detailed texture packs or physically transmitted glass materials. It aims for high-end polish but it has not been demonstrated to match the previously generated concept imagery.
- Cosmetics are currently free and unlocked for testing, with **no payment processing or item unlock economy**.
- Ramps are gentle single-cell tilts with projected 2D acceleration, not a complete 3D rigid-body simulation.

## Licences

Filament and Filamat 1.75.1 are Apache 2.0, free for commercial redistribution with their licence/notice requirements. See `LICENSING_AND_ASSETS.md` and `app/src/main/assets/`.

## Google Play release

The workflow produces a debug-signed test APK. Publishing requires your own release keystore, signed AAB, target API/policy review, performance/security/compatibility testing, store graphics and disclosure. Do not publish the test APK as a production release.
