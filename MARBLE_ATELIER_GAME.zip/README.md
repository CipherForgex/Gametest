# Marble Atelier V0.4.3 — Studio Visual Pass

Native Android + Google Filament marble maze. Exactly TEN fixed levels. Free offline gameplay, no server or account.

## Build from a phone
1. Upload `MARBLE_ATELIER_GAME.zip` to the root of your GitHub repository. Do not extract it.
2. Paste the separately supplied YAML into `.github/workflows/build-apk.yml`.
3. Run GitHub Actions; download the `MARBLE_ATELIER_V043_INSTALL_APK` artifact.
4. Extract the artifact and install `app-debug.apk` on your Android device. An existing install needs the same signing key to upgrade without data loss.

## What's new
- Dark premium studio stage/backdrop and much darker skybox; no giant bright white void as intended.
- Better-balanced directional/point lighting to reduce clipped highlights.
- Bevelled/chamfered top wall geometry with a metallic inset strip.
- All 40 built-in PBR maps refreshed, most at 512px, six visual families and eight balls.
- Better framed follow camera and shortened reset feedback banner.

## What remains unchanged
10 fixed levels, time trials and records, collisions, flick, moving gates, gravity ramps, 360-degree orbit, overhead lockout, six themes and ball customisation, Graphics Lab profiles.

## Tests
`python3 tools/check_project.py && bash tools/test_physics.sh && bash tools/test_graphics.sh && python3 tools/test_visual_upgrade.py`

## Critical limitation
This source has not been compiled or rendered with a real Android device in this environment. The changes are an **experimental visual build** pending GitHub compiler/device testing, not a promise of concept-art parity. See `VISUAL_RESEARCH_AND_LIMITS.md`.
