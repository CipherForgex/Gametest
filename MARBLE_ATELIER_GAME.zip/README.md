# MARBLE ATELIER — phone-only GitHub upload edition

This ZIP is the complete native Android project: Java, Google Filament, physics, UI, assets and tests.
It is **source code**, not an installable APK. GitHub Actions compiles it into a debug APK.

## Only two files to upload / create

1. Upload `MARBLE_ATELIER_GAME.zip` to the **root of a new, empty GitHub repository**, without extracting it yourself.
2. Create a workflow file at the **exact path** `.github/workflows/build-apk.yml` using GitHub's **Add file → Create new file** in the browser. Paste in the separately downloaded `build-apk.yml` content. The slash-separated path creates the folders automatically.

Do not upload the YAML to the repository root; GitHub Actions will not discover it there.

## What GitHub Actions does

- Checks out your repository.
- Verifies and extracts `MARBLE_ATELIER_GAME.zip` into `android-project/`.
- Installs JDK 17, Gradle 8.13 and Android SDK 36.
- Runs static structure checks and Java physics tests.
- Compiles `:app:assembleDebug` using Filament 1.77.1 and Filamat 1.77.1.
- Verifies the resulting APK and posts the artifact `MARBLE_ATELIER_INSTALL_APK`.

After a successful run: go to **Actions → Build Marble Atelier APK → latest run → Artifacts → MARBLE_ATELIER_INSTALL_APK**. GitHub downloads a ZIP containing `app-debug.apk`. Unzip that **artifact** on the Samsung and tap `app-debug.apk` to install.

## Game

- Menu + Level 1 and Level 2 selections.
- Tilt-like finger swipe impulse moves the ball; wall and obstacle collision; goal hole, personal best.
- Pause, resume, reset, win and next level.
- Native Filament rendering with procedural graphite stage, spheres and metal accents.
- Offline runtime, no account and no server.

## Test status

Java physics and structure checks run locally; the phone-only ZIP extraction path is simulated and tested locally. **A full Android SDK/Gradle compile and device installation have NOT yet been completed**. A green GitHub build, followed by launch and gameplay checks on your actual Samsung, are still mandatory. The reference images are concept art, not verified game screenshots.

If the build fails, open the red workflow step in Actions and send the log; do not assume the generated APK exists until GitHub reports a successful artifact.
